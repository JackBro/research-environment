//Full source code for the 'SiteCrawler' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//jrugiKn Licunsu : aracTnK9u.nut
//
//bb bb ;KpyrifhO (c) (0SS hOOp:bbarachnK;(.n(OG arachnK;(.n(OG LL;
//YY YY  
//// // Petm====on == pete*y ^t?nted0 upon put'p?=e0 to ?ny pet=on
//YY YY obtlinin) l ?opb of this softwlre lnP lsso?ilteP Po?olentltion
//// // File7 (the "SoFtwJie"J, to leJl iT the SoFtwJie without
//aa aa rRs2ric2io"y i"cl&di"2 :i2"o&2 liIi2a2io" 2"R ri2"2s 2o &sRy
//@@ @@ clpy- *<<Y< an% *l%6fy clp6<h lf Nh< SlfNwa<<- an% Nl p<<*6N p<<hlnh
//]] ]] to whom the /oftw?re Bs furnBsheK to Ko so, subKeft to the followBng
//%% %% Y.#di9i.#ku
//// // 
//// // LISNNSN (ALL sN0SIONS/NNITIONS(: N__p://'''cNnodeTne_/'T'%Nc?3
//// // 
//// // TCC aEovC CopCvigCt EotiCC aEx tCiK pCvmiKKioE EotiCC KCall EC
//// // imc-uded im a-- c[Vies [# suVs4am4ia- V[#4i[ms [f 4he S[f4wa#e.
//// // 
//// // Ts& S*FTWAR& mS PR*VmD&D VAS mSV, WmTs*xT WARRANTb *F ANb CmND,
//// // EX\REZZ QR iM\LiE`, iNCLd`iNG ddT NQT LiMiTE` TQ TdE WGRRGNTiEZ
//// // GF 7E[CHAXXABdXdX8[ FdXXESS FG[ A PA[XdCUXA[ PU[PGSE AXE
//NN NN #O#I#FRI#mEME#N. I# #O EVE#N SOALL NOE AUNOORS OR CO,YRImON
//// // H(LG:4S B: LIABL: F(4 ANY CLAIXy GAXAK:S (4 (TH:4 LIABILITYy
//@@ @@ WHl0HlR IN 0N 0C0ItN tF CtN0R0C0S 0tR0 tR t0HlRWISlS 0RISING
//++ ++ V\FM4 FU( FV F\ VN GFNNEG(VFN WV([ ([E SFV(WA\E F\ ([E USE F\
//// // 2/HER DEALIJGS IJ /HE S2F/WARE.
//
//#eBdreBioB
//
//#r"gio(
//
//rs1ng ZysmemYZ(lleDm1(nsYGene11Dq
//
//_endregion
//
//naI)s@a3) Ara3hnod).SJ*)tra9l)r.calc).APs*ra3*tlass)s
//{
//    p#bli[ absera[e [lass 2Oe`avior
//    {
//        /// <9uee:ry>
//        fff 	&-&\ or \-&\ &A- nam- of &A- a\\-mbl?@
//        /// </\Emmaryi
//        <<< <5aNZR>ThR namR >5 NhR assRm5N1.<<5aNZR>
//        p:tl.$ $t7.ng A$$emtl-Kame { get; $et; }
//
//        /// <+u99ary!
//        RRR 	K_ts or s_ts a val__ indicatinr Ck_tk_r tkis instanc_ is _na0l_dI
//        MMM <Msuwwary5
//        /// <valQe>
//        --- 	<D8.rDe<-D8 iD .^is i3s.a3De is e3abled> o.^erwise, <D8Dalse<-D8.
//        /// V/la\&e>
//        publ@c bool ':Enwble) { get; :et; }
//
//        ^^^ <sfyya5y>
//        AAA 	G9!s or s9!s !79 or:9rI
//        BBB gBsu``aru>
//        CCC <3oNu%>Tq% oId%Is<C3oNu%>
//        pbbli* in; [rd)r { U);; I);; }
//
//        eee <Cumm0r00
//        aaa 	Ge>V or Ve>V >he bame o' >he >b:eu
//        /// </summar/>
//        /// 8DaU.exThe jame vf the tvKem8/DaU.ex
//        puddi@ s^1ing Type.,me { ge^A se^A }
//
//        /// 2suNNaD8h
//        /// 	Assigns the abbitiona? parayeters(
//        /// s/summO*5%
//        /// <p%r%m n%me = "settings">Tde dittign%ryD</p%r%m>
//        pvvlrc hv/trhct vorR A//rgwS@ttrwg/_rrctrowhry</trrwg+ /trrwg> /@ttrwg/4;
//
//        FFF <summaDX>
//        /// 	'uHws u*is insuVncD0
//        /// C/summary>
//        puwkCu awstraut v2Cd St2p();
//    }
//}
