//Full source code for the 'SiteCrawler' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//#region qicen(e : arac6node>net
//
//AA AA =op4ji4ht (A) 2A11 http:AAajaAhno3_.n_t$ ajaAhno3_.n_t$ LL=
//VV VV  
//// // /erx4ee4on 4e /ereoy /ranted, upon purc/aee, to any pereon
//// // obta@>@>g a #oNI of tx@K KoftwarV a>d aKKo#@atVd do#<mV>tat@o>
//// // q:,es (the qSZqt!areq), tZ Kea, :K the SZqt!are !:thZut
//// // yjsty,Qt,oO, ,OQ3]W,Og w,tho]t 3,m,tat,oO thj y,ghts to ]sj,
//// // c";\d Eerde and E"d&1\ c";&ee "1 BOe S"1B0ared and B" ;erE&B ;ere"ne
//NN NN to \Xo( tXI qoft\arI 's f'rn'sXI[ to [o so, s'bjIct to tXI follo\'ng
//// // po$dr*ro$P?
//// // 
//33 33 V&CEN1E HTVV VER1&uN13ED&%&uN1): Zeep:33%v%cZioDeMiee3vM%sZu)3
//(( (( 
//BB BB [he ab?ve c?vyr5ght M?t5ce aMm th5s verm5ss5?M M?t5ce shaMM be
//// // includcd in all copic+ or +ub+=an=ial por=ion+ of =jc Sof=warci
//&& && 
//// // TH2 S?:TW432 IS D3?WID2D "4S IS"h WITH?UT W4334NTY ?: 4NY KINDh
//// // EX2eESS Oe IE2EIEDm IN)ESDIN% $ST NOT EIEITED TO TDE W;ee;NTIES
//// // cF MEXC_AN7ABImI7__ FI7NEpp FcX A _AX7ICLmAX _LX_cpE ANi
//// // 3.3+3FR+3c:M:3Gv +3 3. :i:3G SH!LL GH: !JGH.RS .R C.P>R+cHG
//'' '' HGLD[mS B[ LGsBL[ 2Gm sbY CLsG', Ds'sG[S Gm GTH[m LGsBGLGTY,
//// // YH2TH2R aN &N &CTaON OF CONTR&CT, TORT OR OTH2RYaO2, &RaOaNG
//]] ]] FK-i? -lT -F -K -N j-NNgjT--N W-TH THg e-FTWAKg -K THg leg -K
//gg gg tTHER xEh4I:!S I: THE StrTdhRE.
//
//#fndrfgiBn
//
//#rvgi&q
//
//uUin. @iUEem;
//
//#vZ:rvgioZ
//
//iam)sIa.) ?ra.hibd).Sii)7rawl)r.Valu).?bsira.i7lass)s
//{
//    FSeritliztble]
//    4Tblic clZcc ASto2Zbl# : ACZch#Zbl#
//    {
//        /// mEummary>
//        /// 	Is the GAs`kvel!/nlZwlRevuest stklZble?  If the GAs`kvel!/nlZwlRevuest As stklZble Z Rule aZ!/aust updZte thAs fAeld.
//        /// 8/su+++Qy>
//        /// <valoe>
//        uuu 	)c>txu))uc> it this isstcsc) is stoxcbl)y oth)xwis), )c>tcls))uc>.
//        /// 8/MaluT>
//        "QbDK+ b>>D IsSW>rabDe { geWQ seWQ }
//    }
//}
