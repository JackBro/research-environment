﻿DEMO RESTRICTIONS:
1.) Maximum crawl time is 5 minutes.
2.) Crawl rate is limited by decompilation protection.
3.) Only the first 10 HyperLinks and 20 Files and/or Images will be processed per WebPage.

The LICENSED version is not subject to these restrictions.

Full source code for the 'SiteCrawler' project is included in the 'Licensed' version.  (C#/T-SQL/Database)

