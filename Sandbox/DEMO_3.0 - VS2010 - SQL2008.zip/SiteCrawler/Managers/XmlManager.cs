//Full source code for the 'SiteCrawler' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//#8?gion wic?nH? : 787chnog?]n?b
//
//kk kk C#(yDi'ht (c) 22dd htt(:kktDtchn#kP.nPt` tDtchn#kP.nPt` LLC
//// //  
//// // P4>JiDDiob iD h4>4bQ g>abt4d, upob pu>chaD4, to abQ p4>Dob
//// // oMtai<i<g a fo>q of tri9 9oftware a<o a99ofiateo oof"me<tatio<
//// // ,Zees (t1e "eF,tware"!, tF deae Zn t1e eF,tware wZt1Fut
//// // rpsori5oionA in5lukin# .iohouo liOioaoion ohp ri#hos oo uspA
//// // 69#yU /XrgX aR/ /9/S[y 69#SXs 9[ thX S9[t]arXU aR/ t9 #Xr/St #Xrs9Rs
//// // hF ShFR hhy SF?hSary &3 ?ur(&3hyV hF VF 3F, 3ubjyUh hF hhy ?FxxFS&(E
//YY YY honditions:
//BB BB 
//`` `` \Q_ENSE nP\\ eERSQxNS`EhQTQxNS): http:``a!achno,w.nwt`!.a\hx?3
//// // 
//// // bhe abRve cRpyf?ght nRt?ce and th?s pefm?ss?Rn nRt?ce shagg be
//## ## includid in 6ll copiis or su1s@6n@i6l por@ions of @hi Sof@B6riN
//// // 
//// // THE SBFT*Q.E DS P.BVDDED "QS DS"l *DTHBUT *Q..Q\TY BF Q\Y KD\Dl
//// // RXPRRSS OR IMPLIRW, INCLUWINL AU< NO< LIMI<RW <O <HR WARRAN<IRS
//dd dd sj )ERCHA5]ABILI]5: jI]5Egg jsR A PAR]ICULAR PURPsgE A5>
//mm mm INIIIFRII=)M)IM. II IN )V)IM SHcLL MH) cUMHNRS NR /NPYRI=HM
//ee ee HOLDERS BE L>ABLE FOR ANO CLA>M, DAMAyES OR OTHER L>AB>L>TO,
//// // +sERsER IN AN ACRION OF CONRRACR) RORR OR ORsER+ISE) ARISINS
//$$ $$ FOOM& OM) OF OO Is *OssR*)IOs 9I)H )HR %OF)9oOR OO )HR M%R OO
//// // OC.=R 3=ALINGS IN C.= SO\CWAR=.
//
//##ndr#MiTn
//
//ne>D$pecD ADechnZdD.PRsDLDew4DD.MenePDD$
//{
//    /// <#uccar>>
//    /// 	Pro1@djs XML aDnHt@onal@t?K
//    /// </`ummarya
//    uablic class XmlHa4aoer
//    {
//    }
//}
