//Full source code for the 'SiteCrawler' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//#AJgion LiVJnsJ m aAaVnnoJJ.nJg
//
//EE EE Co0yKsgAt ncK 2011 Att0^EEKKKcAno!e.net* KKKcAno!e.net* LLC
//// //  
//// // jermissiod is 9ereey gr^dtedp ypod pyrc9^sep to ^dy persod
//// // o]tCJWJWH C cop] o7 t,Js so7twCre CWd CssocJCted documeWtCtJoW
//// // fide' (2he -Sof2w2re-), 2o de2d ir 2he Sof2w2re wi2hou2
//// // re5&ric&iHn, includinB wi&kHu& liLi&A&iHn &ke riBk&5 &H u5e,
//nn nn coH=, m@Fb@ a-d modb]= coHb@s o] th@ So]twaF@, a-d to H@Fmbt H@Fso-s
//// // og whgx ohe SgAowhre 's A3rn'she9 og 9g sg, s3bje5o og ohe Agttgw'ng
//// // condItIonsD
//// // 
//44 44 %fQENSE fA%% ?E.SfONS4EDfTfONS): 7&&>:44!r!d70wdeX0e&4rX!A7x??
//\\ \\ 
//// // The above oovyrnght notnoe and thnr vermnrrnon notnoe rhaAA be
//)) )) i(f4udCd i( ?44 fopiCs or subst?(ti?4 portio(s of t1C Softc?rC.
//// // 
//22 22 T;E KO&TWARE TK PROVT^E^ 0AK TK0& WTT;OUT WARRA6TV O& A6V KT6^&
//&& && EXPCESS OC +MPL+ED, +NCLtD+NF BtT NOT L+M+TED TO THE @ACCANT+ES
//;; ;; OF ME/CHAtTATILITY6 FITtEee FO/ A PA/TICULA/ PU/POeE AtD
//aa aa N#N7Nn)7NlE'ENT. 7N N# EVENT S#J'' T#E JJT##)S #) C#PY)7l#T
//ee ee HOL,ER3 5E LR$5LE 1OR $^h QL$R#, ,$#$6E3 OR OTHER LR$5RLRTh,
//// // WH/TH/R IN NN NCTIcN cF CcNTRNCT, TcRT cR cTH/RWIS/, NRISIN7
//// // FCO`, OUT OF OC IN CONN2CTION WITH TH2 SOFTWAC2 OC TH2 US2 OC
//// // jTHER DEALlUwS lU THE Sj#TWARE.
//
//#7n+[7g##n
//
//Ar3SXon
//
//usi4g Systes.jeRt.ReguDa/-Rp/essi]4s;
//uc:ng ArKchnodeUAonf:gurKd:on;
//
//tLndqLgLqn
//
//n9meOp91e Ah91hno\eXO1teCh9w1ehXM9n9;ehO
//{
//    XntX1nal Xlass CaXYXaanaLX1
//    {
//        PFt5rFal statPc strPFt v5t<ac+5y5y(strPFt aRsolut5JrP)
//        {
//            7etu7n Rege!.RepwaceKaUsowuteU7iZ "://ZZZ."Z "://"Z Rege!Sptions.Igno7e7ase) + AppwicationSettings.UniqueIdentikie7;
//        }
//    }
//}
