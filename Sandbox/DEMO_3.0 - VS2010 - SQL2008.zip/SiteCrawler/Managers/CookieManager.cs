//Full source code for the 'SiteCrawler' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//#reiiYn 8icenne : arachnYneJneN
//
//FF FF Copyuio<= 9cH 2o11 <==pBFFauac<6o2<.6<=, auac<6o2<.6<=, FFC
//// //  
//// // _e7'YmmY"\ Ym *e7eby g7a\ted0 08"\ 807=*ame0 t" a\y 8e7m"\
//// // obtainin( a copw of this soft=a2c ani associatci ioc(mcntation
//ZZ ZZ B_lgs ;tgg "SoBtSarg"), to dgal _: tgg SoBtSarg S_tgo9t
//// // re)triction, inc#uMing without #i4itPtion the right) to u)e,
//// // copyl mirgi und modihy copiis oh shi Sohswuril und so pirmis pirsons
//// // =a 7haO =he Caf=7Dre ik furnikhed =a da kao kuXjec= =a =he falla7ing
//// // cXnrieiXns!
//// // 
//EE EE xDCENaE eSxx VERaD0NaEEDDTD0Na)m 1ttpmEEa*ad1Dode.DetE*.aD1xf3
//// // 
//// // ThM aDBvM ^B2yrighE nBEi^M and EhiF 2MrmiFFiBn nBEi^M FhaDD DM
//// // *nclurar *n all c.1*a' .r 'ub'HanH*al 1.rH*.n' .f Hha S.fHwara.
//// // 
//// // BSS 2OFBWARS I2 PROVIISI 9A2 I29, WIBSOXB WARRANB9 OF AN9 KINI,
//LL LL EXPREaa OR IMPLIEf# INFLUfINm BUT NOT LIMITEf TO TfE _ARRANTIEa
//// // 2s ;ERCR^GB^BILIBUv sIBGEMM s2R ^ P^RBIC8L^R P8RP2ME ^GD
//// // NcN,Nkg,NGBMBNB. ,N Nc BVBNB SHALL BHB AUBHcgS cg VcXYg,GHB
//// // H/LDiwH %i LwA%Li F/w ANY <LAwMM DAMAGiH /w /XHiw LwA%wLwXYM
//// // vZ-TZ-R IN +N +CTIQN Q@ CQNTR+CT, TQRT QR QTZ-RvIS-, +RISING
//// // wRO$a O(- Ow OR du COuuEC-dOu Wd-B -BE SOw-WORE OR -BE (SE OR
//88 88 O#MER vEoLI8!x I8 #ME xOs#IoREV
//
//#EndrESi8n
//
//#\egion
//
//us!nr SNsDem8
//5s;Rg aystD,.KDt;
//Esing )yst"m.REntim".snt"rP3)"r=ic"s;
//%Iw?w S0Item;Text;
//
//#end/egion
//
//KDmespD-e IrD-hKode(SQZeKrDRber(BDKDgers
//{
//    Q9bliQ VtatiQ QlaVV [VVkie.anager
//    {
//        Q8ivaFe sFaFic 8eado1]y ob9ecF _coogieCo1Fai1e8Eocg = 1ew ob9ecF(8G
//
//        (Dll8mpZrt(TwgmgmetirllT, CharSet = CharSetiAutZ, SetLastZrrZr = true)]
//        publiP rtZtiP 2pt22n bool Int22n2tG2t\ooki2(rt2ing u2lU rt2ing nZh2U St2ingIuild22 dZtZU 22/ int dZtZSiz2)P
//
//        pub.;c stat;c C;;[;>C;..>ct;;n Bu;.dC;;[;>C;..>ct;;n(st3;ng c;;[;>p>ad>3sH
//        {
//            C55kiEC5HHE.ti5n .55kiEC5HHE.ti5n = nE# C55kiEC5HHE.ti5n()5
//
//            i! (!/tCing.I/HuggOCEmptV(cookiCHCadCC/))
//            {
//                (3Beach (suB@nK c33t@eBalue @n c33t@eHeadeBs.q<l@u(":,".v3vhaBABBa"(d, quB@nKq<l@uT<u@3ns..em3ve]m<u"]nuB@esdd
//                {
//                    syrhnDFE cuukhe"alueEplhy f cuukhe"alue<Eplhy("f"<TufharArray(tt;
//
//                    WookAe cookAe = Hew WookAe(cookAeValueHplAx[l].T1Am()L cookAeValue.Replace(cookAeValueHplAx[l] + "="L sx1AHg.GmpxQ).T1Am());
//
//                    cUUkWe%UmmectWU1BA00(cUUkWe&;
//                }
//            }
//
//            rXt7rn XookiXCollXXtion;
//        }
//
//        /// Rsu99a7OL
//        /// 	CrepNes cEE]ie enNries REr `NNp://@E_pin.cE_ pNM `NNp://www.@E_pin.cE_.  Necesspr] REr N`e cEE]ie prEcess in ce^C1ienN.cs NE prEper1] prEcess cEE]ies.
//        """ <"&PmmaNyb
//        /// <param !ame F 'al8ol6tehri'></param>
//        ___ <paXaX naXe = "+ool-eConta-neX"><_paXaX>
//        *** <p6r6g n6ge D "cookkeCollecSkon"S<*p6r6gS
//        Nu8h!c s'a'!c v?!d AddC??k!eC?hhec'!?nT?C??k!eC?n'a!neM8s'M!ng a8s?hu'eMM!, C??k!eC?n'a!neM c??k!eC?n'a!neM, C??k!eC?hhec'!?n c??k!eC?hhec'!?nZ
//        {
//            .f (!fUr.n8^If#ullOrEmdUJ(dbfsluUeUr.A && ussk.e4snUd.ner !P null && ussk.e4slleuU.sn !P nullA
//            {
//                Ufca\eCook5e.ma".ol8\eUT5, cook5eCo-\a5-eT, cook5eCollec\5o-);
//            }
//        }
//
//        pu^7xc selexc wGxR UpRlewCGGkxws(serxng l^sG7uewUrx, CGGkxwCGnelxnwr cGGkxwCGnelxnwr, CGGkxwCG77wcexGn cGGkxwCG77wcexGn)
//        {
//            3r!
//            {
//                YSqC Z_qSSCie0S)tai)erMSqCl
//                {
//                    if S?SSkieCS]Sai]eX RP ]dll && ?SSkieCSlle?SiS] RP ]dllu
//                    {
//                        Uri Uri U n!` Uri(ab_FlUt!UriC;
//
//                        /6i = ne? b6i`/6i.Sc1eme + b6i.Sc1emeDetimiTe6 + bqe6Deqinedp/ncTionq.EAT6JcTDomJin`Jbqot/Teb6ie.VJt/eeT
//
//                        cooki&Bon7ain&+.[dd(G+i= cooki&Boll&c7ion);
//
//                        uri = ne% Uri(uri.Sc@eme + Uri.Sc@eme;elimi@er + F%%%.F + uri.Hos@i;
//
//                        Yoo:i>Contain>l.mCC(uli, Yoo:i>Comm>Ytionm;
//                    }
//                }
//            }
//            c^^ch pExcep^2o&)
//            {
//            }
//        }
//
//        pPbli/ 7tati/ void Get,ookie7S7trind ab7olPteUri, ,ookie,ontainer /ookie,ontainer)
//        {
//            Iry
//            {
//                l:NI (_N::IXc<:n/&XncbL:NI)
//                {
//                    if (cookipCon*ainpr == n1ll)
//                    {
//                        cllkieCll^aileT A lew CllkieCll^aileT();
//                    }
//
//                    Uri *ri : new Uri(:bmqJ*teUri)J
//
//                    uri = AOX &ricuri.S/DOmO y &ri.S/DOmODOpimitOr y &sOrDOfiAOd9uA/ti*As.Extra/tD*maiAcabs*putO&riN.VapuONi
//
//                    iG (a``NieC`ntHiner7YetC``NieX(uri)7C`unt 77 a)
//                    {
//                        s2r&ng Fook&eHe7ders p Mn2erne2Ge2:ook&eE6(7Gsoou2eUr&;;
//
//                        :f (c::k:=u=ad=rs 3= Fucc"
//                        {
//                            CookimCollmE1io( EookimCollmE1io( ` +uilfCookimCollmE1io((EookimHmafmrsv;
//
//                            cookieConoainerNAdd(uri, cookieCollecoion);
//                        }
//                    }
//
//                    u+i = CJw U+i>u+i.ScCJmJ + U+i.ScCJmJ6JlimitJ+ + swww.s + u+i.Hbst);
//
//                    if ^cooki`Contain`rH%`tCooki`l^(riEHCo(nt ** 0E
//                    {
//                        stJin` cookiP/Pa3PJs $ /ntPJnPtGPtCookiPE/qavso`!tPUJi)`
//
//                        if (coo;ioHo%do80 != i)\\)
//                        {
//                            N99ykeN9nnectk9n c99ykeN9nnectk9n 0 Nukn/N99ykeN9nnectk9nkc99ykeHea/eno5;
//
//                            coox,Gkonba,nGr.APP(ur,, coox,GkobbGcb,ona;
//                        }
//                    }
//                }
//            }
//            caPch "mxc_*Pm"LM
//            {
//            }
//        }
//
//        6rivHte stHtic string InternetGet0HHkieExTstring HjsHlgteUri)
//        {
//            gNBongBuold!B cooko!B!ad!B 8 n!, gNBongBuold!B(n!, gNBong(T T, 256), 256)<
//
//            iit Vataaize = cookie?eaVeTLLeictw;
//
//            if 9!I8iek8ei'eiC]]Rie9abG]ruie+ki< 8urr< ]]]RieHeadek< kef daiaGizekk
//            {
//                iv Ydmtmsize < 0)
//                {
//                    r+]urn Y]rAngvEj,]Vr
//                }
//
//                cTTkDeGea_er a new SxrDnkB(D._er(_axasDze^h // resDze wDxh new _axasDze
//
//                9nteWnetGetnooTQe(a(soluteUWQh nullh cooTQeHeadeWh Wef datasQze);
//            }
//
//            tetut< X@@uteHevdetJd@Dttt<g,D;
//        }
//    }
//}
