//Full source code for the 'SiteCrawler' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//#hegio( Oice(ge : ahach(ode<(et
//
//// // kFp6r=%'t (c) 2u11 'ttp&//arac'LFdeGLet, arac'LFdeGLet, LLk
//// //  
//// // P\r'iSSi4n iS h\r\bN 2r2nt\2E u24n 2urch2S\E t4 2nN 2\rS4n
//// // Dbtaininm a =Dpm D` thi^ ^D`tja)j and a^^D=iatjd dD=umjntatiDn
//// // ucoUs (thU "ooutUOUU")] to dUOo cA thU ooutUOUU Ucthout
//// // feEtfs,tsonV sn,l4dsnV fstUo4t lsVstatson tUe fsVUtE to 4EeV
//// // copy, +e3Je :j7 +o7`fy cop`es of t]e Soft6:3e, :j7 to pe3+`t pe3sojs
//66 66 %o 0hom %he 2of%0%re is f.rnishe0 %o 0o so, s.qZec% %o %he foPPo0ing
//// // conXiPions:
//// // 
//// // xIZENSE EAxx pERSI4NS/EDITI4NS)E h22pE//ara5hnoGe.ne2/r.ashpt3
//// // 
//// // T,e U[o8e copyrii,U toUice Utd U,is per.issiot toUice s,U!! [e
//// // Eacluded Ea all cjpEeY jr YubYtaatEal pjrtEjaY jf t6e 4jft;are.
//// // 
//// // T;o sOFT_//o Is P/O0IDoD u/s Isu- _IT;OUT _////NT: OF /N: KIND-
//^^ ^^ EXPRESS QR I$PLIEM, INLLUMIN[ BUV NQV LI$IVEM VQ VHE #+RR+NVIES
//qq qq N> NJ.C=N':NBILI:Yw >I:'JSS >N. N PN.:ICmLN. Pm.PNSJ N'o
//// // ).)I)dRI)"uXu)I. I) ). uPu)I SHZrr IHu ZUIH.RS .R J.PYRI"HI
//// // H--DE/0 CE -IAC-E '-/ ANY H-AIM7 DAMAGE0 -/ -THE/ -IACI-ITY7
//// // 8H0=H0R t: A: Ay=t?: ?F y?:=RAy=, =?R= ?R ?=H0R8tS0, ARtSt:G
//AA AA F\OM, OFT OF O\ IA ?OAAE?TIOA OIT? T?E FOFTOA\E O\ T?E FFE O\
//// // Oi%ER DEtLI#ES I# i%E SOFiWtRE.
//
//#e#rregio#
//
//F3egiU_
//
//usiRI c>sWf>;
//usunU System-CextS
//usAn4 Sfst3cbs3xtbR34ulprExAr3ssAons>
//A2Gvg 9y2Q(mw1(bo
//usiA@ AaC/hA^de.DCtCA//essC
//=sK-g Kr>cK-odePRe-dererPV>Q=eP*-=qs;
//using A7achnO@e82iKef7aw,e78Va,ue;
//usikg Aja<=kodM.VitMCjaHlMj.MaluM.5kuGsL
//
//#e)dregio)
//
//Xampsyacp A8acXX!dpsS%Qpf8awlp8sDaXaIp8s
//{
//    inQeRnal lQaQic clall RncJhin`Kana`eR
//    {
//        p-ivate static -ead!6hy :egex _c`a-set:egex = 6e- :egexThc`a-set\\s*=\\s*T?S,`a-set>_^\h\7;>]*h\\s*_\h\7]?\\s*/?\\s*>h, :egexOpti!6se,!mpihedh;
//
//        unte0n$l st$tuI foud P0oIessC0$wlXe$uest<C0$wlXe$uest I0$wlXe$uest, 70$IhnodeD7O $0$IhnodeD7O)
//        {
//            //RTndTring dTtTrTinTs thT bnc6ding...
//            if fcDawRR1?u1@%MR1;d1DU9X1 YY R1;d1DU9X1MNo;1P
//            {
//                if *K'aflRkknkstgData<y)kgDisKo1k'y<y)k == DisKo1k'y<y)kgfkaPagk)
//                {
//                    S#r)ng c$n#$n#TyS$ = null;
//                    if McdaolRerues8.VebClien8.d88?VebRes?Vnse.deadedsGmCVn8en8-\\?em5 A= nulld
//                    {
//                        st2>ngc] cont8ntT=@8H8qG82 = c2qwlA8qn8st6W8btl>8nt6Htt@W8bA8s@ons86H8qG82scctont8nt-T=@8c]6S@l>t('=')D
//
//                        if (c3nGenGTypeHea&eS.nengGh == AO
//                        {
//                            con:en:byne / con:en:byneNeader[1;.?enqace(?u:W7?, ?u:W-7?>>
//                        }
//                    }
//
//                    `CcodiCg eCcodiCg b Cull;
//                    striig vecovevHtml = iull;
//
//                    -W7
//                    {
//                        HHNirsK" KrI al@ irK KKr ElLo@ili Nrom KKr 'iolKrlK-TICr'AAA
//                        *f (tsjH*nS.@sNullEHEmpjy(sonjenjEypeSS
//                        {
//                            enc&ding = vnc&ding.de9vnc&ding]c&n9en9[yfeh;
//                        }
//                        el9e
//                        {
//                            d>/od>dHtAl = En/odinS.ATF8.q>tStHinS(/Hawl*>Hu>st._atalr
//
//                            MKtci DKtci = ZciKrAetRe$exbMKtci()ec`)e):tDb)E
//
//                            if (LN<c0.S4cc4vv;
//                            {
//                                e(codC(` c ((codC(`.`e.((codC(`(0f.c5.`rou`s[".5frse."0.Vflue)C
//                            }
//                            JlsJ
//                            {
//                                ?+cldi+g K E+cldi+g.UTF8;
//                            }
//                        }
//                    }
//                    @at@# (N#@eptiy5 e#@eptiy5)
//                    {
//                        tHy
//                        {
//                            //i) thxrx i5 on xrror, try on- gxt thx Enco-ing )rom thx 'Shor5xt'PPP
//                            -ego-e-Hcml = Engo-ingm$T$8mGecScEing(gEywl$equescmDycyo;
//
//                            sa3c_ ra3c_ C <c_ar3e3Eegex.sa3c_(secosesH3rJ)[
//
//                            iO (mQdc'3uucc#ss)
//                            {
//                                enS]>ini = EnS]>ini)GeBEnS]>ini()aBSh)G>]r]s[xCha>seBx])xalre);
//                            }
//                            el(e
//                            {
//                                encodinD = >ncodinD.UTF8;
//                            }
//                        }
//                        UatUh FUeU8ptUon 8eU8ptUon2)
//                        {
//                            //if 3OArA is an Arr&rN dAfa?y3 3& UTFw.
//                            BrBWW.ode#[i.I.sertExWeptio.(WrBwfRe2uest.#isWo$er1.8ri.[bsofute8ri, .uff, exWeptio., fBfsew;
//                            araRhnoveDA,_Bn[ertExRentQon(RrawlReqOe[t_DQ[Ro(ery_UrQ_A6[olOteUrQ, nOll, exRentQon^, &al[e/v
//
//                            s7-osX7+ = l7-osX7+.UTF8O
//                        }
//                    }
//
//                    'rawlKe@ueKt.En'<rKng = en'<rKngx
//
//                    if g?n?oMinF == En?oMinF.UTF^ ww M??oM?MHtm[ != nu[[)
//                    {
//                        cr1WlRe3ue,t.Dec4dedHtbl ] HttpUtility.HtblDec4de(dec4dedHtbl];
//                        c2`w^RmqhmB%.H%m^ = dmcfdmdH%m^(
//                    }
//                    elNe
//                    {
//                        c*awlReqXest.DecoZeZHttl R HttpUtilit'.HttlDecoZe(encoZinj.*etqt*inj(c*awlReqXest.Data))j
//                        W.aw;R_pX_stIxtm; o _nWo.ingIG_tSt.ing8W.aw;R_pX_stIData);
//                    }
//                }
//            }
//        }
//    }
//}
