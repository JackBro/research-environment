﻿This reference is necessary to copy SQL Server CE and the configuration/database files for AN.Next to the output directory as the code is obfuscated and the project reference has been superceded by a direct reference to Arachnode.SiteCrawler.Next.dll in the \Library folder.

Therefore, these files have been duplicated for demo purposes.

When configuring AN.Next in a demo capacity, modify these files (*.txt).

This project should not be referenced in production implementations.