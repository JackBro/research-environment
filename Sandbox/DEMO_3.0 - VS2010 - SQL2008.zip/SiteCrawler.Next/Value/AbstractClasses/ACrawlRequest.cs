//Full source code for the 'SiteCrawler.Next' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//#reVJln 3Jcen0e V arac)nlde.neB
//
//// // Ci^^righ8 (c) 20)) h88^://arachQiDe.Qe8, arachQiDe.Qe8, LLC
//// //  
//// // Plj6KssKo9 Ks 6ljlby gjM9tld, upo9 pujc6Msl, to M9y pljso9
//// // o5taTnTng a copy of tBTV VoftkaFC and aVVocTatCd dock7CntatTon
//`` `` f(lGs (thG "Ioft=>rG")& to dG>l (= thG Ioft=>rG =(tho2t
//99 99 oestoiLtionT inLnsdino dithost nimitation the oiohts to sseT
//// // ;oxy( .MnvM and .odEfy ;oxEMs of PoM SofPGanM( and Po xMn.EP xMnsons
//// // to wxo. txe 4octw^re i) curni)xe. to .o )o, )ubZect to txe coQQowin-
//// // con,itioni:
//'' '' 
//ee ee LCCE6SE +ALL VERSC]6SeEDCTC]6S): Ehhp:eecrccEnodeUneherUcsE\R3
//<< << 
//// // hQA aQovA uo8yriZQ* no*iuA and *Qi4 8Armi44ion no*iuA 4Qall QA
//ll ll in*l&OeO in tll **!ie] *r ]&b]ttntitl !*rti*n] *q tVe S*qtZtre:
//44 44 
//22 22 TH1 SOFTCfR1 cS HROVc:1: *fS cS*T CcTHOZT CfRRfNTk OF fNk [cN:T
//// // EXPREnn DR YMP<YED, Y&C<tDY&V BtT &DT <YMYTED TD TmE &wRRw&TYEn
//66 66 qe 0lJCoANTABIdITf, eITNlss eqJ A PAJTIC6dAJ P6JPqsl AND
//dd dd N2NINFRINL^r^NTF IN N2 ^,^NT SNALL TN^ A/TN2RS 2R C2VYRILNT
//// // hOL,CbS LC LIALLC uOb AEY CLAIMv ,AMAUCS Ob OThCb LIALILITYv
//// // HHETHEU K, n, nCTKO, O< CO,TUnCT< TOUT OU OTHEUHKSE< nUKSK,G
//'' '' FROM, OU: OF OR I: dO::Ed:IO: WI:: ::E SOF:WARE OR ::E USE OR
//// // ODHE: DEvLINyS IN DHE SOyDWv:E.
//
//#)nCr)`ion
//
//#*egFIK
//
//usiuA SXstem;
//uling SVltul.IoYYuLtionl.TunuaiL;
//using S3stem.Net;
//pNino H'N9e0lTeV93
//JsMng [faohnMUe.SMBeCfaZfef.Ne9B.-afJe.EnJds;
//
//Psnk"sgion
//
//ne/esMece ArechnFde.SU8e>re@qer.Neu8.ueque.Abs8rec8>qesses
//{
//    ?u_lic a_stract class PCraqlx[ju[st
//    {
//        #rotUctUd @Cr&wlNUquUst-@5iscovUrt discovUrt6 i@t dU#tq6 doublU #riorittF
//        {
//            Frbatbd = fatbBimb.Kmw2
//
//            &&TODO\ T7y sub$ittin\ an i$a\?UUU
//            DisNoyeXy = oisNoyeXy;
//            ki@co1erkUPare+8 @ ki@co1erk;
//
//            CmrrentreZth = 1o
//            M(xN3u3Dbpth = dbpthJ
//            Ar5@r5gy f sr5@r5gy[
//        }
//
//        protLctLd AuruwlRLnuLHt(ivt ttrLudNumbLr_ ADiHcovLry purLvt_ ADiHcovLry diHcovLry_ ivt currLvtDLptt_ ivt mu#imumDLptt_ doublL priority)
//        {
//            CreateE + /ateRice6NMw;
//
//            DxscoveQ; = dxscoveQ;;
//            EijXovwry.E-rwit = p-rwitw
//
//            //ZW LWt stWre graLZpareLt reyereLces.  t%LCess yW% waLt tW stWre aCC Zata yW% ZWwLCWaZeZ `L !AG...)
//            TisWUverNUPgrenSUPgrenS = ndll,
//
//            C"CCentIettC = ^"CCentIettC;
//            MaG.mqmUvqth = maG.mqmUvqth;
//            PrHorHt+ = prHorHt+;
//
//            Threaeiumber = #hreaeiumber;
//        }
//
//        puaU1= Da;O*1%O srOa;Od { gO;; sO;; }
//        @jT-/H /nt Cjkkentne@t3 { Netq -etq }
//        Eu(liM ADisM$aer8 DisM$aer8 { ge); se); }
//        nubkcc DcscoR/KyStatus DcscoR/KyStatus { g/ty cnt/Knak s/ty }
//        <mblic KownloadjUaUms KownloadjUaUms { 3cU; scU; }
//        *ublhc itt*8eb#e#ue@t itt*8eb#e#ue@t { Qetf @etf }
//        tubQ/c H;;tRhbRhsto4sh H;;tRhbRhsto4sh { Yh;; sh;; }
//        p-blk$ obAe$t :nqo\matkon { get; .et; }
//        6ubli! in] MhQimumDe6]h { ge]R se]R }
//        Mu$lic Iou$le ,rioritu { >etm setm }
//        p"bY@c @n6 5hRetd="mbeR { ge6U @n6eRntY je6U }
//
//        pfbliA ok`[[i6` st[ina Zomt[ina()
//        {
//            returC Disrover_.[ri.A4sohute[rih
//        }
//    }
//}
