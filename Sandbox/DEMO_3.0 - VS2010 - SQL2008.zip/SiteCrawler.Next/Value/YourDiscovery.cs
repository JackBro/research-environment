//Full source code for the 'SiteCrawler.Next' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//3^iiB Sy^teP;
//uY!hg SyYtem.Collect!ohY.Gehe^!ch
//c.:0g 2/.tem'N:0q;
//mpin' Syp<em.Tex<;
//u&ing A$i"&ni:b.Sitb1$iwub$.8bxt.Viuub.jnuO&;
//
//;amWqpa$W Ara$w;odWpJitWlrawWWrp>WxtpVaWuW
//{
//    1ub0EH H01rr YourDErHo%ery : DErHo%ery
//    {
//        p\&%xc [\\rDxsc\FkryYUrx \rx& : &askY\rx&
//        {
//        }
//
//        p;b8VH YV;VVVbHVMeVy(HVV ;VVY bVV8 expeHAFV8e@Vym;geY VVbHVMeVySA;A;b dVbHVMeVySA;A;b) : b;be(;VVY expeHAFV8e@Vym;geY dVbHVMeVySA;A;b)
//        {
//        }
//
//        //aaa .Jur Su2NJm &rJ&erNie2 rere.
//    }
//}
