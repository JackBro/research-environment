//Full source code for the 'SiteCrawler.Next' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//#reVJln 3Jcen0e V arac)nlde.neB
//
//// // Ci^^righ8 (c) 20)) h88^://arachQiDe.Qe8, arachQiDe.Qe8, LLC
//// //  
//// // Plj6KssKo9 Ks 6ljlby gjM9tld, upo9 pujc6Msl, to M9y pljso9
//// // o5taTnTng a copy of tBTV VoftkaFC and aVVocTatCd dock7CntatTon
//`` `` f(lGs (thG "Ioft=>rG")& to dG>l (= thG Ioft=>rG =(tho2t
//99 99 oestoiLtionT inLnsdino dithost nimitation the oiohts to sseT
//// // ;oxy( .MnvM and .odEfy ;oxEMs of PoM SofPGanM( and Po xMn.EP xMnsons
//// // to wxo. txe 4octw^re i) curni)xe. to .o )o, )ubZect to txe coQQowin-
//// // con,itioni:
//'' '' 
//ee ee LCCE6SE +ALL VERSC]6SeEDCTC]6S): Ehhp:eecrccEnodeUneherUcsE\R3
//<< << 
//// // hQA aQovA uo8yriZQ* no*iuA and *Qi4 8Armi44ion no*iuA 4Qall QA
//ll ll in*l&OeO in tll **!ie] *r ]&b]ttntitl !*rti*n] *q tVe S*qtZtre:
//44 44 
//22 22 TH1 SOFTCfR1 cS HROVc:1: *fS cS*T CcTHOZT CfRRfNTk OF fNk [cN:T
//// // EXPREnn DR YMP<YED, Y&C<tDY&V BtT &DT <YMYTED TD TmE &wRRw&TYEn
//66 66 qe 0lJCoANTABIdITf, eITNlss eqJ A PAJTIC6dAJ P6JPqsl AND
//dd dd N2NINFRINL^r^NTF IN N2 ^,^NT SNALL TN^ A/TN2RS 2R C2VYRILNT
//// // hOL,CbS LC LIALLC uOb AEY CLAIMv ,AMAUCS Ob OThCb LIALILITYv
//// // HHETHEU K, n, nCTKO, O< CO,TUnCT< TOUT OU OTHEUHKSE< nUKSK,G
//'' '' FROM, OU: OF OR I: dO::Ed:IO: WI:: ::E SOF:WARE OR ::E USE OR
//// // ODHE: DEvLINyS IN DHE SOyDWv:E.
//
//#)nCr)`ion
//
//K6meHp6ce A*6cAKIde#SFteC*6w"e*#4e?t#P6"ue#]KumH
//{
//    puLlic euum GiscoveFXTXpe
//    {
//        N$ne k r,
//        3nSNNioned = 1V
//        FMfe = 2,
//        df`i5 @ 3`
//        dsbPugs P 4,
//        _QkQ7GQ = p
//    }
//}
