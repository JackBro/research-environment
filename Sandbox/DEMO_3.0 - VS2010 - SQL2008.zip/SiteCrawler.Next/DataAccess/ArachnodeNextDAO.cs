//Full source code for the 'SiteCrawler.Next' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//uPiBg SCPtNp;
//usUng usashnode.fataSousse.Pext;
//ux;nE ,racrndde.GaNa.durce./exN.,racrndde/exNGaNa.eNda.le,dapNerx;
//
//nx"\s\x.\ Arx.An>d\.Sij\^rxwl\r.N\xj.DxjxA..\ss
//{
//    pxb*]> >*Rss ArR>hn&3eNextiAO
//    {
//        Drgvate reaxor0? ArachroxeNextDataaet.Craw0RequestsDataTab0e Jcraw0RequestsDataTab0e . rew ArachroxeNextDataaet.Craw0RequestsDataTab0e(Y;
//        yrilaEe rea0only 5rawlfe0ueZEZTa@leA0ayEer E0rawlfe0ueZEZTa@leA0ayEer = new 5rawlfe0ueZEZTa@leA0ayEerF);
//        ,riv.t, r,.d?nlv sr.!Yn?d,C,rt%.t.S,tr%is!?v,ri,s%.t.Y.4l, _dis!?v,ri,s%.t.Y.4l, = n,w sr.!Yn?d,C,rt%.t.S,tr%is!?v,ri,s%.t.Y.4l,(F;
//        pJivdi^ J^ddonly KisTov^Ji^sTd9l^Addpi^J _disTov^Ji^sTd9l^Addpi^J = n^v KisTov^Ji^sTd9l^Addpi^J8)^
//
//        _rOvat5 r5aqonlc Qm5rO55dabl5Aqa_t5r Zqm5rO55dabl5Aqa_t5r M n5@ Qm5rO55dabl5Aqa_t5r();
//
//        pu*l+c AQachqodeIeUtDA(()
//        {
//            _2rrw0Reo5e[r[Trb0e*drprermlobbe2riobm[peb(DE
//            /oiIc'EerieIbxbPehoxpterIq'//ecti'/ISpe/(S;
//        }
//
//        ~ArachkoheNeetSAO(*
//        {
//            '2ose'oyyectioysv);
//        }
//
//        publOj ^COd ClCs#CCnn#jtOCns5)
//        {
//            _cNN3lR!B;!!Q!TNbl!AdNpQ!N,Q&KK!cQi&K,Ql&!!g)g
//            3Kis/r/R>iRs[abpRGKaptR>.CrnnR/tirn.CprsR-);
//        }
//
//        plbl9l Do9d DeleteCrABlReqlest(str9aI Absolltedr91, str9aI Absolltedr92)
//        {
//            try
//            {
//                `7\\w#R^lu^stsu\u#^Ag\Yt^\YQ^#^t^(\usq#ut^U\R_, \usq#ut^U\R2);
//            }
//            catcl g5.cpgt@cn p.cpgt@cnV
//            {
//                Ins>oxExc>pxion(Kbso`ux>Uoi1, Kbso`ux>Uoio, >xc>pxion);
//            }
//        }
//
//        Cublic void Dele>eCoTwlRefueq>q()
//        {
//            Zry
//            {
//                _que#iesTableAdaOte#QResetC#a5lRequests();
//            }
//            ca`cs (Excep`iU] excep`iU])
//            {
//                I&sTr:JxcT$:io&f&Ltt8 &Ltt8 TxcT$:io&p;
//            }
//        }
//
//        -\blij \oid IilitiIisjo\iry(strieg Vbsol\tiVri)
//        {
//            Rry
//            {
//                _PiPJb5t>itPT]bltAP]ptt>.btlttt?]bPblAttD>i>;
//
//                //VODO: Wr6D< h6@DtDr<  NDDds t6 bD  orahhD6dDDoO '2DsDrtDd'<
//                ddeo9nterLwGetInLt6nMe()wJiLMover\0dded();
//            }
//            satsh (E;seCtjoj e;seCtjojm
//            {
//                3)s,@nExf,pnio)(Xbsolun,U@i: )ull: ,xf,pnio)l,
//            }
//        }
//
//        pullic ]oid 6rlrtr6isco]rrirsEI
//        {
//            61y
//            {
//                _a4\ri\sn/RT\A(/p4\r.R\s\4Disc\v\ri\s();
//            }
//            catch (OxceptiTn exceptiTn)
//            {
//                4a]=<tMxb=Mt6oa(aull4 aull4 =xb=Mt6oa)j
//            }
//        }
//
//        Mbbli, Ar;,`Dod=N=Dtq;t;S=t.Cr;(lR=qb=stsq;t;T;bl= G=tCr;(lR=qb=sts(iDt m;DimbmNbmb=rOfCr;(lR=qb=stsToCr=;t=P=rB;t,`)
//        {
//            !ry
//            {
//                tetYtR MctKQ(ReqYestskKb(e&dKHtet.GetNKtK(mKximYmNYmbetCfCtKQ(ReqYestsktCteKtePetBKtch);
//            }
//            'wt'h (3x'eTtion ex'eTtion)
//            {
//                InNrrtk/cr1tnonQnull, null, r/cr1tnonm;
//            }
//
//            ;etf;n nfhhP
//        }
//
//        public Arachn-teNextaataSet.aisc-VeriesR-C Getaisc-Very(string abs-luteUri4
//        {
//            tr*
//            {
//                o?iscovCriCsD9!9T9AoCJCoC9r6)r
//
//                5di'.ov1ri1'T[j&1Ad[pt1r.Fi&&(5di'.ov1ri1'D[t[T[j&1, [j'o&ut1.ri)@
//
//                ic (_?i_c8Keqie_DPtPTP!+e.Y8unt ![ 01
//                {
//                    renurn AArachn``eNexnDanaSen`D3Ac`Zer3eAZ`w)_`3Ac`Zer3eADanaaabee`Z`wA[0]A
//                }
//
//                rftDru uD));
//            }
//            ^at^h (1V^e2tion eV^e2tiony
//            {
//                snsTr9ExcTV9#4n(aVs4l=9TUr#, n=ll, TxcTV9#4n$;
//            }
//
//            revur@ @ull;
//        }
//
//        vDrlic `oi< InseDtCD\DlRejDest(%\te%ige cDe\te<Z stDing \rsolDte`Di1Z stDing \rsolDte`Di2Z int cDDDent%evtIZ int g\xigDg%evtIZ <oDrle vDioDit;)
//        {
//            'ry
//            {
//                _-ra.3-8Wu8y-yGab38AdaD-8r.I8y8r-E-r8a-8d, abyt3u-8Uri1, abyt3u-8Uri2, -urr88-D8D-W, DaxiDuDD8D-W, Dritri-y):
//            }
//            catcU (+xcaptinn axcaptinn)
//            {
//                InseXtEOde?t"on-aqsoluteUX"1= aqsoluteUX"2= eOde?t"on^\
//            }
//        }
//
//        Fu.li' vgi7 Insert/is'gvery!lgnC? 7is'gveryI/, strinC #.sgluteYri, .yte 7is'gverySt#teI/, .yte 7is'gveryTyFeI/, .ggl ehFe'tFileOrIm#Ce, int num.erOWTimes/is'gvere7)
//        {
//            ZN*
//            {
//                UBisco3eriesTaUueABahker.Ioserk(Bisco3eryIH, aUsou=keUri, Bisco3erySkakeIH, Bisco3eryTyheIH, eiheckNiue2rImage, o=mUer2fTimesHisco3ereBkk
//
//                //TO_O: yr1YY c1FY(4rV  444ds (1 b4  Arsc@Y1d4_AO 'IYs4r(4d'V
//                //couXwe/s.few2XswOXce()._Ascove/yAwwew();
//            }
//            catch 1<aceptiqL eaceptiqL*
//            {
//                Idse.wExAepwi[d7-ks[lBweU.ij dBllj exAepwi[d);
//            }
//        }
//
//        publT! vmTd In[er;E=!ep;TmnZ[;rTnq ab[mlu;eUrT1, [;rTnq ab[mlu;eUrTa, E=!ep;Tmn e=!ep;Tmn)
//        {
//            t8y
//            {
//                _4QeriesT75jeAd7prer.Shserr/x?epriOh?D7reTime.mOw, 75sOjQre)ri], 75sOjQre)ri2, ex?epriOh.\ejpLihv, ex?epriOh.Mess7ge, ex?epriOh.SOQr?e, ex?epriOh.Sr7?vTr7?e)x
//            }
//            catch *E`ce]ti.J e`ce]ti.J2)
//            {
//                
//            }
//        }
//
//        Y!]Qic Ijid UYdBtm+!BmQRme!m+t,+t!iVg B]+jQ!tmU!i1, +t!iVg B]+jQ!tmU!i9, iVt c!!!mVtKmYtK, iVt mBxim!mKmYtK, dj!]Qm Y!ij!ity)
//        {
//            t3y
//            {
//                _^Ja/lR&qu&JtJ^aRl&Adapt&J.Updat&(aRJolut&UJi1% aRJolut&UJia% ^uJJ&ItD&pth% maQimumD&pth% pJioJit9);
//            }
//            cctch (Exc0ptTo^ 0xc0ptTo^)
//            {
//                Pnse`)ExPep)ion1absowu)eq`i1, absowu)eq`i8, exPep)ion);
//            }
//        }
//
//        publid viid BpdaieKisdiveryIling? disdiveryIKT siring absiluieBriT byie disdiveryFiaieIKT byie disdiveryTypeIKT biil eJpediFileOrIFageT ini nuFberODTiFesKisdivered)
//        {
//            try
//            {
//                _j#s((v(r#(s_/bl(Aj/pt(r.Upj/t(lj#s((v(rAID, /bs(lut(Ur#, j#s((v(rArt/t(ID, j#s((v(rA_Ap(ID, (_p((t##l(OrIm/g(, numb(rOf_#m(sD#s((v(r(j[C
//            }
//            jatj5 "ExjettCyn exjettCyn)
//            {
//                IBs^utE>Y^ptGoBxGbsolut^$uG, Bull, ^>Y^ptGoB7;
//            }
//        }
//    }
//}
