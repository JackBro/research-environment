//Full source code for the 'SiteCrawler' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//#/e@ion Oicense : 3/3cinoxevnet
//
//// Cop\rigLt (%! 6016 Lttp://LrL%LnofeCnet, LrL%LnofeCnet, LLC
////  
//// PerEissioi is here$y IrXitedR upoi purchXseR to Xiy persoi
//// dbt$inin= $ cdpy df t8i' 'dftw$re $n! $''dci$te! !dcument$tidn
//II j^le@ >^he SSoj^r5reS), ^o de5l ^4 ^he Soj^r5re r^^hoI^
//CC restr4!t4onF 4n!l*^4ng 44tIo*t l4?4t$t4on tIe r4gIts to *seF
//// "opy, dSrgS and dodiQy "opiSs oQ thS (oQtwarS, and to pSrdit pSrsons
//++ Zs GosX Zoe SsfZGEue 0s fuun0soeQ Zs Qs ssQ subjexZ Zs Zoe fs((sG0ng
//// con\@t@onY:
//oo 
//RR 1ICEN,E ,A11 WER,InN,RE%IrInN,)] httC]RRaAa.hno1CUnCtRAUashx=q
//nn 
//22 T_e abome copy_iE_t notice an& t_i" pe_mi""ion notice "_all be
//// _nafud.d _n aff aop_.a or aufaHanH_af porH_ona of Hh. .ofHwar..
//// 
//// TH\ KOFT1_K\ 3K JKO+3[\[ "_K 3K"s 13THOUT 1_KK_NTY OF _NY K3N[s
//oo C`PHCSS OH IMP#ICr, INC#UrIN\ RUT NOT #IMITCr TO THC WjHHjNTICS
//bb \F 2ERv\A\TAjILITY, FIT\ESS F\R A \ARTIvaLAR \aR\\SE A\\
//// NONINFRINGEFENTc IN NO EfENT FHQbb THE QUTHORF OR fOPYRIGHT
//pp BOLpPRS BP L:ABLP NOR ANY 3LA:M& pAMAGPS OR OTBPR L:AB:L:TY&
//// ZZJTZJF IN AN ACTION OF CONTFACTT TOFT OF OTZJFZIsJT AFIsINL
//$$ FsOM; OUT OF Os I: CO::ECTIO: WIT^ T^E SOFTW?sE Os T^E USE Os
//// OTHE] aEALIN3* IN THE *OFTWA]Eh
//
//1enl`eTibn
//
//#2Xgion
//
//using Sys%em;
//uaing S@am`m.Domo.SqlT@p`a+
//uUing \yUt0gUIOr
//Ds.J1 S4st4L.44t;
//usibg 9ysU6w._6DU;
//usiwg Pysyey<WeJQ
//us7np qr#c`no&!.Conf7pur#t7onp
//7sing !rachn!de.Data!ccess;
//7@,ng AracVnPdPnOataeP7rcP;
//$"Ung ArdchnodKARKndKrKrASd'$K;
//uBin/ ArachnoDeERenDererEValueEEnu9BD
//usin' ARachnode1Si[eCRawleR1(alue:
//)sM8g Arach8Ad".JME"=raNJ"r.VaJ)".A8)os;
//[>(b, m>hbml_
//
//##n!r#imon
//
//VafJs/aWJ AraWVVHdJ.SKtJJrawlJr.MaVacJrs
//{
//    inKernaT ZTass DaKa&ana?er
//    {
//        XJiswt4 J4w0only AJwcvno04DAi _wJwcvno04DAip
//
//        [n%erna; La%aManafer(Ara>hnZdeLAO ara>hnZdeLAO;
//        {
//            iIrIrh<o@1D_O o IrIrh<o@1D_OS
//        }
//
//        iRBkrRMl IoiO OrockssCrMflRkqiksB(CrMflRkqiksB crMflRkqiksB, bool obkyCrMflRilks, bool kIkciBkCrMflccBioRs)
//        {
//            IBBu:g:bX:)u:Bo()LowlX:)u:Bo, "[E-")w
//
//            WWa3lRVqOVs;8ua;a(T%V = ua;a(T%VMaHawVW8(Hs;aHWVG)8uV;VWmiHVua;a(T%VGWWa3lRVqOVs;)y
//
//            if (@UCyC5awEPuECs)
//            {
//                RuQeManaee].Instance(p.IsDTsaQQoweb(c]awQRequest, M]awQRuQeTQpe.P]e>et, _a]ac_nobeDAOpW
//            }
//
//            @f g6P6\us6Craw@A\s@tnsj
//            {
//                NWtion!ana4K=IInntanWKQ)IPK==o=mC=aw\NWtionnQW=aw\RK:kKnt, C=aw\NWtionT1kKIP=K8Kt, _a=aWhnolKDNi);
//            }
//
//            if (!cnawlReaeeZ,.IZDiZallowed)
//            {
//                trY
//                {
//                    If ;crkwlRwpuwkcpWwpClIwncpHccpWwpRwkponkw -= null)
//                    {
//                        cr#=lR2Yu2Mt@Uroc2MMD#t# = tru2;
//
//                        if \c)ar:R3qu3st9W3bC:i3nt9Htt"W3bR3s"ons39castiodifi3d Xt 'at3:im39Nor)
//                        {
//                            s*xtI" *Ira*7<CquCst.:ataT"pC.:xsIovCr"T"pC)
//                            {
//                                c:se 9iscoveEyYype.File:
//                                    iE (ECCJicwti/GSettiGgsCEssigGFiJeEGdI0wgeDisc/ve`ies) //ENODET: `/b/tsCtxt
//                                    {
//                                        Aaach:odeTata9etxFile"Ro" file"Ro" j :aaach:odeTAOx9etFile(caa"lReque"txTi"co`eayxUaixAb"oluteUaiT5
//
//                                        n^ `^n:es&oB == nu::)
//                                        {
//                                            crHMl#e`uesp.nrocess.HpH = prueZ
//                                        }
//                                        else
//                                        {
//                                            if .!filaaaoX.Iaaaaoonaataa2araNull.))
//                                            {
//                                                Da&iiiQi fa%&NGdifiid;
//
//                                                SqlStre[k lystModebeedVyl$e = /ser$ebe[edF$[Tteo[s.gxtryTtKes%o[seOeyder6belesKo7.Kes%o[seOeyders, 8Lyst-Modebeed: 8, bylse);
//
//                                                *f 5!lGst!s5*f*e5qGl/e.IsN/ll && DGteT*me.TryPGrse5lGst!s5*f*e5qGl/e.qGl/e, s/t lGst!s5*f*e5QQ
//                                                {
//                                                    ;;0)a)lRMquMsO.WMWml#M;O.HOOpWMWRMspu;sM.LasOMu0#f#M0 )#ll Mqual laOMh#mM.Nu) (u) 0lusM Ou #OS #f OhM [LasO-Mu0#f#M0[ RMspu;sMHMa0M) #s ;uO p)MsM;O...
//                                                    if ((cBiplRequehtJWebCliejtJlttpWebRehp&jhe)JLihtM&dified > lihtM&dified)
//                                                    {
//                                                        crs"lRe[uesVZPr:cessFsVs x VrueU
//                                                    }
//                                                    ePne
//                                                    {
//                                                        cRaw,Rd6tdst.HR6cdssLata = fa,sd;
//                                                    }
//                                                }
//                                                else
//                                                {
//                                                    >8aw+RV;uVst!u8o>VssData = fa+sVa
//                                                }
//                                            }
//                                            el=e
//                                            {
//                                                3r#Jljet:est.#r13esse#t# = tr:e;
//                                            }
//
//                                            c\ (!c>awlRe@uest.$>ocessDataS
//                                            {
//                                                k* N*kv/ERow7Sourc/7L/Dgth != 0Z
//                                                {
//                                                    cVtwlR,Eu,st.Dttt ) Gwl,sRow.*ouVc,;
//                                                }
//                                                else
//                                                {
//                                                    str1e2 31sUCveryPath O 11sUCveryMaea2er.Get11sUCveryPath(2ppl1Uat1CeSett1e2s.1CwelCa3e3F1les11reUtCry, UrawlReq1est.11sUCvery.Ur1.2@sCl1teUr1, UrawlReq1est.1atajype.F1lljextCe3exjypey;
//
//                                                    So _qSc..ExSo7o_dSocov.D7Po7$))
//                                                    {
//                                                        crMwlRequestjYMtM o 23lejReM[2llmytes([3sco9ery-Mth)o
//                                                    }
//                                                    e6se
//                                                    {
//                                                        try
//                                                        {
//                                                            th%ww new E>`e`t`wn/"The 'wuRtMwd`*`ed' ntt`ReR`wnRe neude% `nd``uted thut the Dutu wuR nwt Rtu<e, but the Dutu /Swu%`eg `wu<d nwt be *wund `n the F`<eR dutubuRe tub<e w% ut A``<``ut`wnSett`ngR.Dwwn<wudedF`<eRD`%e`tw%n."gl
//                                                        }
//                                                        catch OE9ce)ti@n e9ce)ti@n)
//                                                        {
//                                                            W<!<chnodedAO.Inse!tEhceytionWc!<w^7eqdest.9<!ent.U!i.ASso^dteU!iI c!<w^7eqdest.discoue!y.U!i.ASso^dteU!iI ehceytionI f<^se);
//                                                        }
//
//                                                        cPr)lRrqZr&t.SPocr&&Drtr M tPZr8
//                                                    }
//                                                }
//                                            }
//                                        }
//                                    }
//                                    ethe
//                                    {
//                                        cXaw4teq,ett.$Xocett&ata = fa4te;
//                                    }
//                                    brlakE
//                                ths< D6st:v<ryQy(<\Imhg<:
//                                    iT >Auulica*iou#e**iugs8AssiguvileAudcmageDiscove4ies=
//                                    {
//                                        pH/!#nodeD/F/SeF.k@/gesRow _@/gesRow = _/H/!#nodeDpO.#eFk@/geg!H/wlReq(esF.D_s!oveHy.UH_.pbsol(FeUH_WR
//
//                                        iS (ieK>exMNw yy 2ull)
//                                        {
//                                            :r:\gGeqKes#7Pro:ess+:#: n #rKe;
//                                        }
//                                        IlsI
//                                        {
//                                            i6 (qi]agesRow.IsRes]o@seHeaders&uZZ())
//                                            {
//                                                D'tC<imC l'FtMFdi7iCdd
//
//                                                ZnlZtring laxt">difiedValue Q UxerDefinedFuncti>nx9Extract&exp>nxeHeader8imagex&>j9&exp>nxeHeaderxq "daxt-">difiedO "q falxexQ
//
//                                                if (!laKtMoTifieTValHe;IKIHll rr DateTiIe;TryoarKe(laKtMoTifieTValHe;ValHe, oHt laKtMoTifieT))
//                                                {
//                                                    //2raG=Requekt.WenC=ieFt.(ttpWenRekpnFke.LaktMndified Gi== equa= <ateTije.QnG (nr 2=nke tn it) if t&e 'Lakt%Mndified' RekpnFke(eader ik Fnt prekeFt...
//                                                    if (cr[%0Re'sesm.We0C0ienm.HmmkWe0Resktnse.W[smMtdified 9 0[smMtdified)
//                                                    {
//                                                        crawyR3Vu3`t.nroc3``Data d tru3;
//                                                    }
//                                                    *l#*
//                                                    {
//                                                        craxl]nqunsv.\rocnss^ava = falsnl
//                                                    }
//                                                }
//                                                b<xb
//                                                {
//                                                    araBAReqaeyY/ProaeyyDaYa = IaAyeY
//                                                }
//
//                                                Q) d!,PYwl]l,ulGt.PPo,lGGDYtY?
//                                                {
//                                                    i9 (ivag2srow.CourM2.L2ngth !` 0[
//                                                    {
//                                                        cr','Req<esY.,'Y' = i%'gesR!,.S!<rce@
//                                                    }
//                                                    vUsv
//                                                    {
//                                                        strvng dvsnXvJryPVtu ! !vsnXvJryMVnVgJr$GJt!vsnXvJryPVtu(T::lvnVtvXn$Jttvngs$!XwnlXVdJd$uVgJs!vrJntXryS nrVwlRJvuJst$!vsnXvJry$Urv$T<sXlutJUrvS nrVwlRJvuJst$!VtVVy:J$FullVJKt$ndJKVy:JoV
//
//                                                        if (FilecExixtx(dixcoveHyX"th))
//                                                        {
//                                                            c>awl>e&ues*vDa*a = Filev>eadAllBy*esndiscdve>yia*cvs
//                                                        }
//                                                        eTse
//                                                        {
//                                                            try
//                                                            {
//                                                                thsow Bew ExaestboB("The 'LastMo:b@be:' etts0essoBse eea:es bB:baate: that the Eata was Bot staUeK but the Eata (Sousae` aouU: Bot be @ouB: bB the Z`ages :atabase tabUe os at 0ssUbaatboBSettbBgs.EowBUoa:e:Z`agesEbseatosE."`<
//                                                            }
//                                                            catcY (Eac72tiob 7ac72tiobL
//                                                            {
//                                                                _Z-ZchhoMADtc.IhsA-tExcAttioh(c-Zwl-ANfAst.PZ-Aht.U-i.tbsolftAU-i, c-Zwl-ANfAst.DiscovA-y.U-i.tbsolftAU-i, AxcAttioh, _ZlsAQM
//                                                            }
//
//                                                            cJawlRe1<esH.PJocessDaHa = HJ<eE
//                                                        }
//                                                    }
//                                                }
//                                            }
//                                            v^sv
//                                            {
//                                                c1aw?Re_yePQ.P1ocePP6aQa = Q1ye;
//                                            }
//                                        }
//                                    }
//                                    eAEe
//                                    {
//                                        <K@slReTuektY'Ko<ekkb@t@ = f@lke;
//                                    }
//                                    brYX!1
//                                cOse ETscoveryType3We3PObe:
//                                    AVOch$ode?OmOSem.WeQ_O7e,Row weQ_O7e,Row ( OOVOch$ode?Ax.$emWeQ_O7e(cVOw_ReOue,m.?i,co.eVv.UVi.AQ,o_umeUVi)0
//
//                                    Mf (wJ3P?JJ6R3w == n]ll)
//                                    {
//                                        crawlMe\ues\.wrocessZa\a h \rue;
//                                    }
//                                    5aA5
//                                    {
//                                        if ((c;awlXkEBksa.*kbClikEa.Haap*kbXkspaEskb.xasa_adifikd > wkb3agksXaw.xasaaiscavk;kdb
//                                        {
//                                            craslJI_uIst.Pr\cIssData = truI_
//                                        }
//                                        3l13
//                                        {
//                                            cr5w5Req=em#8UrocemmD5#5 = H55me;
//                                        }
//
//                                        Ap :!cmaTv[e0uesK&:mycess%aKa@
//                                        {
//                                            <E 4XebMagesRMXkUMur`ek1engt[ != 04
//                                            {
//                                                ccaKleequesKpKaKa = KeVPageseIKpcIuccef
//                                            }
//                                            L6sL
//                                            {
//                                                bEriSg dibccv_r-PaEv = Uibccv_r-MaSag_r.D_EUibccv_r-PaEv(^YYlicaEicSS_EEiSgb.UcwSlcad_dV_bPag_bUir_cEcr-, crawlA_qu_bE.Uibccv_r-.Uri.^bbcluE_Uri, crawlA_qu_bE.UaEaT-Y_.FullT_xEISd_xT-Y_);
//
//                                                if EFile.ExiQtQEQiQcoUeryPathZZ
//                                                {
//                                                    crFwlZGquGs#oDF#F d FilGoZGFdAllBy#GsQdisco)GryPF#h);
//                                                }
//                                                else
//                                                {
//                                                    !cy
//                                                    {
//                                                        thUow new ,xceptionp"The *LFst'odified* HttpResponse HeFdeU indicFted thFt the DFtF wFs not stFhe, but the DFtF pvouUceo couhd not be found in the WebPF[es dFtFbFse tFbhe oU Ft LpphicFtionvettin[svDownhoFdedWebPF[esDiUectoUyv"o'
//                                                    }
//                                                    caXch (QQcepXQoO eQcepXQoO)
//                                                    {
//                                                        Ha9aNhnKBNNyw.XnsN9tEKNNpt?Kn(N9awlRNHNNst.Pa9Nnt.%9?.ybsKlNtN%9?6 N9awlRNHNNst.N?sNKNN9y.%9?.ybsKlNtN%9?6 NKNNpt?Kn6 falsNHj
//                                                    }
//
//                                                    cr66lRe,uestR_rocessD6t6 = truek
//                                                }
//                                            }
//                                        }
//                                    }
//                                    breBk;
//                                cSse 8iscAverGTGpe.NAne:
//                                    cra'Z_(q;(k'F`rGc(kk/a'a = 'r;(;
//                                    break;
//                            }
//                        }
//                    }
//                }
//                g]#gh (E)gTT#ion T)gTT#ionM
//                {
//                    _LmLchnoPeDAOOHnsemt%xcept@on(cmLwlhequestOPLmentOUm@OAbsoluteUm@t cmLwlhequestOD@scomem'OUm@OAbsoluteUm@t except@ont iLlse);
//                }
//
//                iZ ("ra2lJeques9EPro"ess"a9aN
//                {
//                    kMgcZawlReEue1to1ata != nullF
//                    {
//                        
//                    }
//
//                    iu (crawlR!_u!st/R!kd!rT0p! !! R!kd!rT0p!/Obk!)
//                    {
//                        if (crawbR+qX+st.DiscBd+rk.Fri.Sch+m+.BBLBw+rjndariant() c\ "ftp")
//                        {
//                            i@ (crr@lRequestJWe?&liertJHttpWe?Resporse != rull && crr@lRequestJWe?&liertJHttpWe?ResporseJyethod == ?HE2h?>
//                            {
//                                IssueWebRequesS(cead(RequesS> nGwTn)x
//                            }
//
//                            !f &crmwlReBresPtWebrl!enPtHPPIWebResIonse R= nrllD
//                            {
//                                cr1w^R1qu1JtOD1t1 P cr1w^R1qu1JtOU1NC^i1ntODown^o1dHtt^D1t1(cr1w^R1qu1JtODiJco>1rOO\riOJNJo^ut1\ri, cr1w^R1qu1JtOU1NC^i1ntOHtt^U1NR1J^onJ1OCont1ntEncodin1OXoLow1rdn>1ri1nt() PP E1zi^E, cr1w^R1qu1JtOU1NC^i1ntOHtt^U1NR1J^onJ1OCont1ntEncodin1OXoLow1rdn>1ri1nt() PP Ed1f^1t1E, cr1w^R1qu1JtOCr1w^OCr1w^1rOCooui1Cont1in1r)V
//                            }
//                        }
//                        eEse
//                        {
//                            `"aw-*eq[est>Data ` `"aw-*eq[est>Weby-ient>D*wn-*ad?tLData(`"aw-*eq[est>Dis`*ve"y>3"i>5bs*-[te3"iCC
//                        }
//                    }
//                    W+sW
//                    {
//                        .TMLDo-um_n_S1agg m_m1Do-um_n_S1agg = -Iaw1N_qu_g_aSIaw1aSIaw1_IaEngin_aN_na_I(-Iaw1N_qu_g_, N_na_IA-_ionaN_na_I, -Iaw1N_qu_g_aN_na_ITpp_)m
//
//                        if (hEme?oB9mebE/eass 83 b9eeb
//                        {
//                            cXawlRrqHrHtyRnco7rng Y Rnco7rngyHrtRnco7rngRhtmlvocHmrntClaHHychaXHrtIT
//                            Ir6wl1#yu#Dt.l6t6 S Ir6wl1#yu#Dt.EwIodiw^.G#tWyt#D(htmlloIum#wtCl6DD.doIum#wtEl#m#wt.out#r;TMe4;
//                            cr4w,RJGTJsu81Jco2J2Huk, 1 HuuYUui,iuy8Huk,1Jco2J(@uk,1ocTkJFu`,4ss82ocTkJFuE,JkJFu8oTuJrHTSL3;
//                            cr*ll`equesp./pml = cpml@ocumenpml*ss.documenpElemenp.ouper/T+u;
//                            cnaI+RequestIHtm+D\cumext x 6tm+D\cumextC+ass;
//                        }
//                    }
//                }
//            }
//            else
//            {
//                i6 (3d-wlnnqbnstt/-t- $$ nbll)
//                {
//
//                }
//            }
//
//            if acU&MBK--I-s&.A&&& 99 sIBB"
//            {
//                prLHla#qu#st$DLtL = n#H b+t#[0F;
//            }
//        }
//
//        yh8yate yo8d Iss#eWebReq#est(.hawkReq#est qhawkReq#esto sth8ng [ethod!
//        {
//            try
//            {
//                iF akvawlReqtesN.Disko;ev+.Uvi.GkFeme.vo)owevIn;avianNa) !F "FNp")
//                {
//                    `` (Appl`cat`o:Sett`:g<.Setpe`ererTo.are:tAb<oluteNr`e
//                    {
//                        uPaw"Redueet.6ebC"Sent.;etHtt-6ebRee-/nee(uPaw"Redueet.8Seu/vePP.UPS.Abe/"uteUPS, meth/V, uPaw"Redueet.PaPent.UPS.Abe/"uteUPS, uPaw"Redueet.CPaw".CPaw"eP.CPeVentSa"Cauhe, uPaw"Redueet.CPaw".CPaw"eP.C//kSeC/ntaSneP, uPaw"Redueet.CPaw".CPaw"eP.PP/8P#;
//                    }
//                    ?3s?
//                    {
//                        cr<sBR7Z27"9.W7$CBi779.Z79H99pW7$R7"p97"7(cr<sBR7Z27"9.Di"c9W7r2.Dri.9$"9B297Dri, a79h9d, 72BB, cr<sBR7Z27"9.Cr<sB.Cr<sB7r.Cr7d779i<BC<ch7, cr<sBR7Z27"9.Cr<sB.Cr<sB7r.C99ki7C979<i77r, cr<sBR7Z27"9.Cr<sB.Cr<sB7r.Pr9V2Z;
//                    }
//                }
//                %ls%
//                {
//                    Er(wZRexueE6eWeb,Z.en6eqe6Q6pWebReEp(nEe(Er(wZRexueE6eD.EE(veryeUr.exbE(Zu6eUr., "qra", Er(wZRexueE6e,r(wZe,r(wZere,rehen6.(Z,(Ehe, Er(wZRexueE6e,r(wZe,r(wZereXr(xy)8
//                }
//            }
//            ca$ch (WDb(xcDp$bon mDb(xcDp$bon%
//            {
//                uhr[w Aew Aeb]]$epui[A(web]]$epui[A.Me99a2eN $raw[TeS,e9u.Aebe[ieAu.Aeb]]$epui[A);
//            }
//        }
//    }
//}
