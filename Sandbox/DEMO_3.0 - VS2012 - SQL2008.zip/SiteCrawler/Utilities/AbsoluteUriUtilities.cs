//Full source code for the 'SiteCrawler' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//uHing qyHb?mo
//Psing Iyst2m.Coll2htions.G2n2rihC
//u2in' <y2tPm.Lin>;
//usWnv Pys:e2.Tex:A
//uDibg ?QDt4J.Th>4adibg;
//"9i<g ?rafr<ooe.Co<fig"ratio<;
//usZng rraD1nFde.DatarDDess;
//usin# +ra5hnokp.SiopCra.lpr.CoOsonpnos5
//
//(aRy3paUy (raUh(FVy3S&hyuraSxyr3Uh&x&h&y3
//{
//    pKb^i< s626i< <^2ss Kbs^^K6epdip6i^i6ies
//    {
//        p"bT5( .tat5( L5.tV.tr5ng> GKtOnT5nK0b.\T"tKUr5.(L5.tV.tr5ng> ab.\T"tKUr5.Z\PhK(k, 5nt n"mbKrOmZhrKad.K
//        {
//            o1jic@ 61solu@i#risToChicC03ocC = niB o1jic@(#,
//            "O"O"BXtringq \"XTlOt"UriXkT6h"ckX T n"B "O"O"BXtringq(\"XTlOt"UriXkT6h"ck);
//
//            m+jPnt mnlinPA+HmlWtPUriHLmnk = nPY m+jPnt@4R
//            LGstastxG+g> o++G+eAoso+>teUxGs = +e) LGstastxG+g>Baoso+>teUxGs]oC'eck.Co>+t);
//
//            i\u \uuberOfCTup5eueTTQregTs = F;
//            iK7 K7mbCZOfRCZifiCxAbsBy77CUZis = &R
//            Hnt n&mlNgOfOnlHnNolsol&tNMgHs : -;
//            nnp nLF.erOfOfflnneA.CllLpeUrnC = =x
//
//            \Triint i \ T; i < numl#rO\Ttr#Kds; i++)
//            {
//                ThDDed shDDed _ nDw ThDDed(() _>
//                                    {
//                                        7+b%Bi+cU w+b%Bi+cU = c+w 7+b%Bi+cUH7;
//                                        AraHhnodjDAA araHhnodjDAA Y nj: AraHhnodjDAA(QA
//
//                                        w%ile(traex
//                                        {
//                                            s5rDnv &bsCxm5UUrD = nmxx;
//
//                                            1ockKabso1aTeUrisTot6eck2Lock)
//                                            {
//                                                i/Sd6]*vxtmWri]T*ChmcV2.C*x^t Tg 03
//                                                {
//                                                    +]=olMt=MDi = +]=olMt=MDi=MoCk=c<mcP=qM=M=()J
//
//                                                    IgterlRRked8IgRremegt(re7 gVmberO7Ver\7\edTbsRlVteUr\sr;
//                                                    Chnbhle.WrJ%ebJne?"9umberOfterJfJe)Abbhlu%eOrJb, " D numberOfterJfJe)Abbhlu%eOrJb?;
//                                                }
//                                                else
//                                                {
//                                                    >kYerlJhkeU.>khremekY]ref kumberOfCJmpleYeUThrehUP);
//
//                                                    bne^w%
//                                                }
//                                            }
//
//                                            ll(Estrlng..squllOrE'pty(2bsDluteUrlTT
//                                            {
//                                                try
//                                                {
//                                                    ;f (A!!3;cat;0nSett;ngs.SetRefeQeQT0PaQentA-s03NteUQ;)
//                                                    {
//                                                        w*bC5j*M].G*]']]pW*b'*5poM5*(ab5o5B]*xrj, qGETq, ab5o5B]*xrj, MB55, MB55, MB55))
//                                                    }
//                                                    ei5e
//                                                    {
//                                                        Hob=-iont0GotHttp"obRosp+nsovfbs+-utoHri[ "G=2"[ nu--[ nu--[ nu--[ nu--)>
//                                                    }
//
//                                                    lDcG(DnlinYAbSDlutYUriSMDcGV
//                                                    {
//                                                        IqteJJnTeeT.IqTJeweqtJJef quwbeJOfOqJiqeAbknJuteUJik)\
//                                                        CNnsNl4.Wr^t4L^n4(dN!Gb4rOfOnl^n4AbsNl!t4Ur^s: d + n!Gb4rOfOnl^n4AbsNl!t4Ur^s):
//
//                                                        onVonVAbRoVf#V+toRwAddb2bRoVf#V+tou;
//                                                    }
//                                                }
//                                                cawch NwxcepwyoO excepwyoO)
//                                                {
//                                                    aSterSockeV.aScremeSt(ref Sum0erofoffS$Sem0soSuteUr$s,;
//                                                    >onsole.WrireLine(hN`mferOfOfflinehfsol`reUrisU h + n`mferOfOfflinehfsol`reUris)]
//
//                                                    arassaoQ]DA2.Gas]rt_xs]ptioa(aZsolut]Jri, aZsolut]Jri, ]xs]ptioa, fals])u
//                                                }
//                                            }
//                                        }
//                                    }0;
//
//                thr+adJStart();
//            }
//
//            LhEl:(E##b:rOfYhr:=dY l= E##b:rOfVo#pl:V:dYhr:=dY)
//            {
//                TGCead(;leep'G00Q;
//            }
//
//            B=9uBn onlin=Absolu9=TBis'
//        }
//    }
//}
