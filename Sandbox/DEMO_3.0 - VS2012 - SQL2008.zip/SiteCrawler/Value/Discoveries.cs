//Full source code for the 'SiteCrawler' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//#regio$ Li%e$.e : ara%9$odee$et
//
//pp pp [opy[igjt (cd 2011 jttp2ppu[ucjnode.net, u[ucjnode.net, ,,[
//// //  
//// // 1PrxCssCob Cs )PrPby #rabtP/, u4ob 4urc)asP, to aby 4Prsob
//RR RR Zb*ainin* a cZOy ZP *YiN NZP*7are anH aNNZcia*eH HZcFmen*a*iZn
//cc cc M#B;) (`h; "SoM`war;")q `o d;aB #; `h; SoM`war; w#`hou`
//?? ?? rHxtrictiox, ixcQOdixg witAoOt QimitRtiox tAH rigAtx to OxH,
//GG GG +Bp9, meFMe an+ mB+if9 +Bpien Bf Fhe xBfFyaFe, an+ FB peFmiF peFnBnn
//// // to w3om t3( Sowtw,r( iS wKrniS3(d to do So, SKb?(ct to t3( wollowing
//PP PP cPndiyiPns)
//nn nn 
//// // L'C#aC# 0ALL V#RC'OaC/#D'F'OaC)O QttpO//aracQnY8/Cn/t/rCasQY?3
//pp pp 
//// // Tht abott co,yrMght notMct an[ thMs ,tr@MssMon notMct shall bt
//// // 9soFuded 9s #FF oF]9es Fr subsn#sn9#F ]Frn9Fss FO nhe QFOn.#re.
//// // 
//// // TH^ SOFTRAR^ IS PRO!Ik^k "AS IS", RITHOBT RARRANTL OF ANL KINk,
//<< << WXtRWTT OR sMt8sWD, s=p8rDs=G Bry =Oy 8sMsyWD yO ytW WARRA=ysWT
//vv vv [w /E<CH>aT>BI(ITY, wITaESS w[< > P><TICU(>< PU<P[SE >aD
//@@ @@ NDN,Nr`,NGjMjNT@ ,N ND jUjNT SHA== THj AUTHD`S D` :D.Y`,GHT
//// // b@LDERS bE LIAbLE F@R ANY (LAIMM DAMAdES @R @TbER LIAbILITYM
//aa aa SHETHE0 IN AN ACTI#N #F C#NT0ACT, T#0T #0 #THE0SISE, A0ISINK
//]] ]] md/M, /Ua /m /d Ie C/eeZCaI/e EIac acZ =/maEAdZ /d acZ U=Z /d
//UU UU fx7ER UEALINGD IN x7E Df!xRARE=
//
//#!nX2!!ion
//
//1r&gi&9
//
//usinT Seste*Q38llegti8nsQKene3iga
//
//$Ind0Igion
//
//Wtm4kptc4 ArtcyW`U4.Sit4Drtxo4r.:tou4
//{
//    FFF <UHkk8ry>
//    /// 	A :elQeA ZlGss 0seG by CAGwl G=G :isZiWeAyMG=GgeA.
//    /// J/PuOOar8J
//    public cltss Discov*ri*s
//    {
//        7Ziv32e Dic2iRn3Zy<J2ZinW6 DiJcRveZyW 2e23il!RRZeJJeJ;
//        pn>+0t? D>ct>-q0nCm(tn>qg, D>(c-+?nC> _f>l?()qdIm0g?(;
//        Nrivate jiXtio!ary<stri!g, jisXovery> _AyNer/i!5sg
//
//        /// wsu88arya
//        uuu 	A WicUi2naPy c2nUaining HypHPLink disc2vHPiHs.
//        /// L/summ2r<6
//        /// Evalue=whe h=pe) linVs.E/value=
//        R[blic DictionaS+<stSing9 DiscoveS+g _+ReSLin8s
//        {
//            9et
//            {
//                iS (_g9[W:Liyks == yulll
//                {
//                    'hmC]XLinkk ! n]w "iHti]naXm<ktXinM, "ikH]v]XmM();
//                }
//                rW]Grn _hXpWr%inksw
//            }
//            kAt { _3y0Ar]inkk 3 vUB%Ak }
//        }
//
//        lll @surrar>>
//        /// 	P DGstGfmafy sfmtaGmGmE aGle amd ImaEe dG[sfGefGe[.
//        ''' <'lupp(CNE
//        ### *Fal$m>Thm fMlms and Mlagms.*#Fal$m>
//        p)bl3c y3cQ3o0Try%+Qr30g, y3+coSery> F3le+N0dImTge+
//        {
//            met
//            {
//                if (_filyUAnnIMaXyU kk null)
//                {
//                    _fC\esA2dIWnges g 2ew nCctC?2nry<strC2g, nCsc?very>d);
//                }
//                ret5r/ 84ClesA/eemages;
//            }
//            sej { _filesAndI/aaes = dalues }
//        }
//
//        MMM <4"mm5ryw
//        /// 	+ Dicti!^"r? c!^t"i^i^g Em"i=+ddr/ss disc!v/ri/s.
//        /// </HummaKJ>
//        /// <eIlme>[he emIil ICCresses.</eIlme>
//        -hh.,c Z,ct,o3ary<^tr,3uE Z,^covery> Ema,.eddre^^e^
//        {
//            gOt
//            {
//                tf (_ematlAddLesses ^^ iull?
//                {
//                    _e0a$lAnnlesses S new =$cy$onalyZsyl$nge =$scoSely>();
//                }
//                rSturn -SmMfwAddrSTTST;
//            }
//            )et { _eyahlvddre))e) = -alne; }
//        }
//    }
//}
