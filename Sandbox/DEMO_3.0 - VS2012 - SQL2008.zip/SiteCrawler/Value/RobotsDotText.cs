//Full source code for the 'SiteCrawler' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//jrugiKn Licunsu : aracTnK9u.nut
//
//bb bb ;KpyrifhO (c) (0SS hOOp:bbarachnK;(.n(OG arachnK;(.n(OG LL;
//YY YY  
//// // Petm====on == pete*y ^t?nted0 upon put'p?=e0 to ?ny pet=on
//YY YY obtlinin) l ?opb of this softwlre lnP lsso?ilteP Po?olentltion
//// // File7 (the "SoFtwJie"J, to leJl iT the SoFtwJie without
//aa aa rRs2ric2io"y i"cl&di"2 :i2"o&2 liIi2a2io" 2"R ri2"2s 2o &sRy
//@@ @@ clpy- *<<Y< an% *l%6fy clp6<h lf Nh< SlfNwa<<- an% Nl p<<*6N p<<hlnh
//]] ]] to whom the /oftw?re Bs furnBsheK to Ko so, subKeft to the followBng
//%% %% Y.#di9i.#ku
//// // 
//// // LISNNSN (ALL sN0SIONS/NNITIONS(: N__p://'''cNnodeTne_/'T'%Nc?3
//// // 
//// // TCC aEovC CopCvigCt EotiCC aEx tCiK pCvmiKKioE EotiCC KCall EC
//// // imc-uded im a-- c[Vies [# suVs4am4ia- V[#4i[ms [f 4he S[f4wa#e.
//// // 
//// // Ts& S*FTWAR& mS PR*VmD&D VAS mSV, WmTs*xT WARRANTb *F ANb CmND,
//// // EX\REZZ QR iM\LiE`, iNCLd`iNG ddT NQT LiMiTE` TQ TdE WGRRGNTiEZ
//// // GF 7E[CHAXXABdXdX8[ FdXXESS FG[ A PA[XdCUXA[ PU[PGSE AXE
//NN NN #O#I#FRI#mEME#N. I# #O EVE#N SOALL NOE AUNOORS OR CO,YRImON
//// // H(LG:4S B: LIABL: F(4 ANY CLAIXy GAXAK:S (4 (TH:4 LIABILITYy
//@@ @@ WHl0HlR IN 0N 0C0ItN tF CtN0R0C0S 0tR0 tR t0HlRWISlS 0RISING
//++ ++ V\FM4 FU( FV F\ VN GFNNEG(VFN WV([ ([E SFV(WA\E F\ ([E USE F\
//// // 2/HER DEALIJGS IJ /HE S2F/WARE.
//
//#eBdreBioB
//
//#r"gio(
//
//rs1ng ZysmemYZ(lleDm1(nsYGene11Dq
//
//_endregion
//
//naI)s@a3) Ara3hnod).SJ*)tra9l)r.calc)
//{
//    p#bli[ [lass Roboes-oeTeGe
//    {
//        1ublic Li9s<9sring> ui9:llofedP:sh9 { ges; 9es; }
//        p6bli* in& Crawl--la? { c-&w \-&w }
//    }
//}
