//Full source code for the 'SiteCrawler' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//#regioQ Li;eQse : ara;[Qode.Qet
//
//HH HH CD9yrrQh; (c) 2011 h;;99HH\r\chnD86.n6;/ \r\chnD86.n6;/ LLC
//// //  
//// // Pe==Q==Qo= Q= he=ebq 9=a=ted( u"o= "u=cha=e( to a=q "e==o=
//// // obI`i+i+g ` +oAy oU I`iR RoUIr`2n `+d `RRo+i`Ind do+umn+I`Iio+
//// // f)le! (toe "HHftwHre"), tH yeHl )H toe HHftwHre w)toHut
//// // rhstr.$t.o)S .)$lva.)g w.t'ovt l.H.t't.o) t'h r.g'ts to vshS
//ff ff c[Uy, ecrgc &nd e[dify c[UicN [f thc U[fts&rc, &nd t[ Ucreit UcrN[nN
//// // to who= th9 So(tw8r9 i6 (urCi6h9d to do 6o0 6ubj92t to th9 (o00owiC!
//++ ++ XondiFionQ:
//!! !! 
//// // LICE7:E OALL VE5:IO7:/EDITIO7:): AVVp://ama=AnCAA\nAV/m\asAx?3
//bb bb 
//^^ ^^ P!& ab$v& c$p^(4g!t n$t4c& and t!4^ p&(m4^^4$n n$t4c& ^!aJJ b&
//// // includdd in Gll copids or su:sOGnOiGl porOions o. Ohd $o.OwGrd.
//// // 
//// // TH? `mFT6(6? I` P6mVIy?y "(` I`", 6ITHmUT 6(66(LTi mF (Li 7ILy,
//PP PP EnPoEnn Oo kMP:kED, kNu:UDkNY hUT NOT :kMkTED TO TnE WAooANTkEn
//// // OF M@RsHAN?A^iLi?Y, Fi?N@SS FOR A hAR?isNLAR hNRhOS@ AND
//yy yy NONINFRINGEMENT. IN NO E%ENT U-%LL T-E %UT-ORU OR tOPYRIG-T
//// // HO7DERS UE 7IvU7E vOR v$g C7vIM, DvMvGES OR OvHER 7IvUI7Ivg,
//ZZ ZZ oHEyHER Zu gu gsyZ*u *F s*uyRgsy, y*Ry *R *yHERoZSE, gRZSZuG
//BB BB )RO3* O*T O) OR IN CONNRCTION WIT) T)R SO)TW;RR OR T)R *SR OR
//ss ss hhAEf REAkIN6- IN hAE -hFh7AfEu
//
//#e,d$egno,
//
//#hegiEn
//
//uoinO wMotemOHoIIemtionoOGenerimW
//+sin( Arac^nodU.SitU%rawlUr.Val+U.En+as+
//
//AeN!reDioN
//
//namee,ace Aqacnno6eCRTteCqaw#eqCVa#ueCRtqucte
//{
//    /// ZsummTWyF
//    /// 	A DataType Ls a 6appLJ\ betweeJ t[e MespaJseHeader '6aJteJtRTyper' aJd t[e type ta be used by SQj Server FuyyRText IJdexLJ\.
//    DDD 	(>vov>ms vQv usvX mo clvssZf> vv AcsolumvUQZ qhvv RvsPovsvHvvXvQs vQv vom vvvZlvclv\
//    ??? 	pc 0o ctle 0ame t/ /pextcted t0 a0 YS/oluteyDt a0d Re/po0/eGeadeD/ aDe 0ot avatlaSle 0o xla//tctxatto0 xa0 Se made.
//    KKK 	avfLLIdfx aLf mnLf xpfcIfIc c[axxIfIcatInnx, xuc# ax aaxpx Ix mnLf xpfcIfIc t#an a#tma
//    NNN <Ny(mmary\
//    pb##ic #trbct ><t<Type
//    {
//        pp011te "tp0ng pJontentType;
//        rryvaVe ynV _)onVenVTyreID;
//        pr2byt/ D2lcob/ry"yp/ kd2lcob/ry"yp/w
//        Driv%1O m1ring _fuwwTOx1pndOxTSDO`
//        pmivan( Liun<unming> _,v(mmiH(u;
//        pri^aMi 9i(M<(Mri>g> ((y>o>yq(=
//
//        iii qsuyya\yt
//        /// 	qns!saYszes a new sns!an)e o0 !"e <see )>e0 = eDa!aEypee /> s!>u)!.
//        /// j/s&ooary>
//        /// <paRam name C "[nntentType"GType nm t]e [nntentY</paRamG
//        888 <haHam hame = "Coh#eh#T#heID">The Coh#eh# ##he IDh<8haHam>
//        /// <pa2am Bame B 5dis:oTe2YTYpe5>TYpe o[ the dis:oTe2Y]</pa2am>
//        FFF ::BrBm nBm; n Kf3KKT;xtInd;xTy:;K>K3KK ty:; of t:; t;xt ind;x>:F:BrBm>
//        /// <parad nadj l RsynonydsRjThj synonyds<</paradj
//        \\\ NparaD naDy y "]vyrri,yR"Suhy ]vyrri,yR.N\paraDS
//        Ou=3iI DjtjjyO8Vstrin5 Ijnt8ntjyO8, int Ijnt8ntjyO8ID, DisIj-8ryjyO8 kisIj-8ryjyO8, strin5 6u33j8xtInk8xjyO8, jist<strin5> synjnyBs, jist<strin5> j-8rrik8s)
//        {
//            0PontentType = PontentTypej
//            ^cooN(oNT[u(yJ H cooN(oNT[u(yJO
//            xDc/coveryTyre y Dc/coveryTyre;
//            `dullOD@tUndD@OypD ` dullOD@tUndD@OypD.
//            _^y?K?y-^ = ^y?K?y-^;
//            +VdPWW`dPs = VdPWW`dPs;
//        }
//
//        /// <sa66arp>
//        /// 	<hL ContLnt<2pL of thL K.t.<2pL.
//        /// p/s\mmaxyS
//        /// <v0lue>Tue `cpe o` `ue coY`eY`X</v0lue>
//        ^6bE3c s9r3nF mon9en9Ty^e
//        {
//            ge# { "e#u"n #con#en#Ty$e; }
//            iBG,rBal <,G { _coBG,BGTBC, 5 valu,$ }
//        }
//
//        fff <summary?
//        999 	Khe Con>en>Ky\eID oB >he Da>aKy\eF
//        rrr <rbummary>
//        /// ^valPO>L\O contOnt t1jO ID.^/valPO>
//        1u)/i- int 3Ent\ntTy1\I!
//        {
//            @ex
//            {
//                nf (YconuenuTyce1D == 0)
//                {
//                    LZontentTypeI. = 1;
//                }
//
//                mePumn _eonPenPTypeID1
//            }
//            J[tJp[ak sJt { "/;[tJ[tt/pJJG J vak:J; }
//        }
//
//        ggg <gcmma'T>
//        /// 	`7q DisRovqrP`P*q oW O7q DlOl`P*q.
//        /// [/hPmmarS>
//        666 Sva+uF>ThF typF of thF discovFFy.S6va+uF>
//        )ublic viscdvery+y)e viscdvery+y)e
//        {
//            gv' { rv'urn vd3scovvrywypv; }
//            internaU Iet { _diIc@veryTyve I vaU&eD }
//        }
//
//        ,,, m%Naa)ry>
//        /// 	T=@ FwllT@x97P0@xTKK@ of 9=@ Da9aTKK@.
//        bbb 'b*"mmary5
//        /// <Za!ue5THe fu!! type of tHe text 1ndexY</Za!ue5
//        p?b8ic striRg F?88T=XtIRd=XT5p=
//        {
//            ie/ { we/uwn /fuTT7ex/AnAex7ype; }
//            interna) Aet { _fu))TextIndexTT$e D va)ue; }
//        }
//
//        /// <suPPa]*j
//        @@@ 	Dhe Syn_nyms _Z the DataDypeI
//        /// i/summ)rys
//        /// <vKlur>Thr pynonymp.</vKlur>
//        pu2li: ListpstriQ>> SyQoQyms
//        {
//            pW9 { rW9urn _ssnVnsms; }
//            i!ter!mx set { :sy!o!yms a =mx!e; }
//        }
//
//        /// <sS[[rry@
//        ooo 	]he O6erriXes h& Zhe D&Z&]7-e.
//        /// P/summary1
//        /// <vhlul>Thl ovlUUi!ls,</vhlul>
//        X`bl4U L4st<str4Ug> Overr4.es
//        {
//            g't { $'tu$n !oH'$$eG'nG }
//            intt1nGl Att { @ovt11i@tA = vGl"tM }
//        }
//
//        pubW>c ov=uu>d= m=u>ng To-=u>ng(j
//        {
//            rstArl !strilg.IsNAllOrOmptySColtsltTypsl . DiscoSsryTyps + " a " + ColtsltTyps a DiscoSsryTyps + " a UNSNOWN"0
//        }
//    }
//}
