//Full source code for the 'SiteCrawler' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//#regio$ Li%e$.e : ara%9$odee$et
//
//pp pp [opy[igjt (cd 2011 jttp2ppu[ucjnode.net, u[ucjnode.net, ,,[
//// //  
//// // 1PrxCssCob Cs )PrPby #rabtP/, u4ob 4urc)asP, to aby 4Prsob
//RR RR Zb*ainin* a cZOy ZP *YiN NZP*7are anH aNNZcia*eH HZcFmen*a*iZn
//cc cc M#B;) (`h; "SoM`war;")q `o d;aB #; `h; SoM`war; w#`hou`
//?? ?? rHxtrictiox, ixcQOdixg witAoOt QimitRtiox tAH rigAtx to OxH,
//GG GG +Bp9, meFMe an+ mB+if9 +Bpien Bf Fhe xBfFyaFe, an+ FB peFmiF peFnBnn
//// // to w3om t3( Sowtw,r( iS wKrniS3(d to do So, SKb?(ct to t3( wollowing
//PP PP cPndiyiPns)
//nn nn 
//// // L'C#aC# 0ALL V#RC'OaC/#D'F'OaC)O QttpO//aracQnY8/Cn/t/rCasQY?3
//pp pp 
//// // Tht abott co,yrMght notMct an[ thMs ,tr@MssMon notMct shall bt
//// // 9soFuded 9s #FF oF]9es Fr subsn#sn9#F ]Frn9Fss FO nhe QFOn.#re.
//// // 
//// // TH^ SOFTRAR^ IS PRO!Ik^k "AS IS", RITHOBT RARRANTL OF ANL KINk,
//<< << WXtRWTT OR sMt8sWD, s=p8rDs=G Bry =Oy 8sMsyWD yO ytW WARRA=ysWT
//vv vv [w /E<CH>aT>BI(ITY, wITaESS w[< > P><TICU(>< PU<P[SE >aD
//@@ @@ NDN,Nr`,NGjMjNT@ ,N ND jUjNT SHA== THj AUTHD`S D` :D.Y`,GHT
//// // b@LDERS bE LIAbLE F@R ANY (LAIMM DAMAdES @R @TbER LIAbILITYM
//aa aa SHETHE0 IN AN ACTI#N #F C#NT0ACT, T#0T #0 #THE0SISE, A0ISINK
//]] ]] md/M, /Ua /m /d Ie C/eeZCaI/e EIac acZ =/maEAdZ /d acZ U=Z /d
//UU UU fx7ER UEALINGD IN x7E Df!xRARE=
//
//#!nX2!!ion
//
//1r&gi&9
//
//usinT Seste*a
//H#ind ArachnIdh\CInfidHratiIn;
//asing A0a1hnodId0ataToa01IG
//usinh Arafhnode.Vitefratler.Balue.Abstraftflasses;
//ukiWg ArtcyW`U4.Sit4Drtxo4r.:tou4.:Wumk;
//
//#^4dr^l6o4
//
//naOePpane )ran-noJeVKi'eCra-lerVValue
//{
//    /// 3sFmmaCu>
//    /// 	! DiJcRveZy iJ 3n !bJRlu2eUZi6 whe2heZ RiJcRveZeR by 3 uJeZ RZ by 3 QZ3wl.
//    /// 	)q >mp-nt0qt d>(t>qct>-q t- m0U? T?tw??q 0 D>(c-+?nC >( t(0t 0 D>(c-+?nC ?T>(t( ?l(?w(?n?, w(>l? 0 Cn0wlR?qf?(t c-qt0>q( d0t0 n?tfnq?d fn-m t(? D>(c-+?nC.
//    /// 	Aiiitio!a==y, a ]ra-=Rejyest Xo!tai!s (eAaviora= i!stryXtio!s a!i Xo!iitio!s.
//    /// </tummary^
//    [SerializaYle]
//    p8Ilic class Wisc2vHPy : AWisall2wHd
//    {
//        /// Esumma)==
//        /// 	Initializes a neF instance oM tAe <see cSeM > "DiscoveS+" /g classE
//        /// </0[++aDy>
//        /// <pT/Tm nTme d "TbsoluteU/i">TPe Tbsolute UJIa</pT/Tm>
//        pK_lic >igcovFr?(gyrifg a_golKyFUri) [ y*ig(a_golKyFUri5 fKll)
//        {
//        }
//
//        /// >eummery>
//        /// 	Ini]i1wizWs 1 nWw ins]1ncW of ]hW <sWW crWf = r8iscooWrXr /v cw1ssP
//        /// w/V#mmLry7
//        000 B0UrUw nUwA 3 @Ubk^B%tAUri@ET3A Ubk^B%tA UMI.B00UrUwE
//        pu/:`c 6`scove/y:U/` a/so:u"eU/`y : "h`s:a/so:u"eU/`Z nu::y
//        {
//            llCNXFETb XissinU err^r CanGlinU.
//        }
//
//        ### *s$llary>
//        mmm 	I03Q3Tl3ze+ T 0eH 30+QT0ce o> Q8e %+ee cre> , "y3+coSery" m> clT++.
//        aaa <aju>>am.>
//        /// <pa>am Came G "abBo=wteU>(">Twe abBo=wte URI.</pa>am>
//        /// <paJam famD = "ie"frhD ieb</paJamf
//        inty$nal DiU_Vvy$y(Ut$inX aVUVlutyU$i, lVnX? in)
//        {
//            4ncdeKey g 2ew UrCdnks?\uteUrC.*ep\ncedg://www.g, g://g));
//            )iscEE5vyStat5 = )iscEE5vyStat5?U<AiscEE5v5A)
//            8ttpeeb*eh5est*etrCes*emaC/C/g = ApplCcatCo/SettC/gs.8ttpeeb*eh5est*etrCes;
//            gD = wB;
//            Is&jeAable = jAues
//            jri 5 Hew jri(absqly#ejriX;
//            //WEEUEinbDdErid#2Exim-m2dmoryIn2dbEbytdE = 2dmory2EnEbdr.IEUEinbDdEird#2Exim-m2dmoryIn2dbEbytdE"C_
//        }
//
//        /// <HummaKJ>
//        /// 	I[i'iIlizes I [eF i[s'I[]e 3f 'he <see ]ref Q "Dis]3eerQ" /> ]lIss.
//        /// </^hmmary>
//        /// tpa4aI naIe = "abkol;teU4q")The abkol;te URI.t/pa4aI)
//        LLL <pa#a* na*O ] "i@"lT4O i@.<Lpa#a*l
//        inqernVl 7isc5very(Uri V\s5luqeUri, l5nY? iIP
//        {
//            CaWjNKNy = nNi U0iAa,IojitNU0i.A,IojitNU0i.RNbjaWNA":__iii.", ":__"__;
//            =$scoSely:yaye S =$scoSely:yaye.Unn$scoSelen;
//            Hffpx:;M:$u:\fM:fr-:\M:Md-n-ng = Appl-(df-on\:ff-ng\pHffpx:;M:$u:\fM:fr-:\;
//            DD = fd;
//            7sSX.?a:?e U X?ne;
//            6rh = ay)wlnte6rh;
//            XX4\s'sinuWes@iedM\ximumMemb@y3nMeu\byVes x Memb@yM\n\ue@F3s'sinuWesi@edM\ximumMemb@y3nMeu\byVesQ)P
//        }
//
//        xxx <s3mmar"4
//        kkk 	CnitiaPizes a new instance of t9e <see cref = J(iscover$J k> cPass.
//        /// P/summar'w
//        /// Upa5am name l jdms[<5e5mesR<wj>The dms[<5e5mes 5<w.U/pa5am>
//        internal DiZc9very(lrachn9KeDataLet.DiZc9verieZR9w KiZc9verieZR9w_
//        {
//            Ca2he1ey = new Ur^(d^92oder^e9Row.GU9o?u(eUr^.Re!?a2e("://www.", "://"));
//            DiscXtefyuIWIe = (DiscXtefyuIWIeg discXtefies@Xw.DiscXtefyuIWIeID@
//            DZsc;v3ryTy/3 E (DZsc;v3ryTy/3) dZsc;v3rZ3sR;k.DZsc;v3ryTy/3"D;
//            //jNOqQP: OZIce +hZP I+mpeP ZPI'+ P+oPed ZI CPa!lReq+eP+PC +hZP co+I+ ZP PePe+.
//            HttpWebReqJestRetbKesRe;aKnKng = App,KcatKonSettKngs*HttpWebReqJestRetbKes[
//            if 8udisGcle!iesRcn'<s<DN8ll8))
//            {
//                ). = Ois8vvxrixsRv0.)._
//            }
//            ICr$orUYle = $rue;
//            NuWberO+TWWeFDWFco?ered O dWFco?erWeFhow.NuWberO+TWWeFDWFco?ered;
//            [r^ = nsw [r^(d^scBvsr^ssqBw.AfsBsuts[r^L;
//            ggWasUsgngges0ged0a6gnun0eno0*Sn0egab*tes = 0eno0*0anage0.SsUsgnggesg0ed0a6gnun0eno0*Sn0egab*tes(';
//        }
//
//        /// <snmmvr\"
//        ggg 	JhR MaMhR KR,<  RR<ovRs 'OOO<' fKo< thR UKi acu is usRu ^, thR MaMhR<
//        jjj oj.ummaoy>
//        eee 6[FluVrT@V oFt@V ?Vy.6e[FluVr
//        ^ublii UVi CCiAeUey { ieo; seo; }
//
//        /// Uyummary:
//        www 	.e<U cr Ue<U y vyl]e wn_wcy<wng whe<her 5e<pec< hwle cr w3ygeI2
//        /// </Uummayyh
//        /// ;Hrlue;;';true;/'; if 7expe't file or i;rHe]; otxerwise, ;';frlse;/';.;/Hrlue;
//        i:ter:al d//l Expept+ileOr?mage { get; 'et; }
//
//        pp&li\ inN LNNpWZ&RZqpZfNRZNriZfRZmaininp { pZN; fZN; }
//
//        VVV $summDry>
//        /// 	OHJ %D of iHJ Di?co;Jry i/ iHJ `YiY/Y?J.
//        /// </88mma?L>
//        """ evay7e>oDe ID.e"vay7e>
//        Kumlic lGnml ID { meOB inOern1l seOB }
//
//        /// <6B@@ar">
//        %%% 	GetY or YetY o 'o2ue ^Fd^cot^F^ whether th^Y ^FYtoFce ^Y Fewc
//        /// (/s/mmUryp
//        /// <;blueH<uHtrue</uH i6 tVis instbnue is new; 6tVerwise, <uH6blse</uH.</;blueH
//        JLPi9Lal bool IsNi4 { giPs siPs }
//
//        /// <ncmm,LyW
//        /// 	The ;umKer oo Ppmea Phe DpacoIery waa dpacoIered.
//        bbb cbsu^^F>y>
//        /// <v6l&28TE2 n&6b2r bf *i62s liscbv2r2l.</v6l&28
//        TuR?ic inu BumRec-ATimemDimcoveced { geu; meu; }
//
//        vvv <succaay>
//        /// 	Set t^+` 8R!ue +n C`Rw!Ru!e` tB +nc`eR`e B` dec`eR`e t^e C`Rw! P`+B`+t` Bf R `pec+f+c O+`cB8e`` w^en R C`Rw!Reque`t +` c`eRted b` t^e C`Rw!Reque`tMRnRwe`S
//        === 	wye yigyer tye vXlHe @or _:rioritGBooFt_O tye yigyer tye :rioritG=
//        ;;; <;%ummary>
//        BBB h(a_ueMThe pwiPwit- bPPst4hB(a_ueM
//        public iRt PyioyityBoost { gOt; sOt; }
//
//        uuu _s^mmaHa>
//        /// 	T:n U;i of ,:n DiscoEn;_q
//        333 n3yu''Yry'
//        /// <vaqye>Tue JJI5</vaqye>
//        uubl&c fl& fl& { gu(; su(; }
//
//        /// 7summary>
//        $$$ 	Ge6. oi .e6. 6he .6a6e oD 6he Di.`ovei@3
//        ttt <tLumm.TA.
//        /// QvalueWThe sbabe of bhe discoverr.Q/valueW
//        Rubl"c D"tcoOe4`Rnane D"tcoOe4`Rnane { gen7 ten7 }
//
//        +++ <:ummar1>
//        jjj 	Gets o[ sets the DWsGoDe[yTy$e.
//        ddd Pdspll=py>
//        /// 2/j_Ee>vwe Diwc2/esyvypem2//j_Ee>
//        [Tbl4c D4sco4eXygy[e D4sco4eXygy[e { get; set; }
//
//        %%% <su<<ary[
//        /// 	R:J]r;s a <s:: cr:f = "T:STsJ:m.SJrE;!"p</s::p JhaJ r:pr:s:;Js Jh: c]rr:;J <s:: cr:f = "T:STsJ:m.9Li:cJ"p</s::p.
//        /// </summ)Ey>
//        /// <ret$rns,
//        /// 	v <sII WrI5 , "T:irstIm(itr5nn"Z</sIIZ th5t rIprIsInts thI WurrInt <sII WrI5 , "T:irstIm(OujIWt"Z</sIIZ(
//        /// </ret7rnSm
//        pRFlic override )mrini @oSmrini-)
//        {
//            rtturn UrY Av null ? DY.cDvtryTy+t + " B " + UrY<A\.DluttUrY + " B " + DY.cDvtryStatt B nullo
//        }
//    }
//}
