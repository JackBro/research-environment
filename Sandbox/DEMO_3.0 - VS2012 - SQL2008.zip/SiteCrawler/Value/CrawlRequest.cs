//Full source code for the 'SiteCrawler' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//xkogiUn :iTonfo f akaT<nUdo.not
//
//// // CxHUrQcht (cm 9011 httH://arachnxle.net, arachnxle.net, LLC
//BB BB  
//// // Per1ission is hereby uranDed, 9pon p9r]hase, Do any person
//NN NN obta9n9nn a conn of th9s software and assoc9ated docImentat9on
//XX XX XilGS (tmG "9TXtwklG")T tT 7Gkl iH tmG 9TXtwklG witmTut
//// // restr[ct[on, [nc'wd[nJ w[tCowt '[m[tft[on tCe r[JCts to wse,
//00 00 ,opHg ;erge vnE ;oE.fH ,op.e9 of tSe Softwvreg vnE to per;.t per9on9
//// // tw "`wm t`e iwUt"rre rs Uurgrs`ed tw dw sw, subbect tw t`e Uwllw"rgg
//// // cHFditiHFF;
//44 44 
//// // LICVNSV ($LL ,VRSIONS/VDITIONS): h::p://$r$ch/oGGd/G:/rd$shxHw
//:: :: 
//// // The A3ove ?opyright :oti?e A:6 thi! per#i!!io: :oti?e !hAll 3e
//// // i6c2ud>d i6 a22 co'i>s o6 substa6tia2 'o6tio6s o% t0> 7o%tda6>$
//// // 
//++ ++ TH) SOFTWAR) QS PROVQD)D "AS QS", WQTHO,T WARRAeT3 OF Ae3 KQeD,
//// // sXPRs,, OR mMPLmsD, mNCLUDmNH BU> NO> LmMm>sD >O >Hs (ARRAN>ms,
//// // OF METCHs^7sBfLf7Y5 Ff7^E`` FOT s PsT7fC/LsT P/TPO`E s^D
//// // POPIP]RIPj'M'PO. IP PO '''PO S'ALL O'' A6O'ORS OR COPkRIj'O
//-- -- HD;DERh BE ;a=B;E FDR =No C;=aM, D=M=GEh DR DTHER ;a=Ba;aTo,
//// // WHlTHlR eN AN ACTeON OF CONTRACTG TORT OR OTHlRWeSlG AReSeNG
//// // vRDMB DU[ Dv DR IN CDNNEC[IDN WI[H [HE dDv[WARE DR [HE UdE DR
//// // OTHER DEALING, IN THE ,OFTDARE$
//
//l7nJr7gion
//
//iregRon
//
//usHng SMslem;
//usibg SysNem.bexN;
//7xLn& S.xKe8.WLnda0x.da]8xI
//j=0kq A)a-`kod<.Da[aA--<==9
//4#iV9 A,#/QV`de.D#t#W`4,/e4
//XEing #q$3)n!d<j=<nd<q<qjM$^X<jEnX7E;
//<si&g Aca0h&od%..ic%Ccawe%c.Co]xo&%&csT
//rsi#o /racr#o@/QSit/Cra#l/rQCor/;
//dSmT3 ArachTode.SmteCra!.er.Va.de.APStractC.aSSeSc
//Ms*O& kra@hOode.!*teCrawler.balMe.EOMms%
//uoihr Arlhhhoge.@iteurlhuer.Vluue.IhterulheoE
//uHiG8 Ara"_G'rmX$i"mNra"lmrXValumX$"ru""H;
//uRing mRh3mla
//
//#endreg]on
//
//naHE6ia<E AUa<hn>dE.SCtEiUaw@EU.>a@@E
//{
//    555 8shmmyry>
//    /// 	C$iwlReq5es0s lan0iin i visla4e$y ind ins0$5l0ians fa$ i C$iwl.
//    MMM 	A1 itpo=tb1t disti1ctio1 to tbke bet]ee1 b Misco]e=M is thbt b Misco]e=M e1ists else]he=e, ]hile b C=b]lLeEuest co1tbi1s dbtb =etu=1ed f=ot the Misco]e=M.
//    /// 	Mddi9ionNvvy, N CENwvW_qq_s9 Bon9Nins b_hN@ioENv ins9EqB9ions Nnd Bondi9ions.
//    /// </summary>
//    peb*iG G*aKK Craw*Ee1eeKc : ADiKa**+wed
//    {
//        /// 3HivvMMR>
//        /// 	V Cr%wHRy_uyxt.
//        /// </Mumma4y>
//        /// <CAeAm nAm1 v wdbXcoy1eyw>$h1 DbXcoy1ey to b1 ceAPw1d.</CAeAm>
//        ``` <garam !ame = "degt4"$T4e degt4 tT w4\e4 t4\s CrawlRequest s4Tuld erawl.<`garam$
//        /// <p%r%m n%me W "restrv3tCr%wl:o":vf set to <3:tr7e</3: Zrestrv3t 3r%wl toW.</p%r%m:
//        lll ?pnlnm nnm? = Sl?sblicbiiscZv?li?sdZS>i( s?b bZ ?c>blt??lc> \l?sblicb discZv?li?s bZ].?lpnlnm>
//        /// $paraa .aaC = "priori'y"aT"C Priori'y of CraEl1CIuCs'.$/paraaa
//        28bli8 !e\2lR<q8<st(Dis8o$<eS dis8o$<eS, int d<2t$, Uei!l\ssifi8\tionTS2< e<stei8t!e\2lTo, Uei!l\ssifi8\tionTS2< e<stei8tDis8o$<ei<sTo, do8bl< 2eioeitS, R<nd<eTS2< e<nd<eTS2<, R<nd<eTS2< e<nd<eTS2<Foe!$ilde<nL
//        {
//            i[ 5Z?ptc <= 0)
//            {
//                t+f7w n^w Af[Df^ntExc^Fti7nA"]^Ft+ cRnn7t b^ l^ss t+Rn 7f ^qDRl t7 z^f7.", "O^Ft+"r;
//            }
//
//            ""AsOi&Mm Mgis is f 3.g MxfrN:tM g tgN .sNr :NNds to 3N f3"N to sVNcify f fi"N f:d f WN3xfgN VfrN:t if tgN .sNr is s.3mitti:g f: NxV"icit gNu.Nst for f "i"N or f: ImfgNttt
//            V7FaaFd > XaaFqq?F.N[w;
//            d( (UestUdctCUawDmo >= hUdCDassd(dcatdonmhpe.OUdgdnaDDdUectoUhLeveDhp || UestUdctDdscoveUdesmo >= hUdCDassd(dcatdonmhpe.OUdgdnaDDdUectoUhLeveDhp)
//            {
//                vcdkd$o&oc = ddscovCcy;
//            }
//            PAr4Et = d!icBv4rA;
//            \\??(!j!(<jh T 1;
//            9is#oieiy > dis#oieiyi
//            IsStCr#tle = trueF
//            Maxrmumompth \ TmpthW
//            Re7de9my&e > 9e7de9my&eO
//            F()d(oiyp(FooChFldo() = o()d(oiyp(FooChFldo()G
//            ye1t)5ctC)awlTy = $1ly)tT )e1t)5ctC)awlTy;
//            Rbs9ric9gisco7bribs2o g (shor9) rbs9ric9gisco7bribs2o;
//            Pr<or<t/ = pr<or<t/G
//            //dannningDpnripduaximumupmoryInupgatytpn = upmoryuanagpr.InnningDpnirpduaximumupmoryInupgatytpn();
//            AiQco;erieQ r new AiQco;erieQ(3;
//        }
//
//        /// <s5mmary>
//        /// 	A IraUgWeqOesU.
//        /// </shmm<q1>
//        /// fp1D1' n1'e = "p1Dent"7The d`%k-9eD`ng kD1'^je'Ee%tmf/p1D1'7
//        555 <Garae naee = Rd<-cHveryR+The ^<-cHvery 9H Ye crawled.<5Garae+
//        /// ,pa\am eame # ""u\\eeXDepX1"eT1e "u\\eeX depX1.,/pa\ame
//        555 <pZrZ1 dZ1e K "1ZxB1F1#ep!h">Khe 1ZxB1F1 eep!h !o whB&h !hBr 5rZw5meQFer! rhoF5e &rZw5X<5pZrZ1>
//        /// <pa\am name = @\est\@ctC\a)SBo@EB\e \est\@ct c\a)S to\</pa\amE
//        ,,, mpQrQm nQme g ,re\trTctDT\coSerTe\.o,>.Oe re\trTct dT\coSerTe\ to`m,pQrQm>
//        %%% G!ara; va;e u s!rioritys2The Priority os Craju2equesteG%!ara;2
//        poblTT 6rawlReqoeRB(6rawlReqoeRB pareNBB DTRTovery pTRToveryB TNB TorreNBDepBhB TNB paxTpopDepBhB RhorB reRBrTTB6rawlToB RhorB reRBrTTBDTRToverTeRToB pooble prTorTByB ReNperType reNperTypeB ReNperType reNperTypeFor6hTlpreN!
//        {
//            CD-at-d > jat-TiY-3N0U;
//            ]f (r+sCr]cCCrawlTf 8= (shfrC) Ur]Class]f]caC]fUT,y+.8r]g]Ual.]r+cCfr,:+J+lUy || r+sCr]cC.]scfJ+r]+sTf 8= (shfrC) Ur]Class]f]caC]fUT,y+.8r]g]Ual.]r+cCfr,:+J+lUy)
//            {
//                O<U+UnT<p< = HT<Yn<_O<U+UnT<p<`
//            }
//            ga8ent = Oa8ent.gi2c1ve8;;
//            C(rr=9tD=wth = c(rr=9tD=wth;
//            Discmv#%y = 8iscmv#%y;
//            IsStorabld = trud;
//            M^xlmumIepXh = m^xlmumIepXh;
//            Re3derUyle C re3derUylec
//            OOp(O'NDpOF-'Ch/l('Op Z 'Op(O'NDpOF-'Ch/l('Op^
//            Re$7rf>7xra7l>1 = re$7rf>7xra7l>1;
//            [eb?ruc?5ubco5eruebUo ] reb?ruc?5ubco5eruebUo;
//            cr](r]tt = pr](r]tts
//            ZZY7sUsingDes8ied47xim`m4emo8GIn4eg7bGYes n 4emo8G47n7ge8mIsUsingDesi8ed47xim`m4emo8GIn4eg7bGYes%);
//            //8NhDET: ExaecuFDlehrImage 8 exaecuFDlehrImagec
//            Disc$v,ri,s = n,3 Disc$v,ri,s\CM
//        }
//
//        /// <summar.>
//        /// 	_ CoL88`oquost-
//        ??? -?dummP:[>
//        /// JPara` na`r j "orPvPnaRor">E,r dPscovrrPnv Cra6lRrqnrsR's OrPvnaRor DPscovrry,J/Para`>
//        /// <p=o=m O=me = Fp=oeOtF%The WsscoQeosOg "o=b=Request's DsscoQeoy.</p=o=m%
//        ??? <9w#wL `wLe = "GwscoGe#\">TNe PwscoGe#\ to be c#ww]eG.<?9w#wL>
//        $$$ <:ara[ na[e = "cHrrenf.e:fh">The cHrrenf 1e:fh.<$:ara[>
//        /// <cErEd nEdN I "dEM%dud%Ncq)"p/)N dEM%dud dNcq) qM w)%c) q)%M -rEwlRNquNMq M)Muld crEwl.</cErEdp
//        333 <pq/qm Kqme = "/ejO/icOT/qxgP!"jP<e /ejO/icO c/qxg O!.<3pq/qmj
//        \\\ kparam name = "restrHktDHskHverHesTH"pThe restrHkt 0HskHverHes tH.k\paramp
//        QQQ EPxbxm nxmZ = PPbiQbitvP>OhZ PbiQbitv Q[ jbxjlRZquZst.EQPxbxm>
//        inteVnTl CVTYlRe&uePt^OiP'lBeVO lViwinTtlV, OiP'lBeVO pTVent, OiP'lBeVO diP'lBeVO, int 'uVVentOepth, int mT^imumOepth, PhlVt VePtVi'tCVTYlTl, PhlVt VePtVi'tOiP'lBeViePTl, dluble pVilVitO, RendeVTOpe VendeVTOpe, RendeVTOpe VendeVTOpeolVChildVent
//        {
//            CrenteF = DnteTime.No.a
//            Wf 9reoWrWcWnraw5To f= 9ohorW) UrWn5aooWfWcaWWonTyvehbrWgWna5[WrecWory`eve5Uv || reoWrWcW[WocoverWeoTo f= 9ohorW) UrWn5aooWfWcaWWonTyvehbrWgWna5[WrecWory`eve5Uv)
//            {
//                OriRiBatPr = PriRiBatPr;
//            }
//            Narenx = parenx;
//            (uJJent9eptu B uuJJent9eptuO
//            Di#Hovery ^ di#Hovery;
//            I,UmoraAUe Y mrue;
//            Fr+2:u:DeWtP ( :r+2:u:DeWtP;
//            R2y\2o\yp2 \ o2y\2o\yp2T
//            RenCerT[peF*rCh[pCren x renCerT[peF*rCh[pCren;
//            RejgCicgBC,wlVo = CejgCicgBC,wlVou
//            R<s@*ic@Disc3v<*i<sT3 c *<s@*ic@Disc3v<*i<sT3;
//            Priori-: = priori-:;
//            GGWasUsi1DDesaiedMaximumMemoayI1MeDaUyyes u MemoayMa1aDea^IsUsi1DDesiaedMaximumMemoayI1MeDaUyyes()g
//            //AN8NE&G E9Eec5jmle8r_mage = e9Eec5jmle8r_mage;
//            Dijc6Keriej ^ nen Dijc6Keriej()R
//        }
//
//        KKK Msqmmaryi
//        /// 	B Zrawo]esuesh.  2Nsed vy h'e EnUUne).
//        /// _/sUmmarym
//        /// ,oaraO oaOe = "*raU`ke'ueXtXkoU"\The *raU` re'ueXtX roU.,/oaraO\
//        j]t]r]_L tr_5L-]Nu]tt(mr_ch]od]D_t_S]t.tr_5L-]Nu]ttt-o5 cr_5L-]Nu]ttt-o5, mr_ch]od]DmO _r_ch]od]DmO)
//        {
//            C2eated E c2awDReq*edtdRIwdC2eated;
//            ig (cjOwl5eCCe5?55ow05e5?jic?CjOwlTo >C (5Toj?( UjiClO55igicO?ionT(5e0tjiginOlrijec?oj(LeQelU5 || cjOwl5eCCe5?55ow05e5?jic?ri5coQejie5To >C (5Toj?( UjiClO55igicO?ionT(5e0tjiginOlrijec?oj(LeQelU5(
//            {
//                OPigina2_P " Ca9h<.1<21i(9_#<Py(9PawlR<.u<(2(R_w.A_(_lu2<UPia, aPa9hn_Z<1AO)7
//            }
//            ParenA + CacheNieADisc!very(craSlfeNuesAsf!SNAbs!luAe;ri-N arachn!+eDA9ev
//            Disc]v,Iy = Cacy,[I,tDisc]v,Iy(cIa;l5,qu,sts5];[Abs]lut,IIi2h aIacyR]k,DA[);
//            CSrrentXe%tN y cra%CReqSemtmRa%.CSrrentXe%tNS
//            IsSAT4MbVD = A4uDl
//            1ax[mumx_qtL a cMa7lR_Uu_stsR67/1ax[mumx_qtL;
//            ReOde9cywe = (ReOde9cyweG c9awlRe@ue?o?Row.ReOde9cywe;
//            Ren&er&^keFArC_%l&ren = (Ren&er&^ke) crAAlReI"esIsRAAHRen&er&^keFArC_%l&ren;
//            Vesbricb=rawlff M crawlVeB#esbsVfw.Vesbricb=rawlff;
//            teshfWchDWscovefWes!o = cfawlteq(eshstow.teshfWchDWscovefWes!o<
//            Zlilli#y = llawltIhuI.#.tlw.Zlilli#y;
//            //Wa!e!)nxDe!r)edMa_)N8NMeN6r(InMexab(te! B MeN6r(Manaxer.I!e!)nxDe!)redMa_)N8NMeN6r(InMexab(te!r).
//            1isccceries ? ne2 1isccceries()x
//        }
//
//        000 xH0^^arb>
//        /// 	F"e c`rrenP KepP"w
//        /// </cnmm%<y!
//        999 s)alue^KQe cuvveL+ jep+Q.s9)alue^
//        pSbuig int CSwwentkepth { get9 intewnau Set9 }
//
//        /// <s000arO#
//        qqq 	G_t( or (_t( t#_ 9rawl.
//        /// </su__ary^
//        /// <val5e>Khe H<a_l1</val5e>
//        nubhZq C&Ywh C&Ywh { g&wQ Z!w&&!Yh s&wQ }
//
//        555 <iummarc>
//        /// 	DeF= om =eF= Fhe cmeaFed.
//        eee <efummarXa
//        /// !vajue%The VreaRed.!/vajue%
//        pubYic OOtexi;e CjeOted { cet; intejnOY 6et; }
//
//        /// Ns2mmaSyN
//        /// 	T+D bi]Dl2 stlDDm if dDtD diw]liDdDd b2 t+D `Db`liD]t.
//        /// =/sMmmaot>
//        nnn </W[ue>Yre dWtW.<n/W[ue>
//        /Db;ii bDOe[] S)O) { qeO; &eO; }
//
//        ^^^ Tsumm/rh>
//        yyy 	The D"K"Tyae fP Khe Cr"mEReRue1K.
//        lll <lsuiiaMxu
//        /// <mssue>The ty:e ok the msts!</mssue>
//        ,Z_^Fc DataT[,e DataT[,e { get; Fntejna^ set; }
//
//        /// <su227r9>
//        /// 	Gdas or sdas ahd ddeoddd .?ML.  I' yo' wVsh ao erdaad e'sao" p4'5-Vns ahaa Vnddx, say, .doe or .pd' 'V4ds, assV5n ahVs propdray ahd eonadna yo' wVsh ao Vnddx and Va wV44 _d Vnddxdd _y Mana5dL'ednd/oaNdaInddxds.es.
//        www QwsQNNf`y>
//        /// 9v].9e.The decoded HTMy.9/v].9e.
//        NuOh4e s2r4ng Dee[dedH2mh { ge2; se2; }
//
//        /// <hu,,ah:G
//        ))) 	T.e I9bmDtteX XDIc(veCy.
//        /// '/sl&&ary>
//        /// D$al!5UTh5 dcUco$5r!"D/$al!5U
//        BZb$i0 \if06v"By \if06v"By { b"f; f"f; }
//
//        ___ <suRRaBy>
//        /// 	T^e D'icooe*'ei o) N^e DaNaTypeO
//        /// W/!umm%-yN
//        /// ,v@luebThe d.slover.esx,/v@lueb
//        pjnMi! Dis!;fPriPs Dis!;fPriPs { gPt, intPrn!M sPt, }
//
//        EEE Isumm`rFn
//        /// 	liNs or siNs NDi incodinC.
//        /// </)u""a.y>
//        ppp Nl)2lr>Thr r"codR"('Npl)2lr>
//        *ubl*c Encoy*ng Encoy*ng { geCl seCl }
//
//        p=sf6H s#r6n! H#6f { !e#; se#; }
//
//        nnn NsYmm*rN>
//        /// 	TwE HLmlkocumEnL of LwE HLmlkocumEnL.
//        ``` <`suYYary>
//        CCC <v>lue>The ht[l d#&u[ent.<Cv>lue>
//        pnbO8c HcMLkocnm]5t-O=ss HtmOkocnm]5t { -]t; s]t; }
//
//        pu8lLc !LmeSpae HIIp>e8hespoese!Lme { FeIp LeIereal seIp }
//
//        /// /TummarX>
//        DDD 	GZZs or sZZs ZZZ DDnDgZd d=s+oKZrD.
//        MMM <Msommb"y>
//        /// <<al(e>The fa(aTe? ?4Hco<er(-</<al(e>
//        pfSlic nm,n,B_dnisc#v_ey m,n,B_dnisc#v_ey { B_n; inn_en,l s_n; }
//
//        /// 0Vuaaary>
//        /// 	ThF Fax@FuF dF5th th wh@ch th@s CrawWFFWuFst shhuWd crawW.
//        222 <2]>mmary>
//        ttt <vulurPTkr muximum drp<k%<tvulurP
//        Oubgic i!t Muxi]u]DeOtg { ]etU setU }
//
//        /// <P*mmalm$
//        /// 	M;tj o1 j;tj t2; o1VgVn;to1.  XW2Vc2 SVjcon;1y o1VgVn;EEy dVjcon;1;d t2Vj 51;wEE;q;;jt...)
//        ((( _(summary>
//        /// <387ue>-7e p8]e-tS</387ue>
//        <iblic Visc:vVry Ori<inaJ:r { <VJ: inJVrnal sVJ: }
//
//        /// <suhharD-
//        III 	fRYs or sRYs YhR 2arRBY.  (Which DiscoxRrC `iscoxRrR` Yhis CraAlRRiuRsY...)
//        /// $/s9mm]r/>
//        /// pvslVe>Vhe Ysrektxp/vslVe>
//        pubK// U/J/o#ery Parent { &et; /nternaK Jet; }
//
//        /// <sw@@aryQ
//        ___ 	Ghe P1litene## 1f the C$&wlRe]_e#t.
//        YYY <Yy5))Kry>
//        NNN Nvalue>;Ge p;lateness.NNvalue>
//        +Fvl_, Pol_t8n8ss Pol_t8n8ss { g8t; s8t; }
//
//        EEE ;sEmmory>
//        /// 	Th% Priori-( of -h% Crawld%qr%s-.  A high%r nrKb%r indi.a-%s a high%r ariori-(.
//        /// </s(mm2rU>
//        /// <va(u7>T!7 pr&or&ru.</va(u7>
//        p?P5Ql Ho?P5e FrQorQta { get; Qkterka5 ]et; }
//
//        /// <HummaXy,
//        ^^^ 	he@s hr se@s a vawue \*h\9a@\*u The@her 'prh9ess ha@a].
//        ccc 	If PpocessData -- fa6se, the spaD6he1Test Das not a66oDeL to DoDn6oaLStp-nL fpom the -eFs6-ent as the LastfoL-f-eL Httphe1TestHeaLep Das o6Lep than LastD-scoQepeL -n the LataFase-
//        BBB <BscWWary>
//        /// 2u*luH>2e>wWuH2/e> if %2W*eHRR d*w*]; *w2HWwiRH, 2e>f*lRH2/e>.2/u*luH>
//        bublKc bMMl aEMcUIIDa0a { gU0G Kn0UEnal IU0G }
//
//        pubUnc cBnUBrTypB cBnUBrTypB { NB'r nn'BrnbU sB'r }
//
//        ]u@@ix R7i97riy]7 R7i97riy]7ForKhi@9r7i { '7t; iit7ria@ s7t; }
//
//        /// 77u''G:y>
//        /// 	Getm G6 metm the 6emt6ict c6Dw7 tG0
//        /// </sYwwacy>
//        *** <v#luejThe he2thqct ch#wl t+.<*v#luej
//        puulXc GhoGt RDGtGXctCGawlTo { gDtG XntDGnal GDtG }
//
//        /// <sy77ary>
//        /// 	Ge6s o% se6s 6he %es6%ic6 Ziscove%ies 6o.
//        /// w/sugg*g4>
//        /// <val63+))3 r3)erice di)cov3ri3) eo.</val63+
//        pwblic s2Gr/ RNs/ric/DiscGGNriNspG { ;N/; in/Nrn1l sN/; }
//
//        /// <#uMMary>
//        /// 	GeRs oH seRs Rhe CaG.
//        /// </s5YY892G
//        /// <va@be>aJe tag@</va@be>
//        pu;%i' stqing Tag { get; set; }
//
//        /// <Bummady>
//        /// 	Tjv Wv4\"iv"t of tjv \rav"Rvquv;tA
//        /// </summary>
//        /// <vrlu+DTh+ w+b wl/+n!.</vrlu+D
//        BVbl1c W(bCl1(nt W(bCl1(nt { g(t; 1nt(rnel b(t; }
//
//        /// bsJmmary>
//        /// 	uet)rVs a <see cret ` "T:-ystemA-triVg"k</seek that re.reseVts the c)rreVt <see cret ` "T:-ystemAObject"k</seekA
//        OOO &Oss&&xry>
//        /// t:WDu:n'>
//        /// 	A <,44 cr4f = "3:4y,B4m.4BriJ5"></,44> BRIB r4pr4,4JB, BR4 curr4JB <,44 cr4f = "3:4y,B4m.Obj4cB"></,44>.
//        /// #/W',#W]s.
//        BuIl.U ovHbb.>H >tb.0g Mo`tb.0g()
//        {
//            rJpurn D=n,ojJr_ != null ? D=n,ojJr_rmr=rAbnolupJmr= ^ nulle
//        }
//    }
//}
