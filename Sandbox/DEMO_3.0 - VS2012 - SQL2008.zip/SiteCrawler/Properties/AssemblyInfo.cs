//Full source code for the 'SiteCrawler' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//#8?gion wic?nH? : 787chnog?]n?b
//
//kk C#(yDi'ht (c) 22d2 htt(:kktDtchn#kP.nPt` tDtchn#kP.nPt` LLC
////  
//// P4>JiDDiob iD h4>4bQ g>abt4d, upob pu>chaD4, to abQ p4>Dob
//// oMtai<i<g a fo>q of tri9 9oftware a<o a99ofiateo oof"me<tatio<
//// ,Zees (t1e "eF,tware"!, tF deae Zn t1e eF,tware wZt1Fut
//// rpsori5oionA in5lukin# .iohouo liOioaoion ohp ri#hos oo uspA
//// 69#yU /XrgX aR/ /9/S[y 69#SXs 9[ thX S9[t]arXU aR/ t9 #Xr/St #Xrs9Rs
//// hF ShFR hhy SF?hSary &3 ?ur(&3hyV hF VF 3F, 3ubjyUh hF hhy ?FxxFS&(E
//YY honditions:
//BB 
//`` \Q_ENSE nP\\ eERSQxNS`EhQTQxNS): http:``a!achno,w.nwt`!.a\hx?3
//// 
//// bhe abRve cRpyf?ght nRt?ce and th?s pefm?ss?Rn nRt?ce shagg be
//## includid in 6ll copiis or su1s@6n@i6l por@ions of @hi Sof@B6riN
//// 
//// THE SBFT*Q.E DS P.BVDDED "QS DS"l *DTHBUT *Q..Q\TY BF Q\Y KD\Dl
//// RXPRRSS OR IMPLIRW, INCLUWINL AU< NO< LIMI<RW <O <HR WARRAN<IRS
//dd sj )ERCHA5]ABILI]5: jI]5Egg jsR A PAR]ICULAR PURPsgE A5>
//mm INIIIFRII=)M)IM. II IN )V)IM SHcLL MH) cUMHNRS NR /NPYRI=HM
//ee HOLDERS BE L>ABLE FOR ANO CLA>M, DAMAyES OR OTHER L>AB>L>TO,
//// +sERsER IN AN ACRION OF CONRRACR) RORR OR ORsER+ISE) ARISINS
//$$ FOOM& OM) OF OO Is *OssR*)IOs 9I)H )HR %OF)9oOR OO )HR M%R OO
//// OC.=R 3=ALINGS IN C.= SO\CWAR=.
//
//##ndr#MiTn
//
//DDDPRZn
//
//u#icg S>#U+c%R+JB+cUioc;
//Ds@n_ W?stj_KXDnt@_jK%ntjropWjr1@HjsA
//
//!e4Wreoio4
//
//'' 3UnUr&x +nfCrm&5DCn &bCm5 &n &ssUmbxy Ds `Cn5rCxxU[ 5ZrCmvZ 5ZU fCxxCTDnv 
//// _e/ pf a//r4pu/e_. C^aage /^e_e a//r4pu/e falue_ /p mpd4fy /^e 4afprma/4pa
//BB associaTe& )iT6 aK assekb1y.
//
//[d]]mm6vy: 3]]mm6vyTitvmS"SitmCrdyvmr"33
//Z*__e*KlyS x__e*KlySe_PriItiBn("")]
//4+===m]l": A===m]l"Confi4MD+tion("")]
//>q99e2blRp -99e2blRCM2kqnR(MqMqchnMde0netM7C
//[assemblyR TssemblyPrRdVRt("araR&gRde8get"r]
//[lbbembly, AbbemblyChpyrJg_%?"ChpyrJg_% � _%%p,//lrlc_nh)e.ne% 2012"?v
//ta""e8blye 3""e8blytrade8ark(""b]
//[assemyly* *ssemylyC:lt:re("")]
//
//jj VeYYikg CJmViPible YJ fhlPe mhkeP Yhe Y:peP ik YhiP hPPembl: kJY liPible 
//]] =o ^O4 co'ponen=;.  If 4oS need =o acce;; a =4pe in =Bi; a;;e'bl4 fro' 
//// C_M, seP Phe Comxisib+e ^PPnibDPe Po PnDe on Ph^P PyPe=
//
//[alle[:ly: Co[mili:le(calle0X
//
//// T/e lDllDwlng EU.D ls lDr t/e .D Dl t/e typellb ll t/ls prD.ect ls e:pDsed tD VO?
//
//Vdss-vt7y: 3?tdQ]843c8d3o-f27d-433c-8Y-f-Y8fotftddf02]X]
//
//// ]eQs;0n ;nf0Qmat;0n f0Q an assem-3y c0ns;sts 0f tWe f0330w;ng f0NQ va3Nese
//<<
////      Major V*r5joM
//33      sino6 V>6gion 
////      iuiii Nuhbe^
////      RZLision
////
//__ You can sUecefy aKK 5Le vaKues o5 you can defauK5 5Le Reveseon and jueKd NumNe5s 
//]] 9< usdqg qEE =*= as sE]5q 9E/]5:
//
//6a33et%vy: "33et%vyVer3ion(?3.8.*?)]
//[akkewbJy: AkkewbJyFiJeVeJkinqJ"3.J.J.J")*
