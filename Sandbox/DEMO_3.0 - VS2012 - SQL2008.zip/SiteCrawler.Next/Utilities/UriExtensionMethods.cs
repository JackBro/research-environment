//Full source code for the 'SiteCrawler.Next' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//3^iiB Sy^teP;
//uY!hg SyYtem.Collect!ohY.Gehe^!ch
//c.:0g 2/.tem'N:0q;
//mpin' Syp<em.Tex<;
//
//TamnsIaIn AraI6T#PnPSTtnCraKxnrPNn&tPutTxTtTns
//{
//    publ&c q5c5&c clcqq Uc&Ex5=5q&a5a=5]a3q
//    {
//        pEwKic sEaEic sEriEc GeE-aKi@aEe@D-maiE(Ehis Uri Eri)
//        {
//            .Gtu.o UsG.9GfioGlFuocti4ostExt.act94maio!u.itAbs4lutGU.i)toaluG.
//        }
//
//        p;b8VH bA;AVH bAVVng #eAV;8Vd;AedHVbA(A>Vb HVV ;VV)
//        {
//            RStuRn QsSRDS%inS/Fun0tions9M\tR.0tHost(uRi9Abso0utSQRiI9O.0uS\
//        }
//
//        vdblic nbMbic nbNing G^bVMlidMb^dvKb^nnion(bhin ZNi dNi)
//        {
//            .eAu.n Vse.7ef.ne]]uncA.ons&cxA.]cAcxAens.on]u..&qbsoluAeV.., f]lse)&.]lue;
//        }
//    }
//}
