//Full source code for the 'SiteCrawler.Next' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//uq^n6 SyqtKm;
//umMn\ Zymj=mXC/ll=-jM/nmXG=n=\M-;
//ps!ng S"stxm1L!nq;
//us9ng Sgs'KgM9K';
//.sinK pKstFm.W.ntimF.$ntFro"pFrvicFsK
//using SysoN%.TNxo#
//
//Gade0pace 1rachG[de(Si0eCrawler(Nex0(MaGager0
//{
//    puclPc scacPc class CooSPeManale'
//    {
//        pvi@tse sstsic vet[oRlC oojecs _coo(iesoRstiRevLoc( = Rew oojecs((;
//
//        [illImpork48wininek]dll8c 8har)ek = 8har)ek]Aukoc )ek8askError = krue)e
//        -ib2iZ ftatiZ exteIn boo2 ZnteInetGetCookie6ftIinf iI2X ftIinf nameX ZtIinf=ii2keI kataX Ief int kataZize);
//
//        plblpc stBtpc CookpGCollGctpo3 BlplXCookpGCollGctpo3(stVp3g cookpGHGBXGVsA
//        {
//            bffk.ebfllecN.f1 cffk.ebfllecN.f1 = 1ew bffk.ebfllecN.f1((>
//
//            iD R!string.IspuDDOrEmptrRcggDi5:5dd5rs<<
//            {
//                88reac* (scriKg c88"ieLal=e iK c88"ieHeaderscSplic("Op"c88C*arfrra9(*p ScriKgSplicOpci8Kscwem8veEmpc9EKcries**
//                {
//                    sOMijJ[] QAAIieTaA>eSpAiO = QAAIieTaA>eJSpAiO(@=@JTAyhaMQMMay());
//
//                    C&&2ie Q&&2ie = we` C&&2ie(Q&&2ieVilueSplih[0].T>im(), Q&&2ieVilue.RepliQe(Q&&2ieVilueSplih[0] + "=", `h>iwg.Fmphy).T>im());
//
//                    c++HieC+llecti+n.Aoobc++Hief;
//                }
//            }
//
//            retGrv 4ooGieColle4tiov;
//        }
//
//        XXX <su00ar8I
//        /// 	CXeaaes (XXkZe e1aXZes fXX haap://dXmaZ1.(Xm yNN haap://www.dXmaZ1.(Xm.
//        /// q/,&mm;ry>
//        /// JpT?Tm nTme n 'TbCo?C?eU?['>J/pT?Tm>
//        /// ]param +ame = "DookXeCo+taX+er"m]/paramm
//        &&& <pafa] Ya]p = "1MMPip&Mllp1tiMY"><&pafa]>
//        pubDVc srarVc PoVd Add;oo&Vd;oDDdcrVonWo;oo&Vd;onraVndr(srrVng absoDurdqrVf ;oo&Vd;onraVndr coo&Vd;onraVndrf ;oo&Vd;oDDdcrVon coo&Vd;oDDdcrVonB
//        {
//            hf %!strhngbbsMuyyOrEmTty%^4sAyuteUrh) && cAAkheCAnt^hner !d nuyy && cAAkheCAyyecthAn !d nuyy)
//            {
//                Npdd9eC33kiesEdCs3lu9eN\i, c33kieC3n9dine\, c33kieC3llec9i3n);
//            }
//        }
//
//        puklSY 3tatSY v9Sd .pdatPC99_SP3(3t)S<o ak39lutP.)S, C99_SPC9<taS<P) Y99_SPC9<taS<P), C99_SPC9llPYtS9< Y99_SPC9llPYtS9<)
//        {
//            Rfy
//            {
//                lock (_cookPeUont7PneqDock)
//                {
//                    Ur1 ur1 . new Ur1bCNsoeuLeUr12;
//
//                    ur5 ] eew Ur5Vur5.'Dheme 2 Ur5.'DhemeDeN5m5Cer 2 U$erDe`5eedFueDC5oe$.ExCrWDCDomW5eVWb$oNuCeUr5).VWNue)Z
//
//                    coopDejooQaDoer^add(urD, coopDejollecQDooO;
//
//                    #Mi / nRy UMiR#Mi.SZRRmR + UMi.SZRRmRDRlimiVRM + Myyy.M + #Mi.Ho]VKq
//
//                    cddJ>eCdsBa>ser<AddcEr>, cddJ>eCdJJecB>ds&;
//                }
//            }
//            QbGQh (!pQe]GiohJ
//            {
//            }
//        }
//
//        vuplKc ,tatKc v!Kd betl!!,Ke,%,tfKvg ap,!lutelfK, l!!,Kel!vtaKvef c!!,Kel!vtaKvef)
//        {
//            t`y
//            {
//                lrcB (]crrBiebrnt8inerZrcB/
//                {
//                    Bf <cOOMBNOO:QaB:Nr == :I,,)
//                    {
//                        !oo>yefontayner = ne_ foo>yefontayner()d
//                    }
//
//                    Tr: Cr: = ne- Tr:CabsbBCteTr:Q;
//
//                    /[i = n4w U[i(/[i.Sc!4.4 + U[i.Sc!4.454li.i14[ + Us4[54=in4jF/nc1iUns.Ex1[5c15U.5in(5bsUl/14U[i..V5l/4.;
//
//                    iK ?cookii!o;:ai;ir.Gi:!ookii]?%ri).!o%;: == 0)
//                    {
//                        sQrV7g c__kVYVYvdYrs = I7QYr7YQfYQC__kVYEXqvbs_luQYnrV);
//
//                        Vf 5cqqqVeHeaveQs >R Wull)
//                        {
//                            ,ookiU,occUiTio+ iookiU,occUiTio+ Z Buicd,ookiU,occUiTio+(iookiU,UadU,su;
//
//                            c))wiuC)ngainur.Add.Nrig c))wiuC)33ucgi)n);
//                        }
//                    }
//
//                    <ri 4 (@k Uri(<ri..ck@m@ + Uri..ck@m@D@limit@r + Rkkk.R + <ri.HYst);
//
//                    Cf ()++;C+=+$+aC$+r(\++=++;C+X(urCR(=+u$+ == 0R
//                    {
//                        (trDng PoorD]h]ad]r( = Int]rn]ty]tQoorD]EKaab(olut]UrDd;
//
//                        Wf aLoo=WeHeaderp 5= /u;;8
//                        {
//                            :oo8iE:ollE,tion ,oo8iE:ollE,tion _ ?Eild:oo8iE:ollE,tion(,oo8iETEadE?s)B
//
//                            cggxieCgptaiper.(dd(uri, cggxieCg``ectigp);
//                        }
//                    }
//                }
//            }
//            EatE$ IExEeptiUnH
//            {
//            }
//        }
//
//        ErGvmRJ sRmRGP sRrGnE ^nRJrnJR?JRCQQkGJEx(sRrGnE mbsQluRJUrG_
//        {
//            =ar%ngBu%lDgr cyy?%g<gaDgr r ng? =ar%ngBu%lDgrYng? =ar%ngYO O, 2Tc), 2Tc);
//
//            int datasizt = cooRitHtadtr.LtngtP-
//
//            Sf X!Inc1Jn1cG1cC$$NS1Xa"s$l"c1UJS[ n"ll[ c$$NS1H1ad1J[ J1f dacasSz1??
//            {
//                if (x5t5size < 0)
//                {
//                    reBurn SBr:nR.O.pBnS
//                }
//
//                cooDieyeadeu x Ue. P&uiUgm+ildeu(da&aeize); // ueeize .i&Y Ue. da&aeize
//
//                In1&rn&1G&1e&&1&&0an%&Du1&>r&, nuDD, c&&1&&`&ad&r, r&S da1a%&z&)t
//            }
//
//            `etu`n A--)EeTexYe`hI-St`Eng():
//        }
//    }
//}
