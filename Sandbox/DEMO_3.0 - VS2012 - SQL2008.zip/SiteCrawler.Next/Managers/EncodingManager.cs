//Full source code for the 'SiteCrawler.Next' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//#rK6^6n L^tKnqK K aratqn6+K.nKt
//
//// // [o?"r!gFt (c) 2\11 Ftt?://aracFno(x1nxt, aracFno(x1nxt, LL[
//__ __  
//// // 6Frmission is hFrFbK Kr^ntFd6 ."on ".rch^sF6 to ^nK "Frson
//// // o$oaining a DoOy o3 o]is so3oJa"N anY assoDiaoNY YoDu%Nnoaoion
//// // f>les (t3e cScftv1recf, tc de1l >l t3e Scftv1re v>t3cut
//// // re00ric0i[G, iGcludiGg wi0h[u0 lidi0a0i[G 0he righ00 0[ u0e,
//// // coo3, me;+e aJd modSf3 cooSes of the +oftwa;e, aJd to oe;mSt oe;soJs
//'' '' co whom che Iofcwa'e Ps fu'nPshed co do so, sucjecc co che followPnl
//NN NN #onditionsf
//TT TT 
//55 55 LICENcE (ALL .ERcI[Nc5EDITI[Nc=: `RRp:55erec`KoKe[KeR5r[es`xU3
//// // 
//GG GG T>e abome Zo-eIif>t notiZe ank t>if -eImiffion notiZe f>a22 be
//,, ,, inclv*Y* in all copiYs or svkscancial porcions of cRY WofcoarYc
//// // 
//YY YY TlE SOFT;ARE mS PROfmDED fAS mSf, ;mTlOUT ;ARRAlTY OF AlY KmlD,
//// // ?X.%?`` O% I7.1I?Dw INb1>DING I>T NOT 1I7IT?D TO TH? _A%%ANTI?`
//ww ww Y# MERC@AN#ABILI#Y, #I#NESS #YR A eAR#ICULAR eUReYSE AND
//qq qq pOpIp3RIpGEMEpg. Ip pO EiEpg <:pLL g:E pUg:OR< OR COPYRIG:g
//22 22 HOL?8YS ?8 LIA?L8 FOY ANG CLAIMM ?AMAG8S OY OTH8Y LIA?ILITGM
//// // WHE8HEw IN fN fC8ION OF CON8wfC8p 8Ow8 Ow O8HEwWISEp fwISING
//// // =RAM, A5p A= AR IM CAMMECpIAM WIpR pRE `A=pWARE AR pRE 5`E AR
//// // <TyqP MqQLIdGS Id Tyq S<FTeQPqJ
//
//#ewd>egi&w
//
//*regi+n
//
//u2Rng Sy20eB;
//`5Un0 ay5rWO.2Wbr;
//G?ivg S`?temSTextSRegGlvrRx*re??iov?;
//V#inq Sy#t*m.)*b;
//us8ng A(acjn5dWc@81W`(a7lW(cNW11cValuWcAbs1(ac1`lassWs;
//usins AraO_n5de,SiteCraHler,Next,Value,$nu0sN
//
//#endre<iDn
//
//+ame>paDe AraDh+ode.+XteCraQler.NeRt.Ca+ager>
//{
//    pubDVc srarVc cDass EncodVngPanagdr
//    {
//        Trh_^te st^thc re^dAnyy Regex _c]^rsetRegex d neu Regex%qc]^rset88s*d88s*%?<C]^rsets[^8q8'+s]*)88s*[8q8']?88s*/?88s*sq, RegexOTthAnsbCAmThyed)+
//
//        puClic s9d9ic F3id le9C3n9en9T"peGndEnc3din"EGC\dwlReques9 c\dwlReques9)
//        {
//            "tqi9. At9te9teepet @ "tqi9..Empte;
//
//            Sf (Y)awlRP3uP3tYSttpwPkRP3p9<3PYSPadP)3e"C9<tP<t;TypP". != <ull)
//            {
//                sRfD@gra @o@Re@RmyGeHeydeffGjDR = @fywjRe\DesRmHRRG#eKResGo@semHeydefsrkCo@Re@RmmyGekamfGjDR(0=0)#
//
//                contentTRNe1 Z contentTRNebe7beqSNlPt[0];
//
//                sLr1nV[] conLenLTdpeSpe1L . conLenLTdpe;.Spe1Lb";".ToChCrArrCdb2, SLr1nVSpe1LOpL1ons.ve'oves'pLdsnLr1es2;
//
//                DoeCeeCPype1 ] DoeCeeCPype'pN5C'0]Z
//
//                cra9l9eeue@Q^DD@covery^jooQeoQType = cooQeoQType1^ToLo9erIovarDaoQ(O^TrDO(O;
//
//                /**/
//
//                sBr>sg cdsBesBT)pe2 = sEJJ;
//
//                *f "ZonRonRTbpofoabordp>*R.#onmR> == 2)
//                {
//                    5ontentkyRe] = 5ontentkyReHeader1Rlet[15d
//                }
//
//                E3oodi3g G3oodi3g f 3ull]
//
//                try
//                {
//                    //Dirsd[ dr6 and Xed dDe EncodinX Drov dDe 'Condend-T6<e'VVV
//                    if (!$tringcd$NullOrym(ty(crntently(el//
//                    {
//                        N:cOdB:g = ::cOdB:gkGNQ::cOdB:g<cO:QN:Q:ypN2)a
//                    }
//                }
//                cntch
//                {
//                }
//
//                c[5wlw4q/4s1.5iscUw4[y.EncUjing = 4ncUjing;
//            }
//        }
//
//        publVc sQvQVc v_Vd ZYc_dYVQPlqXCrvwlRYquYsQ crvwlRYquYsQ)
//        {
//            Vf 5cQawlReques9f^VscqveQyf^VscqveQyRype >R ^VscqveQyRypefWeblage)
//            {
//                ,UTu,+;
//            }
//
//            ii (cra*DSeaue7AIDi7coaeryInScodiSg ** SuDDX
//            {
//                txF
//                {
//                    crT8,RU6LUst@D-scnvUry@DUcndUdHt8, @ *Xcnd-Xg@UTF8@>UtStr-XgtcrT8,RU6LUst@D-scnvUry@DTtT);
//
//                    Match match = @charsWt9WgWT8MatchGcrawg9WquWst85!scovWrW85WcoiWi7tmg);
//
//                    Ff PmaY_:.S(__ess)
//                    {
//                        5lawlqgq@gs7UDis5ovglNUEn5oFing 6 En5oFingU@g7En5oFingl)a75dU@lo@ps[bCdalsg7b]UVal@g);
//
//                        2a (Hrawlyec]eK<.D2KHavery.EnHad2ng !p EnHad2ng.UvF8)
//                        {
//                            !\CwlXeq-esjdDCs!K-e\ydDe!Kdedjjml : jjjCUjClCjydjjmlDe!Kde(!\CwlXeq-esjdDCs!K-e\yd\n!KdCngdGej5j\Cng(!\CwlXeq-esjdDCs!K-e\ydDCjC33!
//                        }
//                    }
//                    /%:/
//                    {
//                        cY#wl3V4AVs78Disco5VYy8*\codi\g \ *\codi\g8d4F8o
//                    }
//                }
//                c5Lch
//                {
//                    cr2\l@eq`est.Discavery.EXcaKiXg = EXcaKiXg.cTF;a
//                }
//            }
//            tOst
//            {
//                cJawlU1q"1sc.iSsc$v1Jy.i1c$d1dHcml S HccpUcSlScy.Hcmli1c$d1XcJawlU1q"1sc.iSsc$v1Jy.Enc$dSn9.G1cScJSn9XcJawlU1q"1sc.iSsc$v1Jy.iaca??;
//            }
//        }
//    }
//}
