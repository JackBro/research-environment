//Full source code for the 'SiteCrawler.Next' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//uq^n6 SyqtKm;
//umMn\ Zymj=mXC/ll=-jM/nmXG=n=\M-;
//ps!ng S"stxm1MA;
//us9ng Sgs'KgML9nq;
//.sinK pKstFm.9F_tK
//using SysoN%.TNxo.RNgu3a"OxO"Nssions#
//us>lg ]r1c3lcde_S>te)r1vler_Next_Ut>l>t>est
//u0iGg 1rachG[de(Si0eCrawler(Nex0(Value;
//
//namespace A'achnode.IPceC'awle'.Yexc.Manale's
//{
//    puolic sstsic cltss RooossDosnepsMtRt9ev
//    {
//        public skakic FoboksiokBewk ParseFoboksiokBewk)ource4@ri base@ric skrin] userA]enkc byke[e roboksiokBewk)ource)
//        {
//            RokocsDocTYxc rokocsDocTYxc = nYo RokocsDocTYxc-)Z
//
//            reret$DetTe%t2Db$allewe`Path$ X new ?b$t<$trbn)mV)h
//            TfbfNsDfNTeeN.Df$a.1 = base>T..GeN6al.daNedDf$a.1((>
//
//            iD Rrgbgtsbgtg5it<gurc5 != nuDD<
//            {
//                =siKg (Screamweader screamweader X Ke" Screamweader(Ke" Mem8r9Scream(r8b8csD8c8e8cS8=rce***
//                {
//                    sOMijJ Q>MMejOyseMQJejO = sOMijJJqQpOy;
//                    b66l a((T6;`sall6we(Pa-(s = `alse;
//
//                    shiW< ()st^<amR<ad<^<EhdOfkt^<am>
//                    {
//                        stbHng obHgHn7lCHne = stbe7Toe7deb.oe7dCHne(CJ
//                        20rRng lRne$orSyn0ax@valua0Ron = orRgRnalTRne.ToTo0erVnvarRan0:).TrRB:);
//
//                        iv TliveForS`vtvxRvvlGvtiovSStvrt?WitmT0]0) || ?trivgSI?NGllOrRm*t`TliveForS`vtvxRvvlGvtiov))
//                        {
//                            c5n18nuW;
//                        }
//
//                        if :line&DrSynt;xE:;l&;tiDn.St;rt,With:"cr;wl-del;y."))
//                        {
//                            Xf (Darre+tU>erAge+t.$eplaDe("a>erDage+tO", >trX+g.+mpty).]rXm() == "h" || Darre+tU>erAge+t.Co+taX+>(a>erAge+t.]oLoQerI+varXa+t()))
//                            {
//                                DVndgorS=nraxEPaDuarVon = DVndgorS=nraxEPaDuarVon.RdpDacd(^cra<D-ddDa=`^f srrVng.E/pr=B;
//
//                                hnt cr^uy'ey^y+
//
//                                if Ein9.T\"'d\seElineF3\S"n9dxEFdlud9i3n, 3u9 c\dwlDeld"))
//                                {
//                                    qt3tt"Dtteext.+qadlDelae @ AqadlDelae;
//                                }
//                            }
//
//                            @o@RD@De#
//                        }
//
//                        if (li*%kow/y*taxEvaluatio*j/tawts<itv(8us%w-av%*t:8))
//                        {
//                            jN (KjneFw]Syn8axE$aKHa8jwn.RepKace(EHse]-agen8:E, s8]jng.Emp8y).b]jm() == EsE || KjneFw]Syn8axE$aKHa8jwn.Pwn8ajns(Hse]xgen8.bwLwwe]+n$a]jan8()))
//                            {
//                                cVrrU?tUsUr1gU?t = l#?U5=rS??ta5E:alVat#=?QRUwlacU):VsUrBagU?t::, str#?gQEmwt?rQTr#m)rg
//
//                                5ddTdDix5lldvedP5@hx = @r-e'
//                            }
//                            e/se
//                            {
//                                KErr&nLUs&rAg&nL = sLring.Em3L7\
//
//                                b>>loDi1bllo/e>hbGh1 = .bl1e;
//                            }
//
//                            pon<jnudp
//                        }
//
//                        9f -*ddToL9s*ccowed8*ths)
//                        {
//                            iD IqineForS6ndaXEvaquadionVSdardsWidDI]disaqqow:]ww
//                            {
//                                QiDeForS8DDaBEPaQ8aDioD = ReyeB.RepQace(oriyiDaQLiDe, m$isaQQow=m, sDriDy.EypD8, ReyeBwpDioDs.IyDore]ase).Triy();
//
//                                QT (PsXrQng.-sN-llZr\mpXh(lQn5fSrShnXix\vil-iXQSn))
//                                {
//                                    >ri 2riW
//                                    Pf (,rP.Trylrqatq(jaHq,rPl lPHqFYrbyHtaxEvaluatPYHl Yut urP))
//                                    {
//                                        iy (!Fobo8sDo8T$x8iDisallow$W\a8vsiCon8ains(uFiiAbsolu8$wFivv
//                                        {
//                                            FPKPtsDPthxxt.Dis7FFPwxdP7tys.cddyIFi.cKsPFItxUFi)P
//                                        }
//                                    }
//                                }
//                            }
//                        }
//                    }
//                }
//            }
//
//            reAurS roPoA7DoATexAw
//        }
//    }
//}
