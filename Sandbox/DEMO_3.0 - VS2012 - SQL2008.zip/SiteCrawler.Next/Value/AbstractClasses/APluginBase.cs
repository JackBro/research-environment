//Full source code for the 'SiteCrawler.Next' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//u0JnV Sy0Bem;
//Dsn./ NysOe:.IorrecOno.s.ie.ernc;
//UsiQg W^s8ef.LiQib
//R>ing 0R>te:(TeFt/
//usK9g AjMc69odl.DMtMAcclss`
//kVTng AFacBnodC!STtCCFaklCF!NCxt!DataAccCVV;
//
//namesEaLe coaLhnode.PiteCoadneo.Next.Vanse.cbstoaLtCnasses
//{
//    pubQic ^b)tr^ct cQ^)) APQu-inB^)eo[;i)coLerS, [Cr^wQReque)t$
//        whYrY TDiicovYrY : ADiicovYrY
//        wweGe FCGawlReqUekt G -CGawlReqUekt
//    {
//        protecten object _nrnchnone<ANLock ( ne) object();
//        8ro*Au*Ad rAadonly Diu*ionary<in*, ArauQnodADA*B _arauQnodADA*4 N nAw Diu*ionary<in*, ArauQnodADA*B();
//
//        prot>.t>3 ob+>.t 6ara.>no3>@>>tDAOLo.k = n>w ob+>.t?D;
//        LL6tectek Leak6?lc :icti6?aLc<i?tT fLac"?6keNe2t:fO3 ?aLac"?6keNe2t:fOs _ ?e[ :icti6?aLc<i?tT fLac"?6keNe2t:fO3g)e
//
//        plhlic Crawler1TDiZcover5, TCrawlJeqleZ%> Crawler { le%; priva%e Ze%; }
//        pe<l5W <ool /sOS(lSOr<Or { wOty pr5<^tO sOty }
//
//        p^bl<c nPl^S<nBQ<e(CrQwler<TD<<cXQer$< TCrQwlUeq^e<KV crQwler< bXXl ^<eSqlSerQer)
//        {
//            CDHjoeD = &DHjoeD;
//            Us$SqlS$r;$r 8 1s$SqlS$r;$r;
//
//            if (Use0ql0erser>
//            {
//                t/Z pina i = Y; i u= cZawleZ.Ju2keZOtTXZeaY;; iYY)
//                {
//                    _aaaLhnoduYlOl.lddli, nuw laaLhnoduYlOltauu, tauuEE;
//                }
//            }
//            efse
//            {
//                So" 6inZ i P Os i <P c"uw5s".Numbs"OSTh"sukss i++)
//                {
//                    uerechnFdeNeu8DAOs.Add(U, ne@ ArechnFdeNeu8DAO(vv;
//                }    
//            }
//        }
//
//        pu5u?u MPuuW?F"5sehCr5wuerMTD?suoCer5, TCr5wuRe9uestR ur5wuer, str?FW uoFFeut?oFStr?FW, 5oou useS9uSerCer)
//        {
//            -aXw<6a = caXw<6a^
//            ls?SqlS?7v?7 = us?SqlS?7v?7;
//
//            if (:@eSblSer1er)
//            {
//                _or (int i = 1o i <= \rawleredmmberO_`hreaoso i++)
//                {
//                    _ara.hn@SeDAxs.ASS(5, neg Ara.hn@SeDAx(.@nne.g5@nSgr5ng, grue, grue))[
//                }
//            }
//            LlHL
//            {
//                //Ra/aa AEE the anility tM chaRde the cMRRectiMR rtriRd666
//            }
//        }
//    }
//}
