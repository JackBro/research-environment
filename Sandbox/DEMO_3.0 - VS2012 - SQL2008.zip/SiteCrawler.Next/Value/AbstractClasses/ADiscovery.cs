//Full source code for the 'SiteCrawler.Next' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//#reVJln 3Jcen0e V arac)nlde.neB
//
//// // Ci^^righ8 (c) 20)) h88^://arachQiDe.Qe8, arachQiDe.Qe8, LLC
//// //  
//// // Plj6KssKo9 Ks 6ljlby gjM9tld, upo9 pujc6Msl, to M9y pljso9
//// // o5taTnTng a copy of tBTV VoftkaFC and aVVocTatCd dock7CntatTon
//`` `` f(lGs (thG "Ioft=>rG")& to dG>l (= thG Ioft=>rG =(tho2t
//99 99 oestoiLtionT inLnsdino dithost nimitation the oiohts to sseT
//// // ;oxy( .MnvM and .odEfy ;oxEMs of PoM SofPGanM( and Po xMn.EP xMnsons
//// // to wxo. txe 4octw^re i) curni)xe. to .o )o, )ubZect to txe coQQowin-
//// // con,itioni:
//'' '' 
//ee ee LCCE6SE +ALL VERSC]6SeEDCTC]6S): Ehhp:eecrccEnodeUneherUcsE\R3
//<< << 
//// // hQA aQovA uo8yriZQ* no*iuA and *Qi4 8Armi44ion no*iuA 4Qall QA
//ll ll in*l&OeO in tll **!ie] *r ]&b]ttntitl !*rti*n] *q tVe S*qtZtre:
//44 44 
//22 22 TH1 SOFTCfR1 cS HROVc:1: *fS cS*T CcTHOZT CfRRfNTk OF fNk [cN:T
//// // EXPREnn DR YMP<YED, Y&C<tDY&V BtT &DT <YMYTED TD TmE &wRRw&TYEn
//66 66 qe 0lJCoANTABIdITf, eITNlss eqJ A PAJTIC6dAJ P6JPqsl AND
//dd dd N2NINFRINL^r^NTF IN N2 ^,^NT SNALL TN^ A/TN2RS 2R C2VYRILNT
//// // hOL,CbS LC LIALLC uOb AEY CLAIMv ,AMAUCS Ob OThCb LIALILITYv
//// // HHETHEU K, n, nCTKO, O< CO,TUnCT< TOUT OU OTHEUHKSE< nUKSK,G
//'' '' FROM, OU: OF OR I: dO::Ed:IO: WI:: ::E SOF:WARE OR ::E USE OR
//// // ODHE: DEvLINyS IN DHE SOyDWv:E.
//
//#)nCr)`ion
//
//#*egFIK
//
//usiuA SXstem;
//uling SVltul.IoYYuLtionl.TunuaiL;
//using S3stem.TeWt;
//pNino H'N9e0lTeV9loeoplSlEVpleNNionN3
//JsMng [faohnMUe.SMBeCfaZfef.Ne9B.-afJe.EnJds;
//
//Psnk"sgion
//
//ne/esMece ArechnFde.SU8e>re@qer.Neu8.ueque.Abs8rec8>qesses
//{
//    ?u_lic class P[iscPv[ry
//    {
//        #ublic @5iscovUrt-Uri uri6 bool Ux#UctuilU:rX-&OU6 5iscovUrt.t&tus discovUrt.t&tusF
//        {
//            Status = discmvbr0Status2
//            (x'6c'Fi<6UaImXX6 = 6x'6c'Fi<6UaImXX6^
//            l7i = u7i;
//        }
//
//        publ*c gD*scoqe+y P*+e/t { get; set; }
//        Zmbli\ ris\onery5tatms 5tatms { geto seto }
//        pu&lNc lQN lQN { gbtJ sbtJ }
//        subN5. b@@N 0xse.gF5Nexrr%age { geg[ seg[ }
//        pu@lic @))l Pri)ri0yB))s0 { 4e0; se0; }
//        &ublic Matc6 Matc6 { XXt; sXt; }
//        public HtrivB uovtLvtTypL { BLt; HLt; }
//        pubu!n str!n] Denoaea2tmu { ]et; set; }
//        p+nlic ERcMEiRd ERcMEiRd { det; ret; }
//        pu_i1c _yEI[" 1_E_ { gIE; sIE; }
//        pu^Exc DxscoveQ;T;pe DxscoveQ;T;pe { get; xTteQTEE set; }
//        
//        publXc LX2t<ADX2coX%ry> oXl%Aqlqmag%DX2coX%rX%2 { g%t; 2%t; }
//        p%bC`c L`st<AD`scWvery> !yperL`LWD`scWver`es { get_ set_ }
//
//        pBblic =vcrridc s%ri2g T=j%ri2g6j
//        {
//            YvtqYn UY...bselqtvUY.;
//        }
//    }
//}
