//Full source code for the 'SiteCrawler.Next' project is included in the 'Licensed' version.  (C#/T-SQL/Database)
//3^iiB Sy^teP;
//uY!hg SyYtem.Collect!ohY.Gehe^!ch
//c.:0g 2/.tem'N:0q;
//mpin' Syp<em.Tex<;
//
//TamnsIaIn AraI6T#PnPSTtnCraKxnrPNn&tPVaxun
//{
//    publ&c clcqq YaucCcc7lh=qu=q5 : Ccc7lh=qu=q5
//    {
//        pEwKic ?-ErCraEKRe[EesE(Disc--erw @isc--erw, iEE @epEh, @-EwKe pri-riEw) / wase(@isc--erw, @epEh, pri-riEw)
//        {
//        }
//
//        >]b:ic Yo]r[rfw:RTq]Tsl(inl lhrTf9U]SbTr, DiscovTry >frTnl, DiscovTry 9iscovTry, inl c]rrTnlDT>lh, inl SfxiS]SDT>lh, 9o]b:T >riorily) * bfsT(lhrTf9U]SbTr, >frTnl, 9iscovTry, c]rrTnlDT>lh, SfxiS]SDT>lh, >riorily)
//        {
//        }
//
//        //aOO FOuS 0ustOm pSOpeStaes heSe.
//    }
//}
