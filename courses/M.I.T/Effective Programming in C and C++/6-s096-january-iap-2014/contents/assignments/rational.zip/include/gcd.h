#ifndef _6S096_GCD_H
#define _6S096_GCD_H

#include <cstdint>

intmax_t gcd( intmax_t a, intmax_t b );
intmax_t lcm( intmax_t a, intmax_t b );

#endif // _6S096_GCD_H
