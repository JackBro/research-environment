#include <stdio.h>

typedef struct IntPair_s {
  int first;
  int second;
} IntPair;

int main(void) {
  
}
