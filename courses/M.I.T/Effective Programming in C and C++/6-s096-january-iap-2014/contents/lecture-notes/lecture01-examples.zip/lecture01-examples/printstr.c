#include <stdio.h>

int main(void) {
  char *str = "I'm a string!";
  // From stdio.h: prints string followed by a newline
  puts( str );
  return 0;
}
