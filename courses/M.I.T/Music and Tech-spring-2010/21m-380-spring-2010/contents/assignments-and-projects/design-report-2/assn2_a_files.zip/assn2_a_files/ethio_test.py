Python 2.6.4 (r264:75708, Oct 26 2009, 07:36:50) [MSC v.1500 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.

    ****************************************************************
    Personal firewall software may warn about the connection IDLE
    makes to its subprocess using this computer's internal loopback
    interface.  This connection is not visible on any external
    interface and no data is sent to or received from the Internet.
    ****************************************************************
    
IDLE 2.6.4      ==== No Subprocess ====
>>> from athenaCL import athenackl
Traceback (most recent call last):
  File "<pyshell#0>", line 1, in <module>
    from athenaCL import athenackl
ImportError: cannot import name athenackl
>>> from athenaCL import athenacl

athenaCL 2.0.0a12 (on win32 via terminal)
Enter "cmd" to see all commands. For help enter "?".
Enter "c" for copyright, "w" for warranty, "r" for credits.

:: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\athenaCL-2.0.0a12\athenaCL-2.0.0a12\setup.py
unknown command. enter "cmd" to see all commands.

pi{}ti{} :: emo m
EventMode mode set to: midi.

pi{}ti{} :: emi
generalMidi instruments:
{number,name}
   0      piano1           
   1      piano2           
   2      piano3           
   3      honkyTonkPiano   
   4      rhodesPiano      
   5      ePiano           
   6      harpsichord      
   7      clavinet         
   8      celesta          
   9      glockenspiel     
   10     musicBox         
   11     vibraphone       
   12     marimba          
   13     xylophone        
   14     tubularBells     
   15     santur           
   16     organ1           
   17     organ2           
   18     organ3           
   19     churchOrgan      
   20     reedOrgan        
   21     accordion        
   22     harmonica        
   23     bandoneon        
   24     nylonGuitar      
   25     steelGuitar      
   26     jazzGuitar       
   27     cleanGuitar      
   28     mutedGuitar      
   29     overDriveGuitar  
   30     distortonGuitar  
   31     guitarHarmonics  
   32     acousticBass     
   33     fingeredBass     
   34     pickedBass       
   35     fretlessBass     
   36     slapBass1        
   37     slapBass2        
   38     synthBass1       
   39     synthBass2       
   40     violin           
   41     viola            
   42     cello            
   43     contraBass       
   44     tremoloStrings   
   45     pizzicatoStrings 
   46     orchestralHarp   
   47     timpani          
   48     strings          
   49     slowStrings      
   50     synthStrings1    
   51     synthStrings2    
   52     choirAahs        
   53     voiceOohs        
   54     synthVox         
   55     orchestraHit     
   56     trumpet          
   57     trombone         
   58     tuba             
   59     mutedTrumpet     
   60     frenchHorn       
   61     brassSection     
   62     synthBrass1      
   63     synthBrass2      
   64     sopranoSax       
   65     altoSax          
   66     tenorSax         
   67     baritoneSax      
   68     oboe             
   69     englishHorn      
   70     bassoon          
   71     clarinet         
   72     piccolo          
   73     flute            
   74     recorder         
   75     panFlute         
   76     bottleBlow       
   77     shakuhachi       
   78     whistle          
   79     ocarina          
   80     squareWave       
   81     sawWave          
   82     synCalliope      
   83     chifferLead      
   84     charang          
   85     soloVoice        
   86     5thSawWave       
   87     bassAndLead      
   88     fantasia         
   89     warmPad          
   90     polySynth        
   91     spaceVoice       
   92     bowedGlass       
   93     metalPad         
   94     haloPad          
   95     sweepPad         
   96     iceRain          
   97     soundTrack       
   98     crystal          
   99     atmosphere       
   100    brightness       
   101    goblins          
   102    echoDrops        
   103    starTheme        
   104    sitar            
   105    banjo            
   106    shamisen         
   107    koto             
   108    kalimba          
   109    bagpipe          
   110    fiddle           
   111    shanai           
   112    tinkleBell       
   113    agogoBells       
   114    steelDrums       
   115    woodBlock        
   116    taikoDrum        
   117    melodicTom1      
   118    synthDrum        
   119    reverseCymbal    
   120    guitarFretnoise  
   121    breathNoise      
   122    seaShore         
   123    birdTweet        
   124    telephoneRing    
   125    helicopterBlade  
   126    applauseNoise    
   127    gunShot          

pi{}ti{} :: tin a1 108; tin a2 107; tin a3 1; tin a4 108; tin a5 15; tin a6 0; tin b 43; tin c1 108; tin c2 8; tin c3 106; tin c4 108; tin c5 4; tin c6 4; tin c7 120; tin d1 115; tin d2 116
TI a1 created.

TI a2 created.

TI a3 created.

TI a4 created.

TI a5 created.

TI a6 created.

TI b created.

TI c1 created.

TI c2 created.

TI c3 created.

TI c4 created.

TI c5 created.

TI c6 created.

TI c7 created.

TI d1 created.

TI d2 created.

pi{auto}ti{d2} :: tio a1; tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1},(n,200,0,1)
TI a1 now active.

TI a1: parameter rhythm updated.

pi{auto}ti{a1} :: tie b whps,e,(bg,rw,(24,18,30,12)),180,60,(ws,t,180,0,120,280)
TI a1: parameter bpm updated.

pi{auto}ti{a1} :: tie a rb, 0.5,0.3,0,.9
TI a1: parameter amplitude updated.

pi{auto}ti{a1} :: tie t 0,80
TI a1: parameter time range updated.

pi{auto}ti{a1} :: tie f a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=7|e=9|f=6|g=10}a:{b=5}b:{a=2|b=3|c=6}c:{b=4|c=3|d=6}d
                    :{c=5|d=2|e=8}e:{d=8|e=2|f=9}f:{e=8|f=2|g=7}g:{f=6|g=1},(c,1)
      TIe ERROR: incorrect arguments: parameter lib error (genPmtrObjs: 
a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3|c=2|d=7|e=9|f=6|g=10}a:{b=5}b:{a
=2|b=3|c=6}c:{b=4|c=3|d=6}d:{c=5|d=2|e=8}e:{d=8|e=2|f=9}f:{e=8|f=2|g=7}g
:{f=6|g=1}, None, ('a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3|c=2|d=7|e=9|
f=6|g=10}a:{b=5}b:{a=2|b=3|c=6}c:{b=4|c=3|d=6}d:{c=5|d=2|e=8}e:{d=8|e=2|
f=9}f:{e=8|f=2|g=7}g:{f=6|g=1}', ['c', 1]))

pi{auto}ti{a1} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=7|e=9|f=6|g=10}a:{b=5}b:{a=2|b=3|c=6}c:{b=4|c=3|d=6}d
                    :{c=5|d=2|e=8}e:{d=8|e=2|f=9}f:{e=8|f=2|g=7}g:{f=6|g=1},(c,1)
TI a1: parameter local field updated.

pi{auto}ti{a1} :: tio a2
TI a2 now active.

pi{auto}ti{a2} :: tie t 4,80
TI a2: parameter time range updated.

pi{auto}ti{a2} :: tils
TextureInstances available:
{name,status,TM,PI,instrument,time,TC}
   a1               + LineGroove  auto        108 00.0--80.0   0
 + a2               + LineGroove  auto        107 04.0--80.0   0
   a3               + LineGroove  auto        1   00.0--20.0   0
   a4               + LineGroove  auto        108 00.0--20.0   0
   a5               + LineGroove  auto        15  00.0--20.0   0
   a6               + LineGroove  auto        0   00.0--20.0   0
   b                + LineGroove  auto        43  00.0--20.0   0
   c1               + LineGroove  auto        108 00.0--20.0   0
   c2               + LineGroove  auto        8   00.0--20.0   0
   c3               + LineGroove  auto        106 00.0--20.0   0
   c4               + LineGroove  auto        108 00.0--20.0   0
   c5               + LineGroove  auto        4   00.0--20.0   0
   c6               + LineGroove  auto        4   00.0--20.0   0
   c7               + LineGroove  auto        120 00.0--20.0   0
   d1               + LineGroove  auto        115 00.0--20.0   0
   d2               + LineGroove  auto        116 00.0--20.0   0

pi{auto}ti{a2} :: tio a1; tie o bpl,e,l,((0,1),(70,2),(140,1),(210,0))
TI a1 now active.

TI a1: parameter local octave updated.

pi{auto}ti{a1} :: tio a2
TI a2 now active.

pi{auto}ti{a2} :: tie t 4,78
TI a2: parameter time range updated.

pi{auto}ti{a2} :: tie r mp,a{6,1}b{7,2}c{6,9}d{16,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=4|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1},(c,0.5)
TI a2: parameter rhythm updated.

pi{auto}ti{a2} :: tie a n,100,1,0,.9
TI a2: parameter amplitude updated.

pi{auto}ti{a2} :: tie r mp,a{6,1}b{7,2}c{6,9}d{16,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=4|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1},(bg,rw,(0,0,0,0,.2,.2,.2,.2,.4,.4,.4,.4,.4,.4,.6,.6,.6,.6,.8,.8,.8,.8,.9,.9)
usage: tie parameter value

pi{auto}ti{a2} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5},(c,0.7)
TI a2: parameter local field updated.

pi{auto}ti{a2} :: tie b ws,200,0,160,240
      TIe ERROR: incorrect arguments: wrong type of data used as an
argument. replace '200' with a string argument type.

pi{auto}ti{a2} :: tie b ws,e,200,0,160,240
TI a2: parameter bpm updated.

pi{auto}ti{a2} :: tiv
TI: a2, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: koto
      status: +, duration: 004.0--78.02
(i)nstrument        107 (generalMidi: koto)
(t)ime range        04.0--78.0
(b)pm               waveSine, event, (constant, 200), 0, (constant,
                    160), (constant, 240)
(r)hythm            markovPulse, a{6,1}b{7,2}c{6,9}d{16,4}e{6,6}:{a=12|b
                    =8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|
                    e=5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}
                    bb:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1
                    }c:{a=6|c=9|e=5}cc:{a=10|b=4|c=4|d=5|e=5}cd:{b=1}ce:
                    {a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5
                    |c=5|d=5|e=1}, (constant, 0.5)
(p)ath              auto
                    (C4)
                    74.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5}, (constant, 0.7)
local (o)ctave      constant, 0
(a)mplitude         noise, 100, (constant, 1), (constant, 0), (constant,
                    0.9)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto}ti{a2} :: tie o ws,e,100,0,-1,0.5
TI a2: parameter local octave updated.

pi{auto}ti{a2} :: tio a3; tie o c,2
TI a3 now active.

TI a3: parameter local octave updated.

pi{auto}ti{a3} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1}, (basketGen, randomWalk,
                    (0,0,0,1,1,1,1,2,2,2,1.5,1.5,0.5,0.5))
TI a3: parameter rhythm updated.

pi{auto}ti{a3} :: tio a2; tie n ws,e,150,0,0,1
TI a2 now active.

TI a2: parameter panning updated.

pi{auto}ti{a2} :: tio a3; tie a bpl,e,l,((0,.9),(20,.5),(50,.2),(70,.4),(80,.8))
TI a3 now active.

TI a3: parameter amplitude updated.

pi{auto}ti{a3} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5}, (constant, 0.75)
TI a3: parameter local field updated.

pi{auto}ti{a3} :: tie n ws,e,300,0,0,1
TI a3: parameter panning updated.

pi{auto}ti{a3} :: tie t 7,70
TI a3: parameter time range updated.

pi{auto}ti{a3} :: ti
TI (TextureInstance) commands:
   TIn              new    
   TIcp             copy   
   TIrm             remove 
   TIo              select 
   TIv              view   
   TIe              edit   
   TIls             list   
   TImode           mode   
   TImute           mute   
   TIdoc            doc    
   TImap            map    
   TImidi           midi   
command? tiv
TI: a3, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: piano2
      status: +, duration: 007.0--70.25
(i)nstrument        1 (generalMidi: piano2)
(t)ime range        07.0--70.0
(b)pm               constant, 120
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1}, (basketGen, randomWalk,
                    (0,0,0,1,1,1,1,2,2,2,1.5,1.5,0.5,0.5))
(p)ath              auto
                    (C4)
                    63.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5}, (constant, 0.75)
local (o)ctave      constant, 2
(a)mplitude         breakPointLinear, event, loop,
                    ((0,0.9),(20,0.5),(50,0.2),(70,0.4),(80,0.8))
pan(n)ing           waveSine, event, (constant, 300), 0, (constant, 0),
                    (constant, 1)
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none


pi{auto}ti{a3} :: tie b ws,100,60,110,180
      TIe ERROR: incorrect arguments: wrong type of data used as an
argument. replace '100' with a string argument type.

pi{auto}ti{a3} ::  tie b ws,e,100,60,110,180
TI a3: parameter bpm updated.

pi{auto}ti{a3} :: tio a4
TI a4 now active.

pi{auto}ti{a4} :: tie b bpl,e,l,((0,70),(15,110),(40,160),(50,220),(75,130),(80,80))
TI a4: parameter bpm updated.

pi{auto}ti{a4} :: tie t 14,80
TI a4: parameter time range updated.

pi{auto}ti{a4} :: tie n n,80,0.3,.7
TI a4: parameter panning updated.

pi{auto}ti{a4} :: tie a rb,0.5,0.3,0,1
TI a4: parameter amplitude updated.

pi{auto}ti{a4} :: tie a rb,0.5,0.3,(bpl,e,l((0,0),(20,0.3)))
      TIe ERROR: incorrect arguments: failed sub-parameter: wrong type
of data used as an argument. replace '((l0,0),(20,0.3))' with a integer
number or string argument type.

pi{auto}ti{a4} :: tie a rb,0.5,0.3,(bpl,e,l,((0,0),(20,0.3))),(bpl,e,l,(0,1),(30,0.7)))
usage: tie parameter value

pi{auto}ti{a4} :: tie a rb,0.5,0.3,bpl,e,l,((0,0),(20,0.3)),bpl,e,l,(0,1),(30,0.7))
usage: tie parameter value

pi{auto}ti{a4} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1},(bg, rw,
                    (0,0,0,1,1,1,1,2,2,2,1.5,1.5,0.5,0.5))
TI a4: parameter rhythm updated.

pi{auto}ti{a4} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5},(n,20,2,0,1)
TI a4: parameter local field updated.

pi{auto}ti{a4} :: tiv
TI: a4, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: kalimba
      status: +, duration: 014.0--80.51
(i)nstrument        108 (generalMidi: kalimba)
(t)ime range        14.0--80.0
(b)pm               breakPointLinear, event, loop,
                    ((0,70),(15,110),(40,160),(50,220),(75,130),(80,80))
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1}, (basketGen, randomWalk,
                    (0,0,0,1,1,1,1,2,2,2,1.5,1.5,0.5,0.5))
(p)ath              auto
                    (C4)
                    66.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5}, (noise, 20, (constant,
                    2), (constant, 0), (constant, 1))
local (o)ctave      constant, 0
(a)mplitude         randomBeta, 0.5, 0.3, (constant, 0), (constant, 1)
pan(n)ing           noise, 80, (constant, 0.3), (constant, 0.7),
                    (constant, 1)
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto}ti{a4} :: tie o bpl,e,l,((20,0),(30,.5),(50,1),(80,.5))
TI a4: parameter local octave updated.

pi{auto}ti{a4} :: tio a5; tie b bg,rp,(0,0,0,0,0,0,0,0,200,180,170,210,220,240,270,0,0,0)
TI a5 now active.

      TIe ERROR: score creation: zero division error: zero cannot be a
divisor.

pi{auto}ti{a5} :: tie b bg,rp,(0,0,0,0,0,0,0,0,200,180,170,210,220,240,270,0,0,0)
      TIe ERROR: score creation: zero division error: zero cannot be a
divisor.
9
pi{auto}ti{a5} :: tie b (bg,rp,(0,0,0,0,0,0,0,0,200,180,170,210,220,240,270,0,0,0))
      TIe ERROR: score creation: zero division error: zero cannot be a
divisor.

pi{auto}ti{a5} :: tie b (bg,rw,(0,0,0,0,0,0,0,0,200,180,170,210,220,240,270,0,0,0))
      TIe ERROR: score creation: zero division error: zero cannot be a
divisor.

pi{auto}ti{a5} :: tie b (bg,oc,(0,0,0,0,0,0,0,0,200,180,170,210,220,240,270,0,0,0))
      TIe ERROR: score creation: zero division error: zero cannot be a
divisor.

pi{auto}ti{a5} :: tie b n,80,0,180,290
TI a5: parameter bpm updated.

pi{auto}ti{a5} :: tiv
TI: a5, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: santur
      status: +, duration: 000.0--20.06
(i)nstrument        15 (generalMidi: santur)
(t)ime range        00.0--20.0
(b)pm               noise, 80, (constant, 0), (constant, 180),
                    (constant, 290)
(r)hythm            pulseTriple, (constant, 4), (basketGen,
                    randomPermutate, (1,1,2,3)), (constant, 1),
                    (constant, 0.75)
(p)ath              auto
                    (C4)
                    20.00(s)
local (f)ield       constant, 0
local (o)ctave      constant, 0
(a)mplitude         randomBeta, 0.4, 0.4, (constant, 0.7), (constant,
                    0.9)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto}ti{a5} :: tie n c,.8
TI a5: parameter panning updated.

pi{auto}ti{a5} :: tie t 18,74
TI a5: parameter time range updated.

pi{auto}ti{a5} :: tie o n,60,0,3,4.5
TI a5: parameter local octave updated.

pi{auto}ti{a5} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1},(c,2)
TI a5: parameter rhythm updated.

pi{auto}ti{a5} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},(bg,oc,(0,0,0,111,1,1,1,1))
TI a5: parameter local field updated.

pi{auto}ti{a5} :: tiv
TI: a5, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: santur
      status: +, duration: 018.0--74.11
(i)nstrument        15 (generalMidi: santur)
(t)ime range        18.0--74.0
(b)pm               noise, 80, (constant, 0), (constant, 180),
                    (constant, 290)
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1}, (constant, 2)
(p)ath              auto
                    (C4)
                    56.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},
                    (basketGen, orderedCyclic, (0,0,0,111,1,1,1,1))
local (o)ctave      noise, 60, (constant, 0), (constant, 3), (constant,
                    4.5)
(a)mplitude         randomBeta, 0.4, 0.4, (constant, 0.7), (constant,
                    0.9)
pan(n)ing           constant, 0.8
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto}ti{a5} :: tils
TextureInstances available:
{name,status,TM,PI,instrument,time,TC}
   a1               + LineGroove  auto        108 00.0--80.0   0
   a2               + LineGroove  auto        107 04.0--78.0   0
   a3               + LineGroove  auto        1   07.0--70.0   0
   a4               + LineGroove  auto        108 14.0--80.0   0
 + a5               + LineGroove  auto        15  18.0--74.0   0
   a6               + LineGroove  auto        0   00.0--20.0   0
   b                + LineGroove  auto        43  00.0--20.0   0
   c1               + LineGroove  auto        108 00.0--20.0   0
   c2               + LineGroove  auto        8   00.0--20.0   0
   c3               + LineGroove  auto        106 00.0--20.0   0
   c4               + LineGroove  auto        108 00.0--20.0   0
   c5               + LineGroove  auto        4   00.0--20.0   0
   c6               + LineGroove  auto        4   00.0--20.0   0
   c7               + LineGroove  auto        120 00.0--20.0   0
   d1               + LineGroove  auto        115 00.0--20.0   0
   d2               + LineGroove  auto        116 00.0--20.0   0

pi{auto}ti{a5} :: tin a7 5
TI a7 created.

pi{auto}ti{a7} :: tio a3; tie a bpl,e,l,((0,0),(50,0),(60,0.6),(70,.9),(100,0.2))
TI a3 now active.

TI a3: parameter amplitude updated.

pi{auto}ti{a3} :: eln; elh
      EventList ath2010.03.13.00.32.35 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.13.00.32.35.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.13.00.32.35.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.13.00.32.35.mid

pi{auto}ti{a3} :: tio a5; tie a bpl,e,l,((0,.9),(40,.6),(30,.5),(60,0),(70,0),(100,.6),(120,0.9))
TI a5 now active.

TI a5: parameter amplitude updated.

pi{auto}ti{a5} :: tio a6
TI a6 now active.

pi{auto}ti{a6} :: tie o n,200,1,2,3.5
TI a6: parameter local octave updated.

pi{auto}ti{a6} :: tie r mp,a{7,1}b{2,2}c{8,3}d{5,4}e{3,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1},(c,1.75)
TI a6: parameter rhythm updated.

pi{auto}ti{a6} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},(bpl,e,l,((0,0),(40,1),(80,0)))
TI a6: parameter local field updated.

pi{auto}ti{a6} :: tiv
TI: a6, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: piano1
      status: +, duration: 000.0--20.16
(i)nstrument        0 (generalMidi: piano1)
(t)ime range        00.0--20.0
(b)pm               constant, 120
(r)hythm            markovPulse, a{7,1}b{2,2}c{8,3}d{5,4}e{3,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1}, (constant, 1.75)
(p)ath              auto
                    (C4)
                    20.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},
                    (breakPointLinear, event, loop,
                    ((0,0),(40,1),(80,0)))
local (o)ctave      noise, 200, (constant, 1), (constant, 2), (constant,
                    3.5)
(a)mplitude         randomBeta, 0.4, 0.4, (constant, 0.7), (constant,
                    0.9)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto}ti{a6} :: tie b ws,e,600,0,80,220
TI a6: parameter bpm updated.

pi{auto}ti{a6} :: tie t 28,82
TI a6: parameter time range updated.

pi{auto}ti{a6} :: tio a7
TI a7 now active.

pi{auto}ti{a7} :: tiv
TI: a7, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: ePiano
      status: +, duration: 018.0--74.03
(i)nstrument        5 (generalMidi: ePiano)
(t)ime range        18.0--74.0
(b)pm               noise, 80, (constant, 0), (constant, 180),
                    (constant, 290)
(r)hythm            pulseTriple, (constant, 4), (basketGen,
                    randomPermutate, (1,1,2,3)), (constant, 1),
                    (constant, 0.75)
(p)ath              auto
                    (C4)
                    56.00(s)
local (f)ield       constant, 0
local (o)ctave      constant, 0
(a)mplitude         randomBeta, 0.4, 0.4, (constant, 0.7), (constant,
                    0.9)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto}ti{a7} :: tie bpm bg,rw,(150,155,145,130,130,135,120,135)
TI a7: parameter bpm updated.

pi{auto}ti{a7} :: tie r mp,a{8,1}b{8,4}c{8,7}d{8,11}e{8,15}:{a=9|b
                    =8|c=6|d=7|e=2}a:{a=3|b=2|c=2|d=3|e=2}b:{a=5|d=4|e=1
                    }c:{a=6|c=2|e=5}d:{a=2|b=10}e:{a=5|b=2|c=5|d=5|e=1},
                    (c,.6)
TI a7: parameter rhythm updated.

pi{auto}ti{a7} :: tie a mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},(c,.9)
TI a7: parameter amplitude updated.

pi{auto}ti{a7} :: tie n 0.3
      TIe ERROR: object creation: incorrect data-type in arguments.
'float' object is unsubscriptable

pi{auto}ti{a7} :: tie n c,.3
TI a7: parameter panning updated.

pi{auto}ti{a7} :: tiv
TI: a7, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: ePiano
      status: +, duration: 018.0--74.79
(i)nstrument        5 (generalMidi: ePiano)
(t)ime range        18.0--74.0
(b)pm               basketGen, randomWalk,
                    (150,155,145,130,130,135,120,135)
(r)hythm            markovPulse, a{8,1}b{8,4}c{8,7}d{8,11}e{8,15}:{a=9|b
                    =8|c=6|d=7|e=2}a:{a=3|b=2|c=2|d=3|e=2}b:{a=5|d=4|e=1
                    }c:{a=6|c=2|e=5}d:{a=2|b=10}e:{a=5|b=2|c=5|d=5|e=1},
                    (constant, 0.6)
(p)ath              auto
                    (C4)
                    56.00(s)
local (f)ield       constant, 0
local (o)ctave      constant, 0
(a)mplitude         markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},
                    (constant, 0.9)
pan(n)ing           constant, 0.3
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto}ti{a7} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},(c,.9)
TI a7: parameter local field updated.

pi{auto}ti{a7} :: tie a bg,rw,(0,0,0,0,0,.8,.6,.6,.6,.9,.9,.9)
TI a7: parameter amplitude updated.

pi{auto}ti{a7} :: tie o c,.5
TI a7: parameter local octave updated.

pi{auto}ti{a7} :: tio b
TI b now active.

pi{auto}ti{b} :: tiv
TI: b, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: contraBass
      status: +, duration: 000.0--20.06
(i)nstrument        43 (generalMidi: contraBass)
(t)ime range        00.0--20.0
(b)pm               constant, 120
(r)hythm            pulseTriple, (constant, 4), (basketGen,
                    randomPermutate, (1,1,2,3)), (constant, 1),
                    (constant, 0.75)
(p)ath              auto
                    (C4)
                    20.00(s)
local (f)ield       constant, 0
local (o)ctave      constant, 0
(a)mplitude         randomBeta, 0.4, 0.4, (constant, 0.7), (constant,
                    0.9)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto}ti{b} :: tie t 60,120
TI b: parameter time range updated.

pi{auto}ti{b} :: tie bpm c,130
TI b: parameter bpm updated.

pi{auto}ti{b} :: tie f {-3}b{0}c{1}d{5}e{6}f{9}g{13}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},(c,1)
      TIe ERROR: incorrect arguments: parameter lib error (genPmtrObjs: 
{-3}b{0}c{1}d{5}e{6}f{9}g{13}:{a=1|b=3|c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=
2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1}, None, ('{
-3}b{0}c{1}d{5}e{6}f{9}g{13}:{a=1|b=3|c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2
|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1}', ['c',
1]))

pi{auto}ti{b} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{13}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},(c,1)
TI b: parameter local field updated.

pi{auto}ti{b} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}
                    c:{a=6|c=9|e=5}d:{a=2|b=10}e:{a=10|b=5|
                    c=5|d=5|e=1},(n,10,1,0,1)
TI b: parameter rhythm updated.

pi{auto}ti{b} :: tie r mp,a{6,1}b{6,2}c{6,6}d{6,10}e{6,12}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}
                    c:{a=6|c=9|e=5}d:{a=2|b=10}e:{a=10|b=5|
                    c=5|d=5|e=4},(n,10,1,0,1)
TI b: parameter rhythm updated.

pi{auto}ti{b} :: tiv
TI: b, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: contraBass
      status: +, duration: 0060.0--120.08
(i)nstrument        43 (generalMidi: contraBass)
(t)ime range        060.0--120.0
(b)pm               constant, 130
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,6}d{6,10}e{6,12}:{a=12|
                    b=8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}b:{a=5|d=10|
                    e=1}bb:{a=2|b=6}c:{a=6|c=9|e=5}d:{a=2|b=10}e:{a=10|b
                    =5|c=5|d=5|e=4}, (noise, 10, (constant, 1),
                    (constant, 0), (constant, 1))
(p)ath              auto
                    (C4)
                    60.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{13}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},
                    (constant, 1)
local (o)ctave      constant, 0
(a)mplitude         randomBeta, 0.4, 0.4, (constant, 0.7), (constant,
                    0.9)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto}ti{b} :: tie a bpl,e,l,((0,0),(10,.3),(30,.6),(40,.5),(60,.3),(80,.7,),(100,.9),(110,60),(125,.7),(135,.4),(150,0))
TI b: parameter amplitude updated.

pi{auto}ti{b} :: tio c1; tie t 65,110
TI c1 now active.

TI c1: parameter time range updated.

pi{auto}ti{c1} :: tie n ws,200,0,0,1; tie a rb,0.5,.2,0,1
      TIe ERROR: incorrect arguments: wrong type of data used as an
argument. replace '200' with a string argument type.

TI c1: parameter amplitude updated.

pi{auto}ti{c1} :: tie n ws,e,200,0,0,1
TI c1: parameter panning updated.

pi{auto}ti{c1} :: tie o whps,100,0,-1,1.5
      TIe ERROR: incorrect arguments: wrong type of data used as an
argument. replace '100' with a string argument type.

pi{auto}ti{c1} :: tie o whps,e,100,0,-1,1.5
TI c1: parameter local octave updated.

pi{auto}ti{c1} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,12}:{
                    a=15|b=4|c=1|d=4|e=2|f=5}a:{a=8|b=5|c=1|f=5}b:{a=8|b
                    =5|c=4|d=10|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=10|c
                    =1|d=3|e=2|f=1}e:{a=6|b=5|c=5|d=1|e=1|f=1}f:{a=8|b=6
                    |c=4|d=1|e=1},(c,.5)
TI c1: parameter rhythm updated.

pi{auto}ti{c1} :: tie a mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5},(ws,e,40,0,0,1)
TI c1: parameter amplitude updated.

pi{auto}ti{c1} :: tiv
TI: c1, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: kalimba
      status: +, duration: 0065.0--110.17
(i)nstrument        108 (generalMidi: kalimba)
(t)ime range        065.0--110.0
(b)pm               constant, 120
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,12}:{
                    a=15|b=4|c=1|d=4|e=2|f=5}a:{a=8|b=5|c=1|f=5}b:{a=8|b
                    =5|c=4|d=10|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=10|c
                    =1|d=3|e=2|f=1}e:{a=6|b=5|c=5|d=1|e=1|f=1}f:{a=8|b=6
                    |c=4|d=1|e=1}, (constant, 0.5)
(p)ath              auto
                    (C4)
                    45.00(s)
local (f)ield       constant, 0
local (o)ctave      waveHalfPeriodSine, event, (constant, 100), 0,
                    (constant, -1), (constant, 1.5)
(a)mplitude         markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5}, (waveSine, event,
                    (constant, 40), 0, (constant, 0), (constant, 1))
pan(n)ing           waveSine, event, (constant, 200), 0, (constant, 0),
                    (constant, 1)
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto}ti{c1} :: tie f a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5},(ws,e,100,0,0,1)
      TIe ERROR: incorrect arguments: parameter lib error (genPmtrObjs: 
a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17}:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h
=2|i=1}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{
f=6|h=4}h:{g=4|i=2}i:{h=5}, None, ('a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i
{17}:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}
d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|h=4}h:{g=4|i=2}i:{h=5}', ['ws',
'e', 100, 0, 0, 1]))

pi{auto}ti{c1} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5},(ws,e,100,0,0,1)
TI c1: parameter local field updated.

pi{auto}ti{c1} :: tie a bg,rp,(0,0,0,0,0,.4,.4,.5,.5,.2,.2,.7,.8,.8,.9)
TI c1: parameter amplitude updated.

pi{auto}ti{c1} :: tiv
TI: c1, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: kalimba
      status: +, duration: 0065.0--110.17
(i)nstrument        108 (generalMidi: kalimba)
(t)ime range        065.0--110.0
(b)pm               constant, 120
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,12}:{
                    a=15|b=4|c=1|d=4|e=2|f=5}a:{a=8|b=5|c=1|f=5}b:{a=8|b
                    =5|c=4|d=10|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=10|c
                    =1|d=3|e=2|f=1}e:{a=6|b=5|c=5|d=1|e=1|f=1}f:{a=8|b=6
                    |c=4|d=1|e=1}, (constant, 0.5)
(p)ath              auto
                    (C4)
                    45.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5}, (waveSine, event,
                    (constant, 100), 0, (constant, 0), (constant, 1))
local (o)ctave      waveHalfPeriodSine, event, (constant, 100), 0,
                    (constant, -1), (constant, 1.5)
(a)mplitude         basketGen, randomPermutate,
                    (0,0,0,0,0,0.4,0.4,0.5,0.5,0.2,0.2,0.7,0.8,0.8,0.9)
pan(n)ing           waveSine, event, (constant, 200), 0, (constant, 0),
                    (constant, 1)
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto}ti{c1} :: tie b c,130
TI c1: parameter bpm updated.

pi{auto}ti{c1} :: tio b; tiv
TI b now active.

TI: b, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: contraBass
      status: +, duration: 0060.0--120.15
(i)nstrument        43 (generalMidi: contraBass)
(t)ime range        060.0--120.0
(b)pm               constant, 130
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,6}d{6,10}e{6,12}:{a=12|
                    b=8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}b:{a=5|d=10|
                    e=1}bb:{a=2|b=6}c:{a=6|c=9|e=5}d:{a=2|b=10}e:{a=10|b
                    =5|c=5|d=5|e=4}, (noise, 10, (constant, 1),
                    (constant, 0), (constant, 1))
(p)ath              auto
                    (C4)
                    60.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{13}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},
                    (constant, 1)
local (o)ctave      constant, 0
(a)mplitude         breakPointLinear, event, loop, ((0,0),(10,0.3),(30,0
                    .6),(40,0.5),(60,0.3),(80,0.7),(100,0.9),(110,60),(1
                    25,0.7),(135,0.4),(150,0))
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto}ti{b} :: tio c2; tie b c,130; tie t 68,118
TI c2 now active.

TI c2: parameter bpm updated.

TI c2: parameter time range updated.

pi{auto}ti{c2} :: tie a mv,a{-6}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5},(c,0)
TI c2: parameter amplitude updated.

pi{auto}ti{c2} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|
                    b=8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}b:{a=5|d=10|
                    e=1}bb:{a=2|b=6}c:{a=2|c=9|e=5}d:{a=2|b=10}e:{a=10|b
                    =5|c=5|d=5|e=4},(c,0.3)
TI c2: parameter rhythm updated.

pi{auto}ti{c2} :: tiv
TI: c2, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: celesta
      status: +, duration: 0068.0--118.08
(i)nstrument        8 (generalMidi: celesta)
(t)ime range        068.0--118.0
(b)pm               constant, 130
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}b:{a=5|d=10|e=
                    1}bb:{a=2|b=6}c:{a=2|c=9|e=5}d:{a=2|b=10}e:{a=10|b=5
                    |c=5|d=5|e=4}, (constant, 0.3)
(p)ath              auto
                    (C4)
                    50.00(s)
local (f)ield       constant, 0
local (o)ctave      constant, 0
(a)mplitude         markovValue, a{-6}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5}, (constant, 0)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto}ti{c2} :: tie o n,40,2,1.5,2.5
TI c2: parameter local octave updated.

pi{auto}ti{c2} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{13}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},
                    (ws,e,200,0,0,1)
TI c2: parameter local field updated.

pi{auto}ti{c2} :: tiv
TI: c2, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: celesta
      status: +, duration: 068.0--118.0
(i)nstrument        8 (generalMidi: celesta)
(t)ime range        068.0--118.0
(b)pm               constant, 130
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}b:{a=5|d=10|e=
                    1}bb:{a=2|b=6}c:{a=2|c=9|e=5}d:{a=2|b=10}e:{a=10|b=5
                    |c=5|d=5|e=4}, (constant, 0.3)
(p)ath              auto
                    (C4)
                    50.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{13}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},
                    (waveSine, event, (constant, 200), 0, (constant, 0),
                    (constant, 1))
local (o)ctave      noise, 40, (constant, 2), (constant, 1.5),
                    (constant, 2.5)
(a)mplitude         markovValue, a{-6}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5}, (constant, 0)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto}ti{c2} :: tio c3
TI c3 now active.

pi{auto}ti{c3} :: tie t 72,120
TI c3: parameter time range updated.

pi{auto}ti{c3} :: tie o bpl,e,l((0,0),(20,-.5),(35,-1),(50,1),(60,0.5),(70,0))
      TIe ERROR: incorrect arguments: wrong type of data used as an
argument. replace '((l0,0),(20,-0.5),(35,-1),(50,1),(60,0.5),(70,0))'
with a integer number or string argument type.

pi{auto}ti{c3} :: tie o bpl,e,l,((0,0),(20,-.5),(35,-1),(50,1),(60,0.5),(70,0))
TI c3: parameter local octave updated.

pi{auto}ti{c3} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4}b:{a=5|d=10|e=
                    1}bb:{a=2|b=6}c:{a=2|c=9|e=5}d:{a=2|b=10}e:{a=10|b=5
                    |c=5|d=5|e=4},(c,1)
TI c3: parameter rhythm updated.

pi{auto}ti{c3} :: tiv
TI: c3, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: shamisen
      status: +, duration: 0072.0--120.08
(i)nstrument        106 (generalMidi: shamisen)
(t)ime range        072.0--120.0
(b)pm               constant, 120
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4}b:{a=5|d=10|e=1}bb:{a=2|b=
                    6}c:{a=2|c=9|e=5}d:{a=2|b=10}e:{a=10|b=5|c=5|d=5|e=4
                    }, (constant, 1)
(p)ath              auto
                    (C4)
                    48.00(s)
local (f)ield       constant, 0
local (o)ctave      breakPointLinear, event, loop,
                    ((0,0),(20,-0.5),(35,-1),(50,1),(60,0.5),(70,0))
(a)mplitude         randomBeta, 0.4, 0.4, (constant, 0.7), (constant,
                    0.9)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto}ti{c3} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{13}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},
                    (bg,rw,(0,0,0,0,1,1,1,1,0.5,.5))
TI c3: parameter local field updated.

pi{auto}ti{c3} :: tie a gd,10,0,0,1
      TIe ERROR: incorrect arguments: parameter lib error (genPmtrObjs:
gd, None, ('gd', 10, 0, 0, 1))

pi{auto}ti{c3} :: tie a bd,0.2,0.4,0,.9
      TIe ERROR: incorrect arguments: parameter lib error (genPmtrObjs:
bd, None, ('bd', 0.20000000000000001, 0.40000000000000002, 0,
0.90000000000000002))

pi{auto}ti{c3} :: tie a rb,0.2,0.4,0,1
TI c3: parameter amplitude updated.

pi{auto}ti{c3} :: tiv
TI: c3, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: shamisen
      status: +, duration: 0072.0--120.08
(i)nstrument        106 (generalMidi: shamisen)
(t)ime range        072.0--120.0
(b)pm               constant, 120
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4}b:{a=5|d=10|e=1}bb:{a=2|b=
                    6}c:{a=2|c=9|e=5}d:{a=2|b=10}e:{a=10|b=5|c=5|d=5|e=4
                    }, (constant, 1)
(p)ath              auto
                    (C4)
                    48.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{13}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},
                    (basketGen, randomWalk, (0,0,0,0,1,1,1,1,0.5,0.5))
local (o)ctave      breakPointLinear, event, loop,
                    ((0,0),(20,-0.5),(35,-1),(50,1),(60,0.5),(70,0))
(a)mplitude         randomBeta, 0.2, 0.4, (constant, 0), (constant, 1)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto}ti{c3} :: tie n n,300,1,0.4,.6
TI c3: parameter panning updated.

pi{auto}ti{c3} :: tie b c,130
TI c3: parameter bpm updated.

pi{auto}ti{c3} :: tio c4; tie b c,130; tie t 75,108
TI c4 now active.

TI c4: parameter bpm updated.

TI c4: parameter time range updated.

pi{auto}ti{c4} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,9}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=5|b=2}b:{a=5|d=10|e=1}bb:{a=2|b=
                    6}c:{a=2|c=9|e=5}d:{a=2|b=12}e:{a=10|b=5|c=5|d=5|e=4
                    },(c,0.2)
TI c4: parameter rhythm updated.

pi{auto}ti{c4} :: tie a bpl,e,l,((0,0),(40,.4),(60,.6),(90,.2),(120,0))
TI c4: parameter amplitude updated.

pi{auto}ti{c4} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{13}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},(bg,oc,(0,.2,.4,.5,.7,.8,.9,1))
TI c4: parameter local field updated.

pi{auto}ti{c4} :: tiv
TI: c4, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: kalimba
      status: +, duration: 075.0--108.0
(i)nstrument        108 (generalMidi: kalimba)
(t)ime range        075.0--108.0
(b)pm               constant, 130
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,9}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=5|b=2}b:{a=5|d=10|e=1}bb:{a=2|b=6
                    }c:{a=2|c=9|e=5}d:{a=2|b=12}e:{a=10|b=5|c=5|d=5|e=4}
                    , (constant, 0.2)
(p)ath              auto
                    (C4)
                    33.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{13}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},
                    (basketGen, orderedCyclic,
                    (0,0.2,0.4,0.5,0.7,0.8,0.9,1))
local (o)ctave      constant, 0
(a)mplitude         breakPointLinear, event, loop,
                    ((0,0),(40,0.4),(60,0.6),(90,0.2),(120,0))
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto}ti{c4} :: tie o c,-.5
TI c4: parameter local octave updated.

pi{auto}ti{c4} :: tio c5
TI c5 now active.

pi{auto}ti{c5} :: tie b c,130
TI c5: parameter bpm updated.

pi{auto}ti{c5} :: tie t,78,128
usage: tie parameter value

pi{auto}ti{c5} :: tie t 78,128
TI c5: parameter time range updated.

pi{auto}ti{c5} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{13}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},
                    (bg,rw,(0,0,0,0,1,1,1,1,0.5,.5))
TI c5: parameter local field updated.

pi{auto}ti{c5} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,9}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=8|b=2}b:{a=5|d=10|e=1}bb:{a=2|b=6
                    }c:{a=2|c=12|e=5}d:{a=2|b=12}e:{a=10|b=5|c=5|d=5|e=4}
                    ,(ws,e,100,0,0,1)
TI c5: parameter rhythm updated.

pi{auto}ti{c5} :: tie a bg,rw(1,1,1,.6,.6,.6,.6,.3,.3,0,0,0,0,0,0,0,0)
      TIe ERROR: incorrect arguments: wrong type of data used as an
argument. replace '(rw1,1,1,0.6,0.6,0.6,0.6,0.3,0.3,0,0,0,0,0,0,0,0)'
with a string argument type.

pi{auto}ti{c5} :: tie a bg,rw,(1,1,1,.6,.6,.6,.6,.3,.3,0,0,0,0,0,0,0,0)
TI c5: parameter amplitude updated.

pi{auto}ti{c5} :: tiv
TI: c5, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: rhodesPiano
      status: +, duration: 0078.0--128.08
(i)nstrument        4 (generalMidi: rhodesPiano)
(t)ime range        078.0--128.0
(b)pm               constant, 130
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,9}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=8|b=2}b:{a=5|d=10|e=1}bb:{a=2|b=6
                    }c:{a=2|c=12|e=5}d:{a=2|b=12}e:{a=10|b=5|c=5|d=5|e=4
                    }, (waveSine, event, (constant, 100), 0, (constant,
                    0), (constant, 1))
(p)ath              auto
                    (C4)
                    50.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{13}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},
                    (basketGen, randomWalk, (0,0,0,0,1,1,1,1,0.5,0.5))
local (o)ctave      constant, 0
(a)mplitude         basketGen, randomWalk,
                    (1,1,1,0.6,0.6,0.6,0.6,0.3,0.3,0,0,0,0,0,0,0,0)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto}ti{c5} :: tie n c,0.8
TI c5: parameter panning updated.

pi{auto}ti{c5} :: tie o c,3
TI c5: parameter local octave updated.

pi{auto}ti{c5} :: tio c6; tie b c,130; tie t 80,122; tie r 

>>> tio c6; tie b c,130; tie t 80,122; tie r
SyntaxError: invalid syntax
>>> 
>>> 
>>> 
>>> pi{auto}ti{c5} :: tio c6; tie b c,130; tie t 80,122; tie r
SyntaxError: invalid syntax
>>> 
>>> from athenaCL import athenacl
>>> 
>>> 
>>> tie ghte
SyntaxError: invalid syntax
>>> thrhe
Traceback (most recent call last):
  File "<pyshell#12>", line 1, in <module>
    thrhe
NameError: name 'thrhe' is not defined
>>> cmd
Traceback (most recent call last):
  File "<pyshell#13>", line 1, in <module>
    cmd
NameError: name 'cmd' is not defined
>>> last.cmd
Traceback (most recent call last):
  File "<pyshell#14>", line 1, in <module>
    last.cmd
NameError: name 'last' is not defined
>>> lastcmd
Traceback (most recent call last):
  File "<pyshell#15>", line 1, in <module>
    lastcmd
NameError: name 'lastcmd' is not defined
>>> cmd.lastcmd
Traceback (most recent call last):
  File "<pyshell#16>", line 1, in <module>
    cmd.lastcmd
NameError: name 'cmd' is not defined
>>> Cmd.lastcmd
Traceback (most recent call last):
  File "<pyshell#17>", line 1, in <module>
    Cmd.lastcmd
NameError: name 'Cmd' is not defined
>>> cmd.lastCmd
Traceback (most recent call last):
  File "<pyshell#18>", line 1, in <module>
    cmd.lastCmd
NameError: name 'cmd' is not defined
>>> 
