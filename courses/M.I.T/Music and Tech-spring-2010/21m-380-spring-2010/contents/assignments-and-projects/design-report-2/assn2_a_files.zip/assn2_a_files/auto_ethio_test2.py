Python 2.6.4 (r264:75708, Oct 26 2009, 07:36:50) [MSC v.1500 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.

    ****************************************************************
    Personal firewall software may warn about the connection IDLE
    makes to its subprocess using this computer's internal loopback
    interface.  This connection is not visible on any external
    interface and no data is sent to or received from the Internet.
    ****************************************************************
    
IDLE 2.6.4      ==== No Subprocess ====
>>> from athenaCL import athenacl

athenaCL 2.0.0a12 (on win32 via terminal)
Enter "cmd" to see all commands. For help enter "?".
Enter "c" for copyright, "w" for warranty, "r" for credits.

:: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\athenaCL-2.0.0a12\athenaCL-2.0.0a12\setup.py
unknown command. enter "cmd" to see all commands.

pi{}ti{} :: emo m; tin a 4
EventMode mode set to: midi.

TI a created.

pi{auto}ti{a} :: tie a mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17}:{a=1|b=3|c=2|d=5|e=9|f=6|g=5|h=2|i=1}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|h=4}h:{g=4|i=2}i:{h=5},(c=0.75)
      TIe ERROR: incorrect arguments: failed sub-parameter: parameter
lib error (genPmtrObjs: c=0.75, None, ['c=0.75'])

pi{auto}ti{a} :: tie a t 0,60
      TIe ERROR: incorrect arguments: parameter lib error (genPmtrObjs:
t0, None, ('t0', 60))

pi{auto}ti{a} :: whps
unknown command. enter "cmd" to see all commands.

pi{auto}ti{a} :: ?wshp
no help for: "wshp"

pi{auto}ti{a} :: ?whps
no help for: "whps"

pi{auto}ti{a} :: tie a mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17}:{a=1|b=3|c=2|d=5|e=9|f=6|g=5|h=2|i=1}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|h=4}h:{g=4|i=2}i:{h=5}
TI a: parameter amplitude updated.

pi{auto}ti{a} :: tie a mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17}:{a=1|b=3|c=2|d=5|e=9|f=6|g=5|h=2|i=1}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|h=4}h:{g=4|i=2}i:{h=5},(c,0.75)
TI a: parameter amplitude updated.

pi{auto}ti{a} :: tie r mv,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a=9|b=7|c=4|d=5|e=2|f=1}a:{a=3|b=2|c=1|f=8}b:{a=6|b=5|c=4|d=3|e=2|f=1}c:{a=3|b=7|c=5|d=2}d:{a=2|b=3|c=7|d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c=4|d=2|e=1},(c,1)
      TIe ERROR: incorrect arguments: parameter lib error (rthmPmtrObjs:
mv, None, ('mv', 'a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a=9|b=7|c=4|d=5|
e=2|f=1}a:{a=3|b=2|c=1|f=8}b:{a=6|b=5|c=4|d=3|e=2|f=1}c:{a=3|b=7|c=5|d=2
}d:{a=2|b=3|c=7|d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c=4|d=
2|e=1}', ['c', 1]))

pi{auto}ti{a} :: eln; elh
      EventList ath2010.03.11.15.32.28 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.32.28.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.32.28.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.32.28.mid

pi{auto}ti{a} :: tie a ls,e,30,0,.9
TI a: parameter amplitude updated.

pi{auto}ti{a} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17}:{a=1|b=3|c=2|d=5|e=9|f=6|g=5|h=2|i=1}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|h=4}h:{g=4|i=2}i:{h=5},(c,0.75)
TI a: parameter local field updated.

pi{auto}ti{a} :: eln; elh
      EventList ath2010.03.11.15.33.12 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.33.12.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.33.12.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.33.12.mid

pi{auto}ti{a} ::  ?om
{topic,documentation}
AOmg                AOmg: AthenaObject: Merge: Merges a selected XML
                    AthenaObject with the current AthenaObject.
AOmg usage:         aomg filename.xml
gfxCommand          This command uses the active graphic output format;
                    this can be selected with the "APgfx" command.
                    Output in "tk" requires the Python Tkinter GUI
                    installation; output in "png" and "jpg" requires the
                    Python Imaging Library (PIL) library installation;
                    output in "eps" and "text" do not require any
                    additional software or configuration.

pi{auto}ti{a} :: ?whpt
no help for: "whpt"

pi{auto}ti{a} :: tie b ws,e,(bg,rw,(80,110,120,130,150)),0,80,150
TI a: parameter bpm updated.

pi{auto}ti{a} :: eln; elh
      EventList ath2010.03.11.15.35.25 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.35.25.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.35.25.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.35.25.mid

pi{auto}ti{a} :: tie a 
usage: tie parameter value

pi{auto}ti{a} :: tie a (c,.8
usage: tie parameter value

pi{auto}ti{a} :: tie a (c,0,8)
      TIe ERROR: incorrect arguments: too many arguments; enter 2
arguments.

pi{auto}ti{a} :: tie a (c,0.8)
TI a: parameter amplitude updated.

pi{auto}ti{a} :: tie r mv,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a=12|b=7|c=4|d=5|e=2|f=1}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=3|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=3|c=7|d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c=4|d=2|e=1},(c,0.75)
      TIe ERROR: incorrect arguments: parameter lib error (rthmPmtrObjs:
mv, None, ('mv', 'a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a=12|b=7|c=4|d=5
|e=2|f=1}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=3|e=2|f=1}c:{a=3|b=9|c=5|d=
2}d:{a=2|b=3|c=7|d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c=4|d
=2|e=1}', ['c', 0.75]))

pi{auto}ti{a} :: tie r mv,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a=12|b=7|c=4|d=5|e=2|f=1}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=3|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=3|c=7|d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c=4|d=2|e=1},(c,0.75)
      TIe ERROR: incorrect arguments: parameter lib error (rthmPmtrObjs:
mv, None, ('mv', 'a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a=12|b=7|c=4|d=5
|e=2|f=1}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=3|e=2|f=1}c:{a=3|b=9|c=5|d=
2}d:{a=2|b=3|c=7|d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c=4|d
=2|e=1}', ['c', 0.75]))

pi{auto}ti{a} :: tie r mv,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a=12|b=7|c=4|d=5|e=2|f=1}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=3|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=3|c=7|d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c=4|d=2|e=1}
      TIe ERROR: incorrect arguments: parameter lib error (rthmPmtrObjs:
mv, None, ('mv', 'a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a=12|b=7|c=4|d=5
|e=2|f=1}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=3|e=2|f=1}c:{a=3|b=9|c=5|d=
2}d:{a=2|b=3|c=7|d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c=4|d
=2|e=1}'))

pi{auto}ti{a} :: tie
edit TI a
which parameter? (i,t,b,r,p,f,o,a,n,x,s,d): r
current rhythm: pulseTriple, (constant, 4), (basketGen, randomPermutate,
(1,1,2,3)), (constant, 1), (constant, 0.75)
new value: mv,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a=12|b=7|c=4|d=5|e=2|f=1}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=3|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=3|c=7|d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c=4|d=2|e=1}
      TIe ERROR: incorrect arguments: parameter lib error (rthmPmtrObjs:
mv, None, ('mv', 'a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a=12|b=7|c=4|d=5
|e=2|f=1}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=3|e=2|f=1}c:{a=3|b=9|c=5|d=
2}d:{a=2|b=3|c=7|d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c=4|d
=2|e=1}'))

pi{auto}ti{a} :: tie r mv,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a=10|b=7|c=4|d=5|e=2|f=1}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=3|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=3|c=7|d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c=4|d=2|e=1},(c,0.75)
      TIe ERROR: incorrect arguments: parameter lib error (rthmPmtrObjs:
mv, None, ('mv', 'a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a=10|b=7|c=4|d=5
|e=2|f=1}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=3|e=2|f=1}c:{a=3|b=9|c=5|d=
2}d:{a=2|b=3|c=7|d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c=4|d
=2|e=1}', ['c', 0.75]))

pi{auto}ti{a} :: tie r mp\,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a=10|b=7|c=4|d=5|e=2|f=1}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=3|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=3|c=7|d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c=4|d=2|e=1},(c,0.75)
      TIe ERROR: incorrect arguments: parameter lib error (rthmPmtrObjs:
mp\, None, ('mp\\', 'a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a=10|b=7|c=4|
d=5|e=2|f=1}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=3|e=2|f=1}c:{a=3|b=9|c=5
|d=2}d:{a=2|b=3|c=7|d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c=
4|d=2|e=1}', ['c', 0.75]))

pi{auto}ti{a} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a=10|b=7|c=4|d=5|e=2|f=1}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=3|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=3|c=7|d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c=4|d=2|e=1},(c,0.75)
TI a: parameter rhythm updated.

pi{auto}ti{a} :: eln; elh
      EventList ath2010.03.11.15.40.50 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.40.50.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.40.50.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.40.50.mid

pi{auto}ti{a} :: tiv
TI: a, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: rhodesPiano
      status: +, duration: 000.0--20.06
(i)nstrument        4 (generalMidi: rhodesPiano)
(t)ime range        00.0--20.0
(b)pm               waveSine, event, (basketGen, randomWalk,
                    (80,110,120,130,150)), 0, (constant, 80), (constant,
                    150)
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a
                    =10|b=7|c=4|d=5|e=2|f=1}a:{a=8|b=5|c=1|f=5}b:{a=8|b=
                    5|c=4|d=3|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=3|c=7|
                    d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c=
                    4|d=2|e=1}, (constant, 0.75)
(p)ath              auto
                    (C4)
                    20.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=5|h=2|i=1}a:{b=5}b:{a=2
                    |c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{
                    f=6|h=4}h:{g=4|i=2}i:{h=5}, (constant, 0.75)
local (o)ctave      constant, 0
(a)mplitude         constant, 0.8
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto}ti{a} :: tie t 0,60
TI a: parameter time range updated.

pi{auto}ti{a} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a=10|b=7|c=4|d=5|e=2|f=1}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=3|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=3|c=7|d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c=4|d=2|e=1},(bg,oc,(0.5,1,.5))
TI a: parameter rhythm updated.

pi{auto}ti{a} :: eln; elh
      EventList ath2010.03.11.15.44.03 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.44.03.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.44.03.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.44.03.mid

pi{auto}ti{a} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,12}:{a=15|b=7|c=4|d=5|e=2|f=5}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=3|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=3|c=7|d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c=4|d=2|e=1},(c,1)
TI a: parameter rhythm updated.

pi{auto}ti{a} :: tie b (c,135)
TI a: parameter bpm updated.

pi{auto}ti{a} :: eln; elh
      EventList ath2010.03.11.15.45.55 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.45.55.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.45.55.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.45.55.mid

pi{auto}ti{a} :: emo mp; tin b 38; tie a (c,0.3); tie r pt,(c,1),(c,1),(c,1)
EventMode mode set to: midiPercussion.

TI b created.

TI b: parameter amplitude updated.

TI b: parameter rhythm updated.

pi{auto-acousticSnare}ti{b} :: tio b
TI b now active.

pi{auto-acousticSnare}ti{b} :: tie t 0,60; tie b (c,135)
TI b: parameter time range updated.

TI b: parameter bpm updated.

pi{auto-acousticSnare}ti{b} :: eln; elh
      EventList ath2010.03.11.15.46.58 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.46.58.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.46.58.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.46.58.mid

pi{auto-acousticSnare}ti{b} :: tio a
TI a now active.

pi{auto-acousticSnare}ti{a} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,12}:{a=20|b=2|c=4|d=2|e=2|f=5}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=3|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=3|c=7|d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c=4|d=2|e=1},(c,1)
TI a: parameter rhythm updated.

pi{auto-acousticSnare}ti{a} :: eln; elh
      EventList ath2010.03.11.15.48.19 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.48.19.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.48.19.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.48.19.mid

pi{auto-acousticSnare}ti{a} :: tie o (bg,rp,(-1.5,-1,-0.5,0,0.5,1,1.5))
TI a: parameter local octave updated.

pi{auto-acousticSnare}ti{a} :: eln; elh
      EventList ath2010.03.11.15.49.36 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.49.36.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.49.36.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.49.36.mid

pi{auto-acousticSnare}ti{a} :: tie o c,1
TI a: parameter local octave updated.

pi{auto-acousticSnare}ti{a} :: tie o c,0
TI a: parameter local octave updated.

pi{auto-acousticSnare}ti{a} :: eln; elh
      EventList ath2010.03.11.15.50.07 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.50.07.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.50.07.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.50.07.mid

pi{auto-acousticSnare}ti{a} :: ?bpl
no help for: "bpl"

pi{auto-acousticSnare}ti{a} :: bpl
unknown command. enter "cmd" to see all commands.

pi{auto-acousticSnare}ti{a} :: tie b ws,e,(ls,e,50,10,30),0,0,10
TI a: parameter bpm updated.

pi{auto-acousticSnare}ti{a} :: timute b
TI b is now muted.

pi{auto-acousticSnare}ti{a} :: eln; ekh
      EventList ath2010.03.11.15.51.26 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.51.26.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.51.26.xml

unknown command. enter "cmd" to see all commands.

pi{auto-acousticSnare}ti{a} :: eln; elh
      EventList ath2010.03.11.15.51.32 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.51.32.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.51.32.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.51.32.mid

pi{auto-acousticSnare}ti{a} :: tie b ws,e,(ls,e,100,80,60),0,80,150
TI a: parameter bpm updated.

pi{auto-acousticSnare}ti{a} :: eln; elh
      EventList ath2010.03.11.15.52.07 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.52.07.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.52.07.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.15.52.07.mid

pi{auto-acousticSnare}ti{a} :: tpmap 100 whps,e,(bg,rp,(2,6,10,14,18)),0,0,10
waveHalfPeriodSine, event, (basketGen, randomPermutate, (2,6,10,14,18)),
0, (constant, 0), (constant, 10)
TPmap display complete.

pi{auto-acousticSnare}ti{a} :: tie b whps,e,(bg,rp,(2,6,10,14,18)),0,80,160
TI a: parameter bpm updated.

pi{auto-acousticSnare}ti{a} :: eln; elh
      EventList ath2010.03.11.16.13.48 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.13.48.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.13.48.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.13.48.mid

pi{auto-acousticSnare}ti{a} :: tiv
TI: a, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: rhodesPiano
      status: +, duration: 000.0--60.23
(i)nstrument        4 (generalMidi: rhodesPiano)
(t)ime range        00.0--60.0
(b)pm               waveHalfPeriodSine, event, (basketGen,
                    randomPermutate, (2,6,10,14,18)), 0, (constant, 80),
                    (constant, 160)
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,12}:{
                    a=20|b=2|c=4|d=2|e=2|f=5}a:{a=8|b=5|c=1|f=5}b:{a=8|b
                    =5|c=4|d=3|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=3|c=7
                    |d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c
                    =4|d=2|e=1}, (constant, 1)
(p)ath              auto
                    (C4)
                    60.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=5|h=2|i=1}a:{b=5}b:{a=2
                    |c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{
                    f=6|h=4}h:{g=4|i=2}i:{h=5}, (constant, 0.75)
local (o)ctave      constant, 0
(a)mplitude         constant, 0.8
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{a} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17}:{a=1|b=3|c=2|d=5|e=9|f=6|g=5|h=2|i=1}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|h=4}h:{g=4|i=2}i:{h=5},(c,1.25)
TI a: parameter local field updated.

pi{auto-acousticSnare}ti{a} :: eln; elh
      EventList ath2010.03.11.16.15.22 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.15.22.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.15.22.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.15.22.mid

pi{auto-acousticSnare}ti{a} :: tie a (bg,rp,(0,0,0,.5,.5,1,1,1,1,1,1))
TI a: parameter amplitude updated.

pi{auto-acousticSnare}ti{a} :: eln; elh
      EventList ath2010.03.11.16.16.33 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.16.33.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.16.33.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.16.33.mid

pi{auto-acousticSnare}ti{a} :: tie 
edit TI a
which parameter? (i,t,b,r,p,f,o,a,n,x,s,d): n
current panning: constant, 0.5
new value: bpl,e,(0,0),(10,0.5),(20,1),(30,0.5)
      TIe ERROR: incorrect arguments: too many arguments; enter 5
arguments.

pi{auto-acousticSnare}ti{a} :: bpl,e,l(0,0),(10,0.5),(20,1),(30,0.5)
unknown command. enter "cmd" to see all commands.

pi{auto-acousticSnare}ti{a} :: ?bpl
no help for: "bpl"

pi{auto-acousticSnare}ti{a} :: bpl,e,l,((0,0),(10,0.5),(20,1),(30,0.5))
unknown command. enter "cmd" to see all commands.

pi{auto-acousticSnare}ti{a} :: tpmap 100 bpl,e,l,((0,.5),(8,0),(16,1),(24,.75),(32,.9),(40,.5))
breakPointLinear, event, loop,
((0,0.5),(8,0),(16,1),(24,0.75),(32,0.9),(40,0.5))
TPmap display complete.

pi{auto-acousticSnare}ti{a} :: tie p bpl,e,l,((0,.5),(8,0),(16,1),(24,.75),(32,.9),(40,.5))
usage: tie parameter value

pi{auto-acousticSnare}ti{a} :: tie n bpl,e,l,((0,.5),(8,0),(16,1),(24,.75),(32,.9),(40,.5))
TI a: parameter panning updated.

pi{auto-acousticSnare}ti{a} :: eln; elh
      EventList ath2010.03.11.16.21.06 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.21.06.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.21.06.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.21.06.mid

pi{auto-acousticSnare}ti{a} :: tie n bpl,e,l,((0,0),(10,0.5),(20,1),(30,.5))
TI a: parameter panning updated.

pi{auto-acousticSnare}ti{a} :: eln; elh
      EventList ath2010.03.11.16.23.02 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.23.02.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.23.02.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.23.02.mid

pi{auto-acousticSnare}ti{a} :: emo m
EventMode mode set to: midi.

pi{auto-acousticSnare}ti{a} :: emi
generalMidi instruments:
{number,name}
   0      piano1           
   1      piano2           
   2      piano3           
   3      honkyTonkPiano   
   4      rhodesPiano      
   5      ePiano           
   6      harpsichord      
   7      clavinet         
   8      celesta          
   9      glockenspiel     
   10     musicBox         
   11     vibraphone       
   12     marimba          
   13     xylophone        
   14     tubularBells     
   15     santur           
   16     organ1           
   17     organ2           
   18     organ3           
   19     churchOrgan      
   20     reedOrgan        
   21     accordion        
   22     harmonica        
   23     bandoneon        
   24     nylonGuitar      
   25     steelGuitar      
   26     jazzGuitar       
   27     cleanGuitar      
   28     mutedGuitar      
   29     overDriveGuitar  
   30     distortonGuitar  
   31     guitarHarmonics  
   32     acousticBass     
   33     fingeredBass     
   34     pickedBass       
   35     fretlessBass     
   36     slapBass1        
   37     slapBass2        
   38     synthBass1       
   39     synthBass2       
   40     violin           
   41     viola            
   42     cello            
   43     contraBass       
   44     tremoloStrings   
   45     pizzicatoStrings 
   46     orchestralHarp   
   47     timpani          
   48     strings          
   49     slowStrings      
   50     synthStrings1    
   51     synthStrings2    
   52     choirAahs        
   53     voiceOohs        
   54     synthVox         
   55     orchestraHit     
   56     trumpet          
   57     trombone         
   58     tuba             
   59     mutedTrumpet     
   60     frenchHorn       
   61     brassSection     
   62     synthBrass1      
   63     synthBrass2      
   64     sopranoSax       
   65     altoSax          
   66     tenorSax         
   67     baritoneSax      
   68     oboe             
   69     englishHorn      
   70     bassoon          
   71     clarinet         
   72     piccolo          
   73     flute            
   74     recorder         
   75     panFlute         
   76     bottleBlow       
   77     shakuhachi       
   78     whistle          
   79     ocarina          
   80     squareWave       
   81     sawWave          
   82     synCalliope      
   83     chifferLead      
   84     charang          
   85     soloVoice        
   86     5thSawWave       
   87     bassAndLead      
   88     fantasia         
   89     warmPad          
   90     polySynth        
   91     spaceVoice       
   92     bowedGlass       
   93     metalPad         
   94     haloPad          
   95     sweepPad         
   96     iceRain          
   97     soundTrack       
   98     crystal          
   99     atmosphere       
   100    brightness       
   101    goblins          
   102    echoDrops        
   103    starTheme        
   104    sitar            
   105    banjo            
   106    shamisen         
   107    koto             
   108    kalimba          
   109    bagpipe          
   110    fiddle           
   111    shanai           
   112    tinkleBell       
   113    agogoBells       
   114    steelDrums       
   115    woodBlock        
   116    taikoDrum        
   117    melodicTom1      
   118    synthDrum        
   119    reverseCymbal    
   120    guitarFretnoise  
   121    breathNoise      
   122    seaShore         
   123    birdTweet        
   124    telephoneRing    
   125    helicopterBlade  
   126    applauseNoise    
   127    gunShot          

pi{auto-acousticSnare}ti{a} :: tie i 104
TI a: parameter instrument updated.

pi{auto-acousticSnare}ti{a} :: eln; elh
      EventList ath2010.03.11.16.23.41 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.23.41.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.23.41.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.23.41.mid

pi{auto-acousticSnare}ti{a} :: tie b c,135
TI a: parameter bpm updated.

pi{auto-acousticSnare}ti{a} :: eln; elh
      EventList ath2010.03.11.16.53.51 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.53.51.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.53.51.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.16.53.51.mid

pi{auto-acousticSnare}ti{a} :: tiv
TI: a, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: sitar
      status: +, duration: 000.0--60.59
(i)nstrument        104 (generalMidi: sitar)
(t)ime range        00.0--60.0
(b)pm               constant, 135
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,12}:{
                    a=20|b=2|c=4|d=2|e=2|f=5}a:{a=8|b=5|c=1|f=5}b:{a=8|b
                    =5|c=4|d=3|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=3|c=7
                    |d=3|e=2|f=1}e:{a=1|b=1|c=3|d=9|e=3|f=1}f:{a=8|b=6|c
                    =4|d=2|e=1}, (constant, 1)
(p)ath              auto
                    (C4)
                    60.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=5|h=2|i=1}a:{b=5}b:{a=2
                    |c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{
                    f=6|h=4}h:{g=4|i=2}i:{h=5}, (constant, 1.25)
local (o)ctave      constant, 0
(a)mplitude         basketGen, randomPermutate,
                    (0,0,0,0.5,0.5,1,1,1,1,1,1)
pan(n)ing           breakPointLinear, event, loop,
                    ((0,0),(10,0.5),(20,1),(30,0.5))
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{a} :: tie r mv,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,12}:{a=20|b=4|c=1|d=4|e=2|f=5}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=10|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=10|c=1|d=3|e=2|f=1}e:{a=6|b=5|c=5|d=2|e=3|f=1}f:{a=8|b=6|c=4|d=2|e=1},(c,0.6)
      TIe ERROR: incorrect arguments: parameter lib error (rthmPmtrObjs:
mv, None, ('mv', 'a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,12}:{a=20|b=4|c=1|d=
4|e=2|f=5}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=10|e=2|f=1}c:{a=3|b=9|c=5|
d=2}d:{a=2|b=10|c=1|d=3|e=2|f=1}e:{a=6|b=5|c=5|d=2|e=3|f=1}f:{a=8|b=6|c=
4|d=2|e=1}', ['c', 0.59999999999999998]))

pi{auto-acousticSnare}ti{a} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,12}:{a=20|b=4|c=1|d=4|e=2|f=5}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=10|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=10|c=1|d=3|e=2|f=1}e:{a=6|b=5|c=5|d=2|e=3|f=1}f:{a=8|b=6|c=4|d=2|e=1},(c,0.6)
TI a: parameter rhythm updated.

pi{auto-acousticSnare}ti{a} :: eln; elh
      EventList ath2010.03.11.17.07.43 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.07.43.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.07.43.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.07.43.mid

pi{auto-acousticSnare}ti{a} :: tiv
TI: a, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: sitar
      status: +, duration: 000.0--60.07
(i)nstrument        104 (generalMidi: sitar)
(t)ime range        00.0--60.0
(b)pm               constant, 135
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,12}:{
                    a=20|b=4|c=1|d=4|e=2|f=5}a:{a=8|b=5|c=1|f=5}b:{a=8|b
                    =5|c=4|d=10|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=10|c
                    =1|d=3|e=2|f=1}e:{a=6|b=5|c=5|d=2|e=3|f=1}f:{a=8|b=6
                    |c=4|d=2|e=1}, (constant, 0.6)
(p)ath              auto
                    (C4)
                    60.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=5|h=2|i=1}a:{b=5}b:{a=2
                    |c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{
                    f=6|h=4}h:{g=4|i=2}i:{h=5}, (constant, 1.25)
local (o)ctave      constant, 0
(a)mplitude         basketGen, randomPermutate,
                    (0,0,0,0.5,0.5,1,1,1,1,1,1)
pan(n)ing           breakPointLinear, event, loop,
                    ((0,0),(10,0.5),(20,1),(30,0.5))
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{a} :: tils
TextureInstances available:
{name,status,TM,PI,instrument,time,TC}
 + a                + LineGroove  auto               104 00.0--60.0   0
   b                o LineGroove  auto-acousticSnare 38  00.0--60.0   0

pi{auto-acousticSnare}ti{a} :: timute b
TI b is no longer muted.

pi{auto-acousticSnare}ti{a} :: eln; elh
      EventList ath2010.03.11.17.09.44 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.09.44.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.09.44.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.09.44.mid

pi{auto-acousticSnare}ti{a} :: tie n c,0.5
TI a: parameter panning updated.

pi{auto-acousticSnare}ti{a} :: tiv a
TI: a, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: sitar
      status: +, duration: 000.0--60.22
(i)nstrument        104 (generalMidi: sitar)
(t)ime range        00.0--60.0
(b)pm               constant, 135
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,12}:{
                    a=20|b=4|c=1|d=4|e=2|f=5}a:{a=8|b=5|c=1|f=5}b:{a=8|b
                    =5|c=4|d=10|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=10|c
                    =1|d=3|e=2|f=1}e:{a=6|b=5|c=5|d=2|e=3|f=1}f:{a=8|b=6
                    |c=4|d=2|e=1}, (constant, 0.6)
(p)ath              auto
                    (C4)
                    60.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=5|h=2|i=1}a:{b=5}b:{a=2
                    |c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{
                    f=6|h=4}h:{g=4|i=2}i:{h=5}, (constant, 1.25)
local (o)ctave      constant, 0
(a)mplitude         basketGen, randomPermutate,
                    (0,0,0,0.5,0.5,1,1,1,1,1,1)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{a} :: tie mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,12}:{a=20|b=4|c=1|d=4|e=2|f=5}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=10|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=10|c=1|d=3|e=2|f=1}e:{a=6|b=5|c=5|d=1|e=1|f=1}f:{a=8|b=6|c=4|d=1|e=1},(c,1)
usage: tie parameter value

pi{auto-acousticSnare}ti{a} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,12}:{a=20|b=4|c=1|d=4|e=2|f=5}a:{a=8|b=5|c=1|f=5}b:{a=8|b=5|c=4|d=10|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=10|c=1|d=3|e=2|f=1}e:{a=6|b=5|c=5|d=1|e=1|f=1}f:{a=8|b=6|c=4|d=1|e=1},(c,1)
TI a: parameter rhythm updated.

pi{auto-acousticSnare}ti{a} :: eln; elh
      EventList ath2010.03.11.17.42.13 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.42.13.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.42.13.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.42.13.mid

pi{auto-acousticSnare}ti{a} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17}:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|h=4}h:{g=4|i=2}i:{h=5},(c,0.75)\
      TIe ERROR: score creation: incorrect data-type in arguments.
unsupported operand type(s) for divmod(): 'str' and 'int'

pi{auto-acousticSnare}ti{a} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17}:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|h=4}h:{g=4|i=2}i:{h=5},(c,0.75)
TI a: parameter local field updated.

pi{auto-acousticSnare}ti{a} :: eln; elh
      EventList ath2010.03.11.17.44.22 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.44.22.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.44.22.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.44.22.mid

pi{auto-acousticSnare}ti{a} :: timute b
TI b is now muted.

pi{auto-acousticSnare}ti{a} :: ticp a c
TextureInstance c created.

pi{auto-acousticSnare}ti{c} :: tio c
TI c now active.

pi{auto-acousticSnare}ti{c} :: tie t 10,15
TI c: parameter time range updated.

pi{auto-acousticSnare}ti{c} :: tie o bpl,t,l,((10,-2),(12.5,2),(15,-2))
TI c: parameter local octave updated.

pi{auto-acousticSnare}ti{c} :: tie i 1
TI c: parameter instrument updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.17.56.27 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.56.27.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.56.27.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.56.27.mid

pi{auto-acousticSnare}ti{c} :: tiv
TI: c, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: piano2
      status: +, duration: 010.0--15.56
(i)nstrument        1 (generalMidi: piano2)
(t)ime range        10.0--15.0
(b)pm               constant, 135
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,12}:{
                    a=20|b=4|c=1|d=4|e=2|f=5}a:{a=8|b=5|c=1|f=5}b:{a=8|b
                    =5|c=4|d=10|e=2|f=1}c:{a=3|b=9|c=5|d=2}d:{a=2|b=10|c
                    =1|d=3|e=2|f=1}e:{a=6|b=5|c=5|d=1|e=1|f=1}f:{a=8|b=6
                    |c=4|d=1|e=1}, (constant, 1)
(p)ath              auto
                    (C4)
                    5.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5}, (constant, 0.75)
local (o)ctave      breakPointLinear, time, loop,
                    ((10,-2),(12.5,2),(15,-2))
(a)mplitude         basketGen, randomPermutate,
                    (0,0,0,0.5,0.5,1,1,1,1,1,1)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{c} :: tie a 0.8
      TIe ERROR: object creation: incorrect data-type in arguments.
'float' object is unsubscriptable

pi{auto-acousticSnare}ti{c} :: tie a c,0.8
TI c: parameter amplitude updated.

pi{auto-acousticSnare}ti{c} :: tie r pt,(c,8),(n,100,1,16),(c,1)
TI c: parameter rhythm updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.17.58.17 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.58.17.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.58.17.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.58.17.mid

pi{auto-acousticSnare}ti{c} :: timute a
TI a is now muted.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.17.58.43 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.58.43.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.58.43.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.17.58.43.mid

pi{auto-acousticSnare}ti{c} :: tie t 0,20
TI c: parameter time range updated.

pi{auto-acousticSnare}ti{c} :: tie b (n,100,2,60,200)
TI c: parameter bpm updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.18.00.06 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.00.06.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.00.06.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.00.06.mid

pi{auto-acousticSnare}ti{c} :: tie b (n,100,2,120,200)
TI c: parameter bpm updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.18.00.26 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.00.26.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.00.26.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.00.26.mid

pi{auto-acousticSnare}ti{c} :: tiv
TI: c, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: piano2
      status: +, duration: 000.0--20.36
(i)nstrument        1 (generalMidi: piano2)
(t)ime range        00.0--20.0
(b)pm               noise, 100, (constant, 2), (constant, 120),
                    (constant, 200)
(r)hythm            pulseTriple, (constant, 8), (noise, 100, (constant,
                    1), (constant, 16), (constant, 1)), (constant, 1),
                    (randomUniform, (constant, 0.5), (constant, 1.5))
(p)ath              auto
                    (C4)
                    20.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5}, (constant, 0.75)
local (o)ctave      breakPointLinear, time, loop,
                    ((10,-2),(12.5,2),(15,-2))
(a)mplitude         constant, 0.8
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{c} :: tie b (n,100,2,180,240)
TI c: parameter bpm updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.18.03.29 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.03.29.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.03.29.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.03.29.mid

pi{auto-acousticSnare}ti{c} :: tie b (bg,oc,(200,210,205,180,190,175,185,200,215,240,280,250,235,220,215,205)))
usage: tie parameter value

pi{auto-acousticSnare}ti{c} :: bpl,t,l,((0,0),(3,-0.5),(6,0.5),(9,1.5),(12,1),(15,0))
unknown command. enter "cmd" to see all commands.

pi{auto-acousticSnare}ti{c} :: tie o bpl,t,l,((0,0),(3,-0.5),(6,0.5),(9,1.5),(12,1),(15,0))
TI c: parameter local octave updated.

pi{auto-acousticSnare}ti{c} :: ticp c c1
TextureInstance c1 created.

pi{auto-acousticSnare}ti{c1} :: tie c1 2
usage: tie parameter value

pi{auto-acousticSnare}ti{c1} :: tio c; tiv
TI c now active.

TI: c, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: piano2
      status: +, duration: 000.0--20.12
(i)nstrument        1 (generalMidi: piano2)
(t)ime range        00.0--20.0
(b)pm               noise, 100, (constant, 2), (constant, 180),
                    (constant, 240)
(r)hythm            pulseTriple, (constant, 8), (noise, 100, (constant,
                    1), (constant, 16), (constant, 1)), (constant, 1),
                    (randomUniform, (constant, 0.5), (constant, 1.5))
(p)ath              auto
                    (C4)
                    20.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5}, (constant, 0.75)
local (o)ctave      breakPointLinear, time, loop,
                    ((0,0),(3,-0.5),(6,0.5),(9,1.5),(12,1),(15,0))
(a)mplitude         constant, 0.8
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{c} :: tie r pt,(c,6),(bg,oc,(1,1,1,2,1,6,4,2,2,4,1,1,1,3,6,9,2,1,4,4,4,3,3,3,2,2,1,1,1,1,1,3,6,6,1,1,1,1,1,1)),(c,1)
TI c: parameter rhythm updated.

pi{auto-acousticSnare}ti{c} :: tio c1; tie r pt,(c,6),(bg,oc,(1,1,1,2,1,6,4,2,2,4,1,1,1,3,6,9,2,1,4,4,4,3,3,3,2,2,1,1,1,1,1,3,6,6,1,1,1,1,1,1)),(c,1)
TI c1 now active.

TI c1: parameter rhythm updated.

pi{auto-acousticSnare}ti{c1} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17}:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|h=4}h:{g=4|i=2}i:{h=5},(c,0.25)
TI c1: parameter local field updated.

pi{auto-acousticSnare}ti{c1} :: tiv
TI: c1, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: piano2
      status: +, duration: 000.0--20.07
(i)nstrument        1 (generalMidi: piano2)
(t)ime range        00.0--20.0
(b)pm               noise, 100, (constant, 2), (constant, 180),
                    (constant, 240)
(r)hythm            pulseTriple, (constant, 6), (basketGen,
                    orderedCyclic, (1,1,1,2,1,6,4,2,2,4,1,1,1,3,6,9,2,1,
                    4,4,4,3,3,3,2,2,1,1,1,1,1,3,6,6,1,1,1,1,1,1)),
                    (constant, 1), (randomUniform, (constant, 0.5),
                    (constant, 1.5))
(p)ath              auto
                    (C4)
                    20.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5}, (constant, 0.25)
local (o)ctave      breakPointLinear, time, loop,
                    ((0,0),(3,-0.5),(6,0.5),(9,1.5),(12,1),(15,0))
(a)mplitude         constant, 0.8
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{c1} :: eln; elh
      EventList ath2010.03.11.18.10.30 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.10.30.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.10.30.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.10.30.mid

pi{auto-acousticSnare}ti{c1} :: tie o bpl,t,l,((0,2),(3,1.5),(9,0.5),(12,-.5),(15,-2))
TI c1: parameter local octave updated.

pi{auto-acousticSnare}ti{c1} :: eln; elh
      EventList ath2010.03.11.18.11.26 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.11.26.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.11.26.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.11.26.mid

pi{auto-acousticSnare}ti{c1} :: timute b
TI b is no longer muted.

pi{auto-acousticSnare}ti{c1} :: eln; elh
      EventList ath2010.03.11.18.12.32 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.12.32.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.12.32.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.12.32.mid

pi{auto-acousticSnare}ti{c1} :: timute b
TI b is now muted.

pi{auto-acousticSnare}ti{c1} :: eln; elh
      EventList ath2010.03.11.18.25.50 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.25.50.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.25.50.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.25.50.mid

pi{auto-acousticSnare}ti{c1} :: ticp c1 c2
TextureInstance c2 created.

pi{auto-acousticSnare}ti{c2} :: tie i 5
TI c2: parameter instrument updated.

pi{auto-acousticSnare}ti{c2} :: tio c1; tiv
TI c1 now active.

TI: c1, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: piano2
      status: +, duration: 00.0--20.4
(i)nstrument        1 (generalMidi: piano2)
(t)ime range        00.0--20.0
(b)pm               noise, 100, (constant, 2), (constant, 180),
                    (constant, 240)
(r)hythm            pulseTriple, (constant, 6), (basketGen,
                    orderedCyclic, (1,1,1,2,1,6,4,2,2,4,1,1,1,3,6,9,2,1,
                    4,4,4,3,3,3,2,2,1,1,1,1,1,3,6,6,1,1,1,1,1,1)),
                    (constant, 1), (randomUniform, (constant, 0.5),
                    (constant, 1.5))
(p)ath              auto
                    (C4)
                    20.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5}, (constant, 0.25)
local (o)ctave      breakPointLinear, time, loop,
                    ((0,2),(3,1.5),(9,0.5),(12,-0.5),(15,-2))
(a)mplitude         constant, 0.8
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{c1} :: tie i 3
TI c1: parameter instrument updated.

pi{auto-acousticSnare}ti{c1} :: tio c2
TI c2 now active.

pi{auto-acousticSnare}ti{c2} :: tie b n,100,1,40,100
TI c2: parameter bpm updated.

pi{auto-acousticSnare}ti{c2} :: eln; elh
      EventList ath2010.03.11.18.27.07 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.27.07.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.27.07.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.27.07.mid

pi{auto-acousticSnare}ti{c2} :: tie o c,-2
TI c2: parameter local octave updated.

pi{auto-acousticSnare}ti{c2} :: eln; elh
      EventList ath2010.03.11.18.27.27 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.27.27.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.27.27.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.27.27.mid

pi{auto-acousticSnare}ti{c2} :: emi
generalMidi instruments:
{number,name}
   0      piano1           
   1      piano2           
   2      piano3           
   3      honkyTonkPiano   
   4      rhodesPiano      
   5      ePiano           
   6      harpsichord      
   7      clavinet         
   8      celesta          
   9      glockenspiel     
   10     musicBox         
   11     vibraphone       
   12     marimba          
   13     xylophone        
   14     tubularBells     
   15     santur           
   16     organ1           
   17     organ2           
   18     organ3           
   19     churchOrgan      
   20     reedOrgan        
   21     accordion        
   22     harmonica        
   23     bandoneon        
   24     nylonGuitar      
   25     steelGuitar      
   26     jazzGuitar       
   27     cleanGuitar      
   28     mutedGuitar      
   29     overDriveGuitar  
   30     distortonGuitar  
   31     guitarHarmonics  
   32     acousticBass     
   33     fingeredBass     
   34     pickedBass       
   35     fretlessBass     
   36     slapBass1        
   37     slapBass2        
   38     synthBass1       
   39     synthBass2       
   40     violin           
   41     viola            
   42     cello            
   43     contraBass       
   44     tremoloStrings   
   45     pizzicatoStrings 
   46     orchestralHarp   
   47     timpani          
   48     strings          
   49     slowStrings      
   50     synthStrings1    
   51     synthStrings2    
   52     choirAahs        
   53     voiceOohs        
   54     synthVox         
   55     orchestraHit     
   56     trumpet          
   57     trombone         
   58     tuba             
   59     mutedTrumpet     
   60     frenchHorn       
   61     brassSection     
   62     synthBrass1      
   63     synthBrass2      
   64     sopranoSax       
   65     altoSax          
   66     tenorSax         
   67     baritoneSax      
   68     oboe             
   69     englishHorn      
   70     bassoon          
   71     clarinet         
   72     piccolo          
   73     flute            
   74     recorder         
   75     panFlute         
   76     bottleBlow       
   77     shakuhachi       
   78     whistle          
   79     ocarina          
   80     squareWave       
   81     sawWave          
   82     synCalliope      
   83     chifferLead      
   84     charang          
   85     soloVoice        
   86     5thSawWave       
   87     bassAndLead      
   88     fantasia         
   89     warmPad          
   90     polySynth        
   91     spaceVoice       
   92     bowedGlass       
   93     metalPad         
   94     haloPad          
   95     sweepPad         
   96     iceRain          
   97     soundTrack       
   98     crystal          
   99     atmosphere       
   100    brightness       
   101    goblins          
   102    echoDrops        
   103    starTheme        
   104    sitar            
   105    banjo            
   106    shamisen         
   107    koto             
   108    kalimba          
   109    bagpipe          
   110    fiddle           
   111    shanai           
   112    tinkleBell       
   113    agogoBells       
   114    steelDrums       
   115    woodBlock        
   116    taikoDrum        
   117    melodicTom1      
   118    synthDrum        
   119    reverseCymbal    
   120    guitarFretnoise  
   121    breathNoise      
   122    seaShore         
   123    birdTweet        
   124    telephoneRing    
   125    helicopterBlade  
   126    applauseNoise    
   127    gunShot          

pi{auto-acousticSnare}ti{c2} :: tio c; tie i 108
TI c now active.

TI c: parameter instrument updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.18.29.37 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.29.37.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.29.37.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.18.29.37.mid

pi{auto-acousticSnare}ti{c} :: tils
TextureInstances available:
{name,status,TM,PI,instrument,time,TC}
   a                o LineGroove  auto               104 00.0--60.0   0
   b                o LineGroove  auto-acousticSnare 38  00.0--60.0   0
 + c                + LineGroove  auto               108 00.0--20.0   0
   c1               + LineGroove  auto               3   00.0--20.0   0
   c2               + LineGroove  auto               5   00.0--20.0   0

pi{auto-acousticSnare}ti{c} :: tie
edit TI c
which parameter? (i,t,b,r,p,f,o,a,n,x,s,d): 
no such parameter exists: enter "TIv" to display parameters.

pi{auto-acousticSnare}ti{c} :: timute a b c1 c2
TI a is no longer muted.
TI b is no longer muted.
TI c1 is now muted.
TI c2 is now muted.

pi{auto-acousticSnare}ti{c} :: tils
TextureInstances available:
{name,status,TM,PI,instrument,time,TC}
   a                + LineGroove  auto               104 00.0--60.0   0
   b                + LineGroove  auto-acousticSnare 38  00.0--60.0   0
 + c                + LineGroove  auto               108 00.0--20.0   0
   c1               o LineGroove  auto               3   00.0--20.0   0
   c2               o LineGroove  auto               5   00.0--20.0   0

pi{auto-acousticSnare}ti{c} :: tie r mp,a{6,1}b{6,2}c{6,3},d{6,4}e{6,6}:{a=12|b=8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}b:{a=5|d=10|e=1}c:{a=6|c=9|e=5}d:{a=2|b=10}e:{a=10|b=5|c=5|d=5|e=1},(wp,e,100,0,1,0)
      TIe ERROR: incorrect arguments: too many arguments; enter 3
arguments.

pi{auto-acousticSnare}ti{c} :: tie r mp,a{6,1}b{6,2}c{6,3},d{6,4}e{6,6}:{a=12|b=8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}b:{a=5|d=10|e=1}c:{a=6|c=9|e=5}d:{a=2|b=10}e:{a=10|b=5|c=5|d=5|e=1},(wp,e,100,0,1,0)
      TIe ERROR: incorrect arguments: too many arguments; enter 3
arguments.

pi{auto-acousticSnare}ti{c} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}b:{a=5|d=10|e=1}c:{a=6|c=9|e=5}d:{a=2|b=10}e:{a=10|b=5|c=5|d=5|e=1},(wp,e,100,0,1,0)
TI c: parameter rhythm updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.21.40.06 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.40.06.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.40.06.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.40.06.mid

pi{auto-acousticSnare}ti{c} :: timute a
TI a is now muted.

pi{auto-acousticSnare}ti{c} :: tils
TextureInstances available:
{name,status,TM,PI,instrument,time,TC}
   a                o LineGroove  auto               104 00.0--60.0   0
   b                + LineGroove  auto-acousticSnare 38  00.0--60.0   0
 + c                + LineGroove  auto               108 00.0--20.0   0
   c1               o LineGroove  auto               3   00.0--20.0   0
   c2               o LineGroove  auto               5   00.0--20.0   0

pi{auto-acousticSnare}ti{c} :: timute b
TI b is now muted.

pi{auto-acousticSnare}ti{c} :: tils
TextureInstances available:
{name,status,TM,PI,instrument,time,TC}
   a                o LineGroove  auto               104 00.0--60.0   0
   b                o LineGroove  auto-acousticSnare 38  00.0--60.0   0
 + c                + LineGroove  auto               108 00.0--20.0   0
   c1               o LineGroove  auto               3   00.0--20.0   0
   c2               o LineGroove  auto               5   00.0--20.0   0

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.21.40.37 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.40.37.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.40.37.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.40.37.mid

pi{auto-acousticSnare}ti{c} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}b:{a=5|d=10|e=1}c:{a=6|c=9|e=5}d:{a=2|b=10}e:{a=10|b=5|c=5|d=5|e=1},(ls,e,100,0,1)
TI c: parameter rhythm updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.21.41.22 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.41.22.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.41.22.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.41.22.mid

pi{auto-acousticSnare}ti{c} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}b:{a=5|d=10|e=1}c:{a=6|c=9|e=5}d:{a=2|b=10}e:{a=10|b=5|c=5|d=5|e=1}aa:{a=10|c=5|e=5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}bb:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{a=6|c=4|e=2}dd:{d=1}de:{b=1},(c,2)
TI c: parameter rhythm updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.21.45.26 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.45.26.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.45.26.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.45.26.mid

pi{auto-acousticSnare}ti{c} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}b:{a=5|d=10|e=1}c:{a=6|c=9|e=5}d:{a=2|b=10}e:{a=10|b=5|c=5|d=5|e=1}aa:{a=10|c=5|e=5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}bb:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{a=6|c=4|e=2}dd:{d=1}de:{b=1},(rn,100,2,0,2)
      TIe ERROR: incorrect arguments: failed sub-parameter: parameter
lib error (genPmtrObjs: rn, None, ['rn', 100, 2, 0, 2])

pi{auto-acousticSnare}ti{c} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}b:{a=5|d=10|e=1}c:{a=6|c=9|e=5}d:{a=2|b=10}e:{a=10|b=5|c=5|d=5|e=1}aa:{a=10|c=5|e=5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}bb:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{a=6|c=4|e=2}dd:{d=1}de:{b=1},(n,100,2,0,2)
TI c: parameter rhythm updated.

pi{auto-acousticSnare}ti{c} :: tie a n,200,1,0.3,.9
TI c: parameter amplitude updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.21.49.26 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.49.26.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.49.26.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.49.26.mid

pi{auto-acousticSnare}ti{c} :: tie a rb,0.4,.1,0.2,1
TI c: parameter amplitude updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.21.49.58 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.49.58.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.49.58.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.49.58.mid

pi{auto-acousticSnare}ti{c} :: tie a rb,0.5,.2,0.4,1
TI c: parameter amplitude updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.21.50.30 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.50.30.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.50.30.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.50.30.mid

pi{auto-acousticSnare}ti{c} :: tiv
TI: c, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: kalimba
      status: +, duration: 000.0--20.14
(i)nstrument        108 (generalMidi: kalimba)
(t)ime range        00.0--20.0
(b)pm               noise, 100, (constant, 2), (constant, 180),
                    (constant, 240)
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1}, (noise, 100, (constant, 2), (constant,
                    0), (constant, 2))
(p)ath              auto
                    (C4)
                    20.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5}, (constant, 0.75)
local (o)ctave      breakPointLinear, time, loop,
                    ((0,0),(3,-0.5),(6,0.5),(9,1.5),(12,1),(15,0))
(a)mplitude         randomBeta, 0.5, 0.2, (constant, 0.4), (constant, 1)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{c} :: a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1},(bg,rw,(0,0,0,1,1,1,1,2,2,2,1.5,1.5,0.5,0.5))
unknown command. enter "cmd" to see all commands.

pi{auto-acousticSnare}ti{c} :: tie a mv,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1},(bg,rw,(0,0,0,1,1,1,1,2,2,2,1.5,1.5,0.5,0.5))
TI c: parameter amplitude updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
apologies: the previous command could not be completed as expected.
please report this bug when quitting, or examine the log (AUlog).

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.21.50.30.mid

pi{auto-acousticSnare}ti{c} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1},(bg,rw,(0,0,0,1,1,1,1,2,2,2,1.5,1.5,0.5,0.5))
TI c: parameter rhythm updated.

pi{auto-acousticSnare}ti{c} :: tie a bg,rw,(0,0,0,0.3,0.3,0.3,0.3,0.5,0.5,0.5,0.5,0.8,0.8,0.8,0.8,1,1)
TI c: parameter amplitude updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.22.07.03 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.07.03.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.07.03.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.07.03.mid

pi{auto-acousticSnare}ti{c} :: tie b whsp,e,l(30,180,180,260)
      TIe ERROR: incorrect arguments: parameter lib error (genPmtrObjs:
whsp, None, ('whsp', 'e', ['l30', 180, 180, 260]))

pi{auto-acousticSnare}ti{c} :: tie b whsp,e,(30,180,180,260)
      TIe ERROR: incorrect arguments: parameter lib error (genPmtrObjs:
whsp, None, ('whsp', 'e', [30, 180, 180, 260]))

pi{auto-acousticSnare}ti{c} :: tie b whps,e,l(30,180,180,260)
      TIe ERROR: incorrect arguments: failed sub-parameter: parameter
lib error (genPmtrObjs: l30, None, ['l30', 180, 180, 260])

pi{auto-acousticSnare}ti{c} :: tie b whps,e,(30,180,180,260)
      TIe ERROR: incorrect arguments: failed sub-parameter: parameter
lib error (genPmtrObjs: 30, None, [30, 180, 180, 260])

pi{auto-acousticSnare}ti{c} :: tie b whps,e(30,0,180,260)
      TIe ERROR: incorrect arguments: wrong type of data used as an
argument. replace '(e30,0,180,260)' with a string argument type.

pi{auto-acousticSnare}ti{c} :: tie b whps,e,(bg,rp,(2,6,10,14,18)),0,180,250
TI c: parameter bpm updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.22.09.15 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.09.15.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.09.15.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.09.15.mid

pi{auto-acousticSnare}ti{c} :: tiv 
TI: c, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: kalimba
      status: +, duration: 000.0--20.04
(i)nstrument        108 (generalMidi: kalimba)
(t)ime range        00.0--20.0
(b)pm               waveHalfPeriodSine, event, (basketGen,
                    randomPermutate, (2,6,10,14,18)), 0, (constant,
                    180), (constant, 250)
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1}, (basketGen, randomWalk,
                    (0,0,0,1,1,1,1,2,2,2,1.5,1.5,0.5,0.5))
(p)ath              auto
                    (C4)
                    20.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}h{13}i{17
                    }:{a=1|b=3|c=2|d=5|e=9|f=6|g=10|h=2|i=1}a:{b=5}b:{a=
                    2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:
                    {f=6|h=4}h:{g=4|i=2}i:{h=5}, (constant, 0.75)
local (o)ctave      breakPointLinear, time, loop,
                    ((0,0),(3,-0.5),(6,0.5),(9,1.5),(12,1),(15,0))
(a)mplitude         basketGen, randomWalk,
                    (0,0,0,0.3,0.3,0.3,0.3,0.5,0.5,0.5,0.5,0.8,0.8,0.8,0
                    .8,1,1)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{c} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3|c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|h=g=1},(n,100,2,0,1)
      TIe ERROR: incorrect arguments: Markov transition creation failed:
incorrect weight specification: h=g=1

pi{auto-acousticSnare}ti{c} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3|c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},(n,100,2,0,1)
TI c: parameter local field updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.22.28.22 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.28.22.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.28.22.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.28.22.mid

pi{auto-acousticSnare}ti{c} :: tiv
TI: c, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: kalimba
      status: +, duration: 000.0--20.05
(i)nstrument        108 (generalMidi: kalimba)
(t)ime range        00.0--20.0
(b)pm               waveHalfPeriodSine, event, (basketGen,
                    randomPermutate, (2,6,10,14,18)), 0, (constant,
                    180), (constant, 250)
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1}, (basketGen, randomWalk,
                    (0,0,0,1,1,1,1,2,2,2,1.5,1.5,0.5,0.5))
(p)ath              auto
                    (C4)
                    20.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1}, (noise,
                    100, (constant, 2), (constant, 0), (constant, 1))
local (o)ctave      breakPointLinear, time, loop,
                    ((0,0),(3,-0.5),(6,0.5),(9,1.5),(12,1),(15,0))
(a)mplitude         basketGen, randomWalk,
                    (0,0,0,0.3,0.3,0.3,0.3,0.5,0.5,0.5,0.5,0.8,0.8,0.8,0
                    .8,1,1)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{c} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1},(c,0)
TI c: parameter rhythm updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.22.30.55 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.30.55.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.30.55.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.30.55.mid

pi{auto-acousticSnare}ti{c} :: tie o c,2
TI c: parameter local octave updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.22.31.29 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.31.29.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.31.29.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.31.29.mid

pi{auto-acousticSnare}ti{c} :: tiv 
TI: c, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: kalimba
      status: +, duration: 000.0--20.03
(i)nstrument        108 (generalMidi: kalimba)
(t)ime range        00.0--20.0
(b)pm               waveHalfPeriodSine, event, (basketGen,
                    randomPermutate, (2,6,10,14,18)), 0, (constant,
                    180), (constant, 250)
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1}, (constant, 0)
(p)ath              auto
                    (C4)
                    20.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1}, (noise,
                    100, (constant, 2), (constant, 0), (constant, 1))
local (o)ctave      constant, 2
(a)mplitude         basketGen, randomWalk,
                    (0,0,0,0.3,0.3,0.3,0.3,0.5,0.5,0.5,0.5,0.8,0.8,0.8,0
                    .8,1,1)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{c} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1}, (constant, 2)
TI c: parameter rhythm updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.22.35.44 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.35.44.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.35.44.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.35.44.mid

pi{auto-acousticSnare}ti{c} :: tie a bg,rw,(0,0.3,0.3,0.3,0.3,0.5,0.5,0.5,0.5,0.8,0.8,0.8,0.8,1,1)
TI c: parameter amplitude updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.22.36.32 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.36.32.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.36.32.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.22.36.32.mid

pi{auto-acousticSnare}ti{c} :: tie t 0,60
TI c: parameter time range updated.

pi{auto-acousticSnare}ti{c} :: tie a n,40,0,0,1
TI c: parameter amplitude updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.11.23.06.53 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.23.06.53.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.23.06.53.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.23.06.53.mid

pi{auto-acousticSnare}ti{c} :: tiv
TI: c, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: kalimba
      status: +, duration: 000.0--60.03
(i)nstrument        108 (generalMidi: kalimba)
(t)ime range        00.0--60.0
(b)pm               waveHalfPeriodSine, event, (basketGen,
                    randomPermutate, (2,6,10,14,18)), 0, (constant,
                    180), (constant, 250)
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1}, (constant, 2)
(p)ath              auto
                    (C4)
                    60.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1}, (noise,
                    100, (constant, 2), (constant, 0), (constant, 1))
local (o)ctave      constant, 2
(a)mplitude         noise, 40, (constant, 0), (constant, 0), (constant,
                    1)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{c} :: tils
TextureInstances available:
{name,status,TM,PI,instrument,time,TC}
   a                o LineGroove  auto               104 00.0--60.0   0
   b                o LineGroove  auto-acousticSnare 38  00.0--60.0   0
 + c                + LineGroove  auto               108 00.0--60.0   0
   c1               o LineGroove  auto               3   00.0--20.0   0
   c2               o LineGroove  auto               5   00.0--20.0   0

pi{auto-acousticSnare}ti{c} :: tin d 4; tie o bpl,t,l,((0,-2),(.5,-1),(1,0),(1.5,1),(2,2),(2.5,1),(3,0),(3.5,-1),(4,-2))
TI d created.

TI d: parameter local octave updated.

pi{auto-acousticSnare}ti{d} :: eln; elh
      EventList ath2010.03.11.23.41.48 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.23.41.48.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.23.41.48.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.23.41.48.mid

pi{auto-acousticSnare}ti{d} :: tils
TextureInstances available:
{name,status,TM,PI,instrument,time,TC}
   a                o LineGroove  auto               104 00.0--60.0   0
   b                o LineGroove  auto-acousticSnare 38  00.0--60.0   0
   c                + LineGroove  auto               108 00.0--60.0   0
   c1               o LineGroove  auto               3   00.0--20.0   0
   c2               o LineGroove  auto               5   00.0--20.0   0
 + d                + LineGroove  auto-acousticSnare 4   00.0--60.0   0

pi{auto-acousticSnare}ti{d} :: timute c
TI c is now muted.

pi{auto-acousticSnare}ti{d} :: tie b bg,rw,(30,50,40,55,70,60,80,76,65,80,85,90,95)
TI d: parameter bpm updated.

pi{auto-acousticSnare}ti{d} :: eln; elh
      EventList ath2010.03.11.23.42.56 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.23.42.56.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.23.42.56.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.23.42.56.mid

pi{auto-acousticSnare}ti{d} :: tiv
TI: d, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: rhodesPiano
      status: +, duration: 000.0--60.01
(i)nstrument        4 (generalMidi: rhodesPiano)
(t)ime range        00.0--60.0
(b)pm               basketGen, randomWalk,
                    (30,50,40,55,70,60,80,76,65,80,85,90,95)
(r)hythm            pulseTriple, (constant, 4), (basketGen,
                    randomPermutate, (1,1,2,3)), (constant, 1),
                    (constant, 0.75)
(p)ath              auto-acousticSnare
                    (D2)
                    60.00(s)
local (f)ield       constant, 0
local (o)ctave      breakPointLinear, time, loop,
                    ((0,-2),(0.5,-1),(1,0),(1.5,1),(2,2),(2.5,1),(3,0),(
                    3.5,-1),(4,-2))
(a)mplitude         randomBeta, 0.4, 0.4, (constant, 0.7), (constant,
                    0.9)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{d} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3|c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d:{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},(n,100,2,0,1)
TI d: parameter local field updated.

pi{auto-acousticSnare}ti{d} :: eln; elh
      EventList ath2010.03.11.23.43.53 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.23.43.53.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.23.43.53.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.23.43.53.mid

pi{auto-acousticSnare}ti{d} :: tie t 0,4
TI d: parameter time range updated.

pi{auto-acousticSnare}ti{d} :: eln; elh
      EventList ath2010.03.11.23.44.27 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.23.44.27.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.23.44.27.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.23.44.27.mid

pi{auto-acousticSnare}ti{d} :: tie b bg,rw,(250,240,260)
TI d: parameter bpm updated.

pi{auto-acousticSnare}ti{d} :: eln; elh
      EventList ath2010.03.11.23.45.00 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.23.45.00.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.23.45.00.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.11.23.45.00.mid

pi{auto-acousticSnare}ti{d} :: timute d
TI d is now muted.

pi{auto-acousticSnare}ti{d} :: tio c
TI c now active.

pi{auto-acousticSnare}ti{c} :: tils
TextureInstances available:
{name,status,TM,PI,instrument,time,TC}
   a                o LineGroove  auto               104 00.0--60.0   0
   b                o LineGroove  auto-acousticSnare 38  00.0--60.0   0
 + c                o LineGroove  auto               108 00.0--60.0   0
   c1               o LineGroove  auto               3   00.0--20.0   0
   c2               o LineGroove  auto               5   00.0--20.0   0
   d                o LineGroove  auto-acousticSnare 4   0.0--4.0     0

pi{auto-acousticSnare}ti{c} :: timute c
TI c is no longer muted.

pi{auto-acousticSnare}ti{c} :: tils
TextureInstances available:
{name,status,TM,PI,instrument,time,TC}
   a                o LineGroove  auto               104 00.0--60.0   0
   b                o LineGroove  auto-acousticSnare 38  00.0--60.0   0
 + c                + LineGroove  auto               108 00.0--60.0   0
   c1               o LineGroove  auto               3   00.0--20.0   0
   c2               o LineGroove  auto               5   00.0--20.0   0
   d                o LineGroove  auto-acousticSnare 4   0.0--4.0     0

pi{auto-acousticSnare}ti{c} :: tiv
TI: c, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: kalimba
      status: +, duration: 000.0--60.09
(i)nstrument        108 (generalMidi: kalimba)
(t)ime range        00.0--60.0
(b)pm               waveHalfPeriodSine, event, (basketGen,
                    randomPermutate, (2,6,10,14,18)), 0, (constant,
                    180), (constant, 250)
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}:{a=12|b=
                    8|c=4|d=8|e=2}a:{a=10|b=4|c=3|d=3|e=2}aa:{a=10|c=5|e
                    =5}ab:{c=1}ac:{b=1}ad:{a=1}ae:{b=1}b:{a=5|d=10|e=1}b
                    b:{a=2|b=6}bc:{a=1}bd:{a=10|b=3|c=7|d=1|e=5}be:{d=1}
                    c:{a=6|c=9|e=5}cc:{a=10|b=5|c=4|d=5|e=5}cd:{b=1}ce:{
                    a=6|c=4|e=2}d:{a=2|b=10}dd:{d=1}de:{b=1}e:{a=10|b=5|
                    c=5|d=5|e=1}, (constant, 2)
(p)ath              auto
                    (C4)
                    60.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1}, (noise,
                    100, (constant, 2), (constant, 0), (constant, 1))
local (o)ctave      constant, 2
(a)mplitude         noise, 40, (constant, 0), (constant, 0), (constant,
                    1)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{c} :: tie r mp,a{8,2}b{8,5}c{8,3}d{8,7}e{8,13}:{a=9|b=
                    8|c=6|d=7|e=2}a:{a=3|b=2|c=2|d=3|e=2}b:{a=5|d=4|e=1}
                    c:{a=6|c=2|e=5}d:{a=2|b=10}e:{a=5|b=2|
                    c=5|d=5|e=1},(c,1)
TI c: parameter rhythm updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.12.00.02.12 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.02.12.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.02.12.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.02.12.mid

pi{auto-acousticSnare}ti{c} :: tiv
TI: c, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: kalimba
      status: +, duration: 000.0--60.12
(i)nstrument        108 (generalMidi: kalimba)
(t)ime range        00.0--60.0
(b)pm               waveHalfPeriodSine, event, (basketGen,
                    randomPermutate, (2,6,10,14,18)), 0, (constant,
                    180), (constant, 250)
(r)hythm            markovPulse, a{8,2}b{8,5}c{8,3}d{8,7}e{8,13}:{a=9|b=
                    8|c=6|d=7|e=2}a:{a=3|b=2|c=2|d=3|e=2}b:{a=5|d=4|e=1}
                    c:{a=6|c=2|e=5}d:{a=2|b=10}e:{a=5|b=2|c=5|d=5|e=1},
                    (constant, 1)
(p)ath              auto
                    (C4)
                    60.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1}, (noise,
                    100, (constant, 2), (constant, 0), (constant, 1))
local (o)ctave      constant, 2
(a)mplitude         noise, 40, (constant, 0), (constant, 0), (constant,
                    1)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{c} :: tie b whpt,(bg,rw,(32,3,25,16,9,40)),0,70,140
      TIe ERROR: incorrect arguments: wrong type of data used as an
argument. replace '(bg,rw,(32,3,25,16,9,40))' with a string argument
type.

pi{auto-acousticSnare}ti{c} :: tie b whpt,(bg,rp,(32,3,25,16,9,40)),0,70,140
      TIe ERROR: incorrect arguments: wrong type of data used as an
argument. replace '(bg,rp,(32,3,25,16,9,40))' with a string argument
type.

pi{auto-acousticSnare}ti{c} :: tie b whpt,e,(bg,rw,(32,3,25,16,9,40)),0,70,140
TI c: parameter bpm updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.12.00.10.23 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.10.23.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.10.23.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.10.23.mid

pi{auto-acousticSnare}ti{c} :: tiv
TI: c, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: kalimba
      status: +, duration: 00.0--60.1
(i)nstrument        108 (generalMidi: kalimba)
(t)ime range        00.0--60.0
(b)pm               waveHalfPeriodTriangle, event, (basketGen,
                    randomWalk, (32,3,25,16,9,40)), 0, (constant, 70),
                    (constant, 140)
(r)hythm            markovPulse, a{8,2}b{8,5}c{8,3}d{8,7}e{8,13}:{a=9|b=
                    8|c=6|d=7|e=2}a:{a=3|b=2|c=2|d=3|e=2}b:{a=5|d=4|e=1}
                    c:{a=6|c=2|e=5}d:{a=2|b=10}e:{a=5|b=2|c=5|d=5|e=1},
                    (constant, 1)
(p)ath              auto
                    (C4)
                    60.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1}, (noise,
                    100, (constant, 2), (constant, 0), (constant, 1))
local (o)ctave      constant, 2
(a)mplitude         noise, 40, (constant, 0), (constant, 0), (constant,
                    1)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{c} :: tie r mp,a{8,1}b{8,4}c{8,7}d{8,0}e{8,15}:{a=9|b=
                    8|c=6|d=7|e=2}a:{a=3|b=2|c=2|d=3|e=2}b:{a=5|d=4|e=1}
                    c:{a=6|c=2|e=5}d:{a=2|b=10}e:{a=5|b=2|c=5|d=5|e=1},
                    (n,40,2,0,1)
      TIe ERROR: incorrect arguments: failed pulse object definition: 

pi{auto-acousticSnare}ti{c} ::  tie r mp,a{8,1}b{8,4}c{8,7}d{8,0}e{8,15}:{a=9|b=8|c=6|d=7|e=2}a:{a=3|b=2|c=2|d=3|e=2}b:{a=5|d=4|e=1}c:{a=6|c=2|e=5}d:{a=2|b=10}e:{a=5|b=2|c=5|d=5|e=1},(n,40,2,0,1)
      TIe ERROR: incorrect arguments: failed pulse object definition: 

pi{auto-acousticSnare}ti{c} :: tie r mp,a{8,1}b{8,4}c{8,7}d{8,0}e{8,15}:{a=9|b=8|c=6|d=7|e=2}a:{a=3|b=2|c=2|d=3|e=2}b:{a=5|d=4|e=1}c:{a=6|c=2|e=5}d:{a=2|b=10}e:{a=5|b=2|c=5|d=5|e=1},(c,1)
      TIe ERROR: incorrect arguments: failed pulse object definition: 

pi{auto-acousticSnare}ti{c} :: tie r mp,a{8,1}b{8,4}c{8,7}d{8,11}e{8,15}:{a=9|b=8|c=6|d=7|e=2}a:{a=3|b=2|c=2|d=3|e=2}b:{a=5|d=4|e=1}c:{a=6|c=2|e=5}d:{a=2|b=10}e:{a=5|b=2|c=5|d=5|e=1},(c,1)
TI c: parameter rhythm updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.12.00.21.29 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.21.29.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.21.29.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.21.29.mid

pi{auto-acousticSnare}ti{c} :: tie b whps,t,(bg,rw,(40,20,50,60,10)),90,80,190
TI c: parameter bpm updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.12.00.22.13 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.22.13.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.22.13.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.22.13.mid

pi{auto-acousticSnare}ti{c} :: tiv
TI: c, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: kalimba
      status: +, duration: 000.0--60.17
(i)nstrument        108 (generalMidi: kalimba)
(t)ime range        00.0--60.0
(b)pm               waveHalfPeriodSine, time, (basketGen, randomWalk,
                    (40,20,50,60,10)), 90, (constant, 80), (constant,
                    190)
(r)hythm            markovPulse, a{8,1}b{8,4}c{8,7}d{8,11}e{8,15}:{a=9|b
                    =8|c=6|d=7|e=2}a:{a=3|b=2|c=2|d=3|e=2}b:{a=5|d=4|e=1
                    }c:{a=6|c=2|e=5}d:{a=2|b=10}e:{a=5|b=2|c=5|d=5|e=1},
                    (constant, 1)
(p)ath              auto
                    (C4)
                    60.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1}, (noise,
                    100, (constant, 2), (constant, 0), (constant, 1))
local (o)ctave      constant, 2
(a)mplitude         noise, 40, (constant, 0), (constant, 0), (constant,
                    1)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{c} :: tie o bg,rp,(-2,-1,0,1)
TI c: parameter local octave updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.12.00.24.14 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.24.14.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.24.14.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.24.14.mid

pi{auto-acousticSnare}ti{c} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a
                    =9|b=7|c=4|d=5|e=2|f=1}a:{a=5|b=2}b:{a=6|b=2
                    |c=4}c:{b=7|c=5|d=4}d:{c=7|d
                    =3|e=2}e:{d=9|e=3|f=1}f:{a=9|e=1},(n,40,2,0,1)
TI c: parameter rhythm updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.12.00.32.48 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.32.48.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.32.48.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.32.48.mid

pi{auto-acousticSnare}ti{c} :: tie o n,50,1,-.5,.5
TI c: parameter local octave updated.

pi{auto-acousticSnare}ti{c} :: tiv
TI: c, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: kalimba
      status: +, duration: 000.0--60.02
(i)nstrument        108 (generalMidi: kalimba)
(t)ime range        00.0--60.0
(b)pm               waveHalfPeriodSine, time, (basketGen, randomWalk,
                    (40,20,50,60,10)), 90, (constant, 80), (constant,
                    190)
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a
                    =9|b=7|c=4|d=5|e=2|f=1}a:{a=5|b=2}b:{a=6|b=2|c=4}c:{
                    b=7|c=5|d=4}d:{c=7|d=3|e=2}e:{d=9|e=3|f=1}f:{a=9|e=1
                    }, (noise, 40, (constant, 2), (constant, 0),
                    (constant, 1))
(p)ath              auto
                    (C4)
                    60.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1}, (noise,
                    100, (constant, 2), (constant, 0), (constant, 1))
local (o)ctave      noise, 50, (constant, 1), (constant, -0.5),
                    (constant, 0.5)
(a)mplitude         noise, 40, (constant, 0), (constant, 0), (constant,
                    1)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{c} :: tie b bpl,e,l,((0,80),(10,110),(20,140),(30,170),(40,210))
TI c: parameter bpm updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.12.00.34.20 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.34.20.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.34.20.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.34.20.mid

pi{auto-acousticSnare}ti{c} :: tiv
TI: c, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: kalimba
      status: +, duration: 000.0--60.02
(i)nstrument        108 (generalMidi: kalimba)
(t)ime range        00.0--60.0
(b)pm               breakPointLinear, event, loop,
                    ((0,80),(10,110),(20,140),(30,170),(40,210))
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a
                    =9|b=7|c=4|d=5|e=2|f=1}a:{a=5|b=2}b:{a=6|b=2|c=4}c:{
                    b=7|c=5|d=4}d:{c=7|d=3|e=2}e:{d=9|e=3|f=1}f:{a=9|e=1
                    }, (noise, 40, (constant, 2), (constant, 0),
                    (constant, 1))
(p)ath              auto
                    (C4)
                    60.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1}, (noise,
                    100, (constant, 2), (constant, 0), (constant, 1))
local (o)ctave      noise, 50, (constant, 1), (constant, -0.5),
                    (constant, 0.5)
(a)mplitude         noise, 40, (constant, 0), (constant, 0), (constant,
                    1)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{c} :: tie r mp,a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a
                    =5|b=10|c=4|d=2|e=6|f=4}a:{a=5|b=2|f=4}b:{a=9|b=2|c=4}c:{
                    b=7|c=2|d=4}d:{c=4|d=3|e=2}e:{d=1|e=3|f=3}f:{a=5|e=4
                    },(rb,0.5,0.2,0,1)
TI c: parameter rhythm updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.12.00.41.04 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.41.04.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.41.04.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.41.04.mid

pi{auto-acousticSnare}ti{c} :: tie o c,-.5
TI c: parameter local octave updated.

pi{auto-acousticSnare}ti{c} :: tiv
TI: c, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: kalimba
      status: +, duration: 000.0--60.05
(i)nstrument        108 (generalMidi: kalimba)
(t)ime range        00.0--60.0
(b)pm               breakPointLinear, event, loop,
                    ((0,80),(10,110),(20,140),(30,170),(40,210))
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a
                    =5|b=10|c=4|d=2|e=6|f=4}a:{a=5|b=2|f=4}b:{a=9|b=2|c=
                    4}c:{b=7|c=2|d=4}d:{c=4|d=3|e=2}e:{d=1|e=3|f=3}f:{a=
                    5|e=4}, (randomBeta, 0.5, 0.2, (constant, 0),
                    (constant, 1))
(p)ath              auto
                    (C4)
                    60.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1}, (noise,
                    100, (constant, 2), (constant, 0), (constant, 1))
local (o)ctave      constant, -0.5
(a)mplitude         noise, 40, (constant, 0), (constant, 0), (constant,
                    1)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{c} :: tie b whps,e,(bg,oc,(20,30,14,53,2,38,30,56)),90,190,300
TI c: parameter bpm updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.12.00.42.38 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.42.38.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.42.38.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.00.42.38.mid

pi{auto-acousticSnare}ti{c} :: tiv
TI: c, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: kalimba
      status: +, duration: 00.0--60.4
(i)nstrument        108 (generalMidi: kalimba)
(t)ime range        00.0--60.0
(b)pm               waveHalfPeriodSine, event, (basketGen,
                    orderedCyclic, (20,30,14,53,2,38,30,56)), 90,
                    (constant, 190), (constant, 300)
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a
                    =5|b=10|c=4|d=2|e=6|f=4}a:{a=5|b=2|f=4}b:{a=9|b=2|c=
                    4}c:{b=7|c=2|d=4}d:{c=4|d=3|e=2}e:{d=1|e=3|f=3}f:{a=
                    5|e=4}, (randomBeta, 0.5, 0.2, (constant, 0),
                    (constant, 1))
(p)ath              auto
                    (C4)
                    60.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1}, (noise,
                    100, (constant, 2), (constant, 0), (constant, 1))
local (o)ctave      constant, -0.5
(a)mplitude         noise, 40, (constant, 0), (constant, 0), (constant,
                    1)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{c} :: tie a rb,0.6,0.2,0,1
TI c: parameter amplitude updated.

pi{auto-acousticSnare}ti{c} :: tie f mv,a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},(c,1)
TI c: parameter local field updated.

pi{auto-acousticSnare}ti{c} :: tie b c,135
TI c: parameter bpm updated.

pi{auto-acousticSnare}ti{c} :: tiv
TI: c, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: kalimba
      status: +, duration: 000.0--60.44
(i)nstrument        108 (generalMidi: kalimba)
(t)ime range        00.0--60.0
(b)pm               constant, 135
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a
                    =5|b=10|c=4|d=2|e=6|f=4}a:{a=5|b=2|f=4}b:{a=9|b=2|c=
                    4}c:{b=7|c=2|d=4}d:{c=4|d=3|e=2}e:{d=1|e=3|f=3}f:{a=
                    5|e=4}, (randomBeta, 0.5, 0.2, (constant, 0),
                    (constant, 1))
(p)ath              auto
                    (C4)
                    60.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},
                    (constant, 1)
local (o)ctave      constant, -0.5
(a)mplitude         randomBeta, 0.6, 0.2, (constant, 0), (constant, 1)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-acousticSnare}ti{c} :: tie a n,30,(bg,rw,(0,0.5,1,1.5,2)),0,1
TI c: parameter amplitude updated.

pi{auto-acousticSnare}ti{c} :: eln; elh
      EventList ath2010.03.12.01.05.05 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.01.05.05.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.01.05.05.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.01.05.05.mid

pi{auto-acousticSnare}ti{c} :: emo mp; tin e 40; tie r pt,(c,1),(c,1),(c,1); tie b 135
EventMode mode set to: midiPercussion.

TI e created.

TI e: parameter rhythm updated.

      TIe ERROR: object creation: incorrect data-type in arguments.
'int' object is unsubscriptable

pi{auto-electricSnare}ti{e} :: tie b c,135
TI e: parameter bpm updated.

pi{auto-electricSnare}ti{e} :: eln; elh
      EventList ath2010.03.12.01.06.09 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.01.06.09.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.01.06.09.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.01.06.09.mid

pi{auto-electricSnare}ti{e} :: timute d
TI d is no longer muted.

pi{auto-electricSnare}ti{e} :: timute d
TI d is now muted.

pi{auto-electricSnare}ti{e} :: timute e
TI e is now muted.

pi{auto-electricSnare}ti{e} :: eln; elh
      EventList ath2010.03.12.01.06.42 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.01.06.42.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.01.06.42.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.01.06.42.mid

pi{auto-electricSnare}ti{e} :: tiv
TI: e, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: piano1
      status: o, duration: 000.0--60.66
(i)nstrument        40 (generalMidiPercussion: electricSnare)
(t)ime range        00.0--60.0
(b)pm               constant, 135
(r)hythm            pulseTriple, (constant, 1), (constant, 1),
                    (constant, 1), (randomUniform, (constant, 0.5),
                    (constant, 1.5))
(p)ath              auto-electricSnare
                    (E2)
                    60.00(s)
local (f)ield       constant, 0
local (o)ctave      constant, 0
(a)mplitude         randomBeta, 0.4, 0.4, (constant, 0.7), (constant,
                    0.9)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-electricSnare}ti{e} :: tils
TextureInstances available:
{name,status,TM,PI,instrument,time,TC}
   a                o LineGroove  auto               104 00.0--60.0   0
   b                o LineGroove  auto-acousticSnare 38  00.0--60.0   0
   c                + LineGroove  auto               108 00.0--60.0   0
   c1               o LineGroove  auto               3   00.0--20.0   0
   c2               o LineGroove  auto               5   00.0--20.0   0
   d                o LineGroove  auto-acousticSnare 4   0.0--4.0     0
 + e                o LineGroove  auto-electricSnare 40  00.0--60.0   0

pi{auto-electricSnare}ti{e} :: tiv c
TI: c, TM: LineGroove, TC: 0, TT: TwelveEqual
pitchMode: pitchSpace, silenceMode: off, postMapMode: on
midiProgram: kalimba
      status: +, duration: 000.0--60.07
(i)nstrument        108 (generalMidi: kalimba)
(t)ime range        00.0--60.0
(b)pm               constant, 135
(r)hythm            markovPulse, a{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a
                    =5|b=10|c=4|d=2|e=6|f=4}a:{a=5|b=2|f=4}b:{a=9|b=2|c=
                    4}c:{b=7|c=2|d=4}d:{c=4|d=3|e=2}e:{d=1|e=3|f=3}f:{a=
                    5|e=4}, (randomBeta, 0.5, 0.2, (constant, 0),
                    (constant, 1))
(p)ath              auto
                    (C4)
                    60.00(s)
local (f)ield       markovValue, a{-3}b{0}c{1}d{5}e{6}f{9}g{12}:{a=1|b=3
                    |c=2|d=5|e=9|f=6|g=10}a:{b=5}b:{a=2|c=6}c:{b=4|d=6}d
                    :{c=5|e=8}e:{d=8|f=9}f:{e=8|g=7}g:{f=6|g=1},
                    (constant, 1)
local (o)ctave      constant, -0.5
(a)mplitude         noise, 30, (basketGen, randomWalk, (0,0.5,1,1.5,2)),
                    (constant, 0), (constant, 1)
pan(n)ing           constant, 0.5
au(x)iliary         none
texture (s)tatic
      s0            parallelMotionList, (), 0.0
      s1            pitchSelectorControl, randomPermutate
      s2            levelFieldMonophonic, event
      s3            levelOctaveMonophonic, event
texture (d)ynamic   none

pi{auto-electricSnare}ti{e} :: tie r mp,{6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a
                    =5|b=10|c=4|d=2|e=6|f=4}a:{a=5|b=2|f=4}b:{a=9|b=2|c=
                    4}c:{b=7|c=2|d=4}d:{c=4|d=3|e=2}e:{d=1|e=3|f=3}f:{a=
                    5|e=4},(c,1)
      TIe ERROR: incorrect arguments: Markov transition creation failed:
weight specified for undefined symbol: a

pi{auto-electricSnare}ti{e} :: tie r mp,a
							   {6,1}b{6,2}c{6,3}d{6,4}e{6,6}f{6,9}:{a
                    =5|b=10|c=4|d=2|e=6|f=4}a:{a=5|b=2|f=4}b:{a=9|b=2|c=
                    4}c:{b=7|c=2|d=4}d:{c=4|d=3|e=2}e:{d=1|e=3|f=3}f:{a=
                    5|e=4},(c,1)
TI e: parameter rhythm updated.

pi{auto-electricSnare}ti{e} :: eln; elh
      EventList ath2010.03.12.01.10.41 complete:
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.01.10.41.mid
C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.01.10.41.xml

EventList hear initiated: C:\Users\yhprumkcaj\Desktop\MIT SPRING
2010\21M.380\scratch\ath2010.03.12.01.10.41.mid

pi{auto-electricSnare}ti{e} :: 
