/*++

Copyright (c) Ged Murphy.  All rights reserved.

    THIS CODE AND INFORMATION IS PROVIDED UNDER THE TINYKRNL SHARED
    SOURCE LICENSE.  PLEASE READ THE FILE "LICENSE" IN THE TOP
    LEVEL DIRECTORY.

Module Name:

    moupnp.c

Abstract:

    The i8042 Port Driver <FILLMEIN>

Environment:

    Kernel mode

Revision History:

    Ged Murphy - Started Implementation - <FILLMEIN>

--*/
#include "precomp.h"