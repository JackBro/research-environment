/*++

Copyright (c) Samuel Serapi�n, .   All rights reserved.

    THIS CODE AND INFORMATION IS PROVIDED UNDER THE TINYKRNL SHARED
    SOURCE LICENSE.  PLEASE READ THE FILE "LICENSE" IN THE TOP
    LEVEL DIRECTORY.

    Based on WDK sample source code (c) Microsoft Corporation.

Module Name:

    timesup.c

Abstract:

    <FILLMEIN>

Environment:

    Kernel mode

Revision History:

    Samuel Serapi�n - Started Implementation -

--*/
#include "precomp.h"
