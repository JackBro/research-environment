/*++

Copyright (c) .  All rights reserved.

    THIS CODE AND INFORMATION IS PROVIDED UNDER THE TINYKRNL SHARED
    SOURCE LICENSE.  PLEASE READ THE FILE "LICENSE" IN THE TOP
    LEVEL DIRECTORY.

Module Name:

    kbdclass.c

Abstract:

    The Keyboard Class Driver <FILLMEIN>

Environment:

    Kernel mode

Revision History:

    <FILLMEIN> - xx-May-2006 - Started Implementation

--*/
#include "ntddk.h"

NTSTATUS
DriverEntry(IN PDRIVER_OBJECT DriverObject,
            IN PUNICODE_STRING RegistryPath)
{
    //
    // FIXME: TODO
    //
    return STATUS_SUCCESS;
}
