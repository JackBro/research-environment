<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en-AU"><head>
    <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    <meta name="description" content="Information about the project and its developers.">
    <meta name="author" content="haran">
    <meta name="generator" content="Microsoft FrontPage 6.0"><!-- Navigational metadata for large websites (an accessibility feature): -->

    
    <link rel="top" href="http://tinykrnl.org/index.htm" title="Homepage">
    <link rel="up" href="http://tinykrnl.org/index.htm" title="Up">
    <link rel="first" href="http://tinykrnl.org/index.htm" title="First page">
    <link rel="previous" href="http://tinykrnl.org/index.htm" title="Previous page">
    <link rel="next" href="http://tinykrnl.org/index.htm" title="Next page">
    <link rel="last" href="http://tinykrnl.org/index.htm" title="Last page">
    <link rel="toc" href="http://tinykrnl.org/index.htm" title="Table of contents">
    <link rel="index" href="http://tinykrnl.org/index.htm" title="Site map">

    <link rel="stylesheet" type="text/css" href="http://www.tinykrnl.org/sinorca-screen.css" media="screen" title="Sinorca (screen)">
    <link rel="stylesheet alternative" type="text/css" href="http://www.tinykrnl.org/sinorca-screen-alt.css" media="screen" title="Sinorca (alternative)">
    <link rel="stylesheet" type="text/css" href="http://www.tinykrnl.org/sinorca-print.css" media="print"><title>TinyKRNL Project Status - Overview</title>

    
    <script language="JavaScript" type="text/JavaScript" src="status_filer/menu.js"></script></head>
  <body onresize="P7_ReDoIt();P7_Snap('leftanchor','closer',0,0,'leftanchor','dropdownLayer',0,0)">
   <!-- Hidden Dropdown Menus -->

          <div id="drop1" style="position: absolute; left: 328px; top: 109px; z-index: 2; visibility: hidden;">
          <table border="0" cellpadding="0" cellspacing="0">
               <tbody><tr>
                    <td rowspan="4" onmouseover="P7_autoLayers(0)" bgcolor="#999999" width="1"></td>
                    <td colspan="3" bgcolor="#999999" height="1"></td>
                    <td rowspan="4" onmouseover="P7_autoLayers(0)" bgcolor="#999999" width="1"></td>
               </tr>
               <tr>

                    <td rowspan="2" onmouseover="P7_autoLayers(0)" bgcolor="#ffffff" width="3"></td>
                    <td bgcolor="#ffffff" height="3"></td>
                    <td rowspan="2" onmouseover="P7_autoLayers(0)" bgcolor="#ffffff" width="3"></td>
               </tr>
               <tr>
                    <td align="center">
                         <font class="menu">
                         <table border="0" cellpadding="3" cellspacing="0">
                              <tbody><tr>
								<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='about_proj.htm';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
								Project Information</td></tr>

                              <tr>
								<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='about_devs.htm';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
								Developer Information</td></tr>
                              <tr>
								<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='about_faq.htm';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
								FAQs</td></tr>
                              </tbody></table>
                         </font>
                    </td>
               </tr>
               <tr>
                    <td colspan="3" onmouseover="P7_autoLayers(0)" bgcolor="#ffffff" height="3"></td>
               </tr>

               <tr>
                    <td colspan="6" onmouseover="P7_autoLayers(0)" bgcolor="#999999" height="1"></td>
               </tr>
          </tbody></table>
          </div>

          <div id="drop2" style="position: absolute; left: 246px; top: 100px; z-index: 2; visibility: hidden;">
          <table border="0" cellpadding="0" cellspacing="0">
               <tbody><tr>

                    <td rowspan="4" onmouseover="P7_autoLayers(0)" bgcolor="#999999" width="1"></td>
                    <td colspan="3" bgcolor="#999999" height="1"></td>
                    <td rowspan="4" onmouseover="P7_autoLayers(0)" bgcolor="#999999" width="1"></td>
               </tr>
               <tr>
                    <td rowspan="2" onmouseover="P7_autoLayers(0)" bgcolor="#ffffff" width="3"></td>
                    <td bgcolor="#ffffff" height="3"></td>
                    <td rowspan="2" onmouseover="P7_autoLayers(0)" bgcolor="#ffffff" width="3"></td>
               </tr>

               <tr>
                    <td align="center">
                         <font class="menu">
                         <table border="0" cellpadding="3" cellspacing="0">
                              <tbody><tr>
								<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='dev_phase1.htm';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
								Phase 1 Development</td></tr>
                              <tr>
								<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='dev_phase2.htm';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
								Phase 2<font class="menu">
                         		Development</font></td></tr>
                              <tr>
								<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='dev_phase3.htm';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
								Phase 3
                         <font class="menu">
                         		Development</font></td></tr>

                              <tr>
								<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='dev_source.htm';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
								Source Code Access</td>
								</tr>
								<tr>
									<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='dev_build.htm';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
                         <font class="menu">
                         			Build Environment</font></td>
								</tr>
								<tr>
									<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='dev_test.htm';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
                         <font class="menu">
                         			Test Suite</font></td>
								</tr>

                              <tr>
								<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='guidelines.htm';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
								Coding Guidelines</td></tr>
                              </tbody></table>
                         </font>
                    </td>
               </tr>

               <tr>
                    <td colspan="3" onmouseover="P7_autoLayers(0)" bgcolor="#ffffff" height="3"></td>
               </tr>
               <tr>
                    <td colspan="6" onmouseover="P7_autoLayers(0)" bgcolor="#999999" height="1"></td>
               </tr>
          </tbody></table>
          </div>
          
          <div id="drop3" style="position: absolute; left: 341px; top: 100px; z-index: 2; visibility: hidden;">

          <table border="0" cellpadding="0" cellspacing="0">
               <tbody><tr>
                    <td rowspan="4" onmouseover="P7_autoLayers(0)" bgcolor="#999999" width="1"></td>
                    <td colspan="3" bgcolor="#999999" height="1"></td>
                    <td rowspan="4" onmouseover="P7_autoLayers(0)" bgcolor="#999999" width="1"></td>
               </tr>
               <tr>
                    <td rowspan="2" onmouseover="P7_autoLayers(0)" bgcolor="#ffffff" width="3"></td>
                    <td bgcolor="#ffffff" height="3"></td>

                    <td rowspan="2" onmouseover="P7_autoLayers(0)" bgcolor="#ffffff" width="3"></td>
               </tr>
               <tr>
                    <td align="center">
                         <font class="menu">
                         <table border="0" cellpadding="3" cellspacing="0">
                              <tbody><tr>
								<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='docu_doxy.htm';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
								Doxygen Documentation</td></tr>
                              <tr>
								<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='books.htm';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
								Published Books</td></tr>

                              <tr>
								<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='http://svn.tinykrnl.org/svn/tinykrnl/';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
								Live SVN Browser</td></tr>
                              <tr>
								<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='links.htm';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
								Online Resources</td></tr>
                              <tr>
								<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='reading.htm';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
								Recommended Reading</td></tr>
                              <tr>
								<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='whitepapers.htm';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
								Whitepapers</td></tr>
                              <tr>
								<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='articles.htm';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
								Technical Articles</td></tr>

                         </tbody></table>

                         </font>
                    </td>
               </tr>
               <tr>
                    <td colspan="3" onmouseover="P7_autoLayers(0)" bgcolor="#ffffff" height="3"></td>
               </tr>
               <tr>
                    <td colspan="6" onmouseover="P7_autoLayers(0)" bgcolor="#999999" height="1"></td>
               </tr>

          </tbody></table>
          </div>
          
          <div id="drop4" style="position: absolute; left: 462px; top: 100px; z-index: 2; visibility: hidden;">
          <table border="0" cellpadding="0" cellspacing="0">
               <tbody><tr>
                    <td rowspan="4" onmouseover="P7_autoLayers(0)" bgcolor="#999999" width="1"></td>
                    <td colspan="3" bgcolor="#999999" height="1"></td>
                    <td rowspan="4" onmouseover="P7_autoLayers(0)" bgcolor="#999999" width="1"></td>
               </tr>

               <tr>
                    <td rowspan="2" onmouseover="P7_autoLayers(0)" bgcolor="#ffffff" width="3"></td>
                    <td bgcolor="#ffffff" height="3"></td>
                    <td rowspan="2" onmouseover="P7_autoLayers(0)" bgcolor="#ffffff" width="3"></td>
               </tr>
               <tr>
                    <td align="center">
                         <font class="menu">
                         <table border="0" cellpadding="3" cellspacing="0">

                              <tbody><tr>
								<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='down_releases.htm';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
								Releases</td></tr>
                              <tr>
								<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='testsuite.htm';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
								Test Suite</td></tr>
                              <tr>
								<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='tools.htm';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
								3rd Party Tools</td></tr>
                              <tr>
								<td onmouseover="this.bgColor='EDCA5D'" onmouseout="this.bgColor='#ffffff'" onclick="window.location.href='down_pdf.htm';P7_autoLayers(0)" align="left" bgcolor="#ffffff">
								Documentation PDFs</td></tr>
                         </tbody></table>
                         </font>
                    </td>

               </tr>
               <tr>
                    <td colspan="3" onmouseover="P7_autoLayers(0)" bgcolor="#ffffff" height="3"></td>
               </tr>
               <tr>
                    <td colspan="6" onmouseover="P7_autoLayers(0)" bgcolor="#999999" height="1"></td>
               </tr>
          </tbody></table>
          </div>
    <!-- For non-visual user agents: -->
      <div id="top"><a href="#main-copy" class="doNotDisplay doNotPrint">Skip to 
		main content.</a></div>

    <!-- ##### Header ##### -->

    <div id="header">
      <div class="superHeader">
        <div class="left">
          <span class="doNotDisplay">Related sites:</span>
          <a href="http://tinykrnl.org/index.htm" class="highlight">Current Status</a> |
          <a href="mailto:join@tinykrnl.org?subject=Joining%20the%20Project">Join Project</a>
        </div>
        <div class="right">
          <span class="doNotDisplay">More related sites:</span>
          <a href="javascript:alert('Sorry, releases are not yet available')">Current Release</a> |
          <a href="http://svn.tinykrnl.org/tinykrnl/tinynightly.7z">Nightly Release</a> |
          <a href="irc://freenode.net/tinykrnl">IRC Channel</a> |
          <a href="mailto:devel-subscribe@tinykrnl.org">Mailing List</a> |
          <a href="http://tinykrnl.org/index.htm">Site Map</a>
        </div>
      </div>

      <div class="midHeader">
        <h1 class="headerTitle" align="left">Project Status [LIVE]</h1>
      </div>

      <div class="subHeader">
        <span class="doNotDisplay">Navigation:</span>
        <a href="http://tinykrnl.org/index.htm">Home</a> |
        <a href="http://tinykrnl.org/about_proj.htm" name="menuanchor1" onmouseover="P7_autoLayers(0);P7_Snap('menuanchor1','drop1',0,8);P7_autoLayers(0,'drop1')">
        	<img src="" name="menuanchor1" border="0" height="0" width="0%">
        	About
        </a> |
        <a href="http://tinykrnl.org/dev_phase1.htm" name="menuanchor2" onmouseover="P7_autoLayers(0);P7_Snap('menuanchor2','drop2',0,8);P7_autoLayers(0,'drop2')">
        	<img src="" name="menuanchor2" border="0" height="0" width="0%">
        	Development
        </a> |
        <a href="http://tinykrnl.org/docu_doxy.htm" name="menuanchor3" onmouseover="P7_autoLayers(0);P7_Snap('menuanchor3','drop3',0,8);P7_autoLayers(0,'drop3')">
			<img src="" name="menuanchor3" border="0" height="0" width="0%">
	        Documentation
	    </a> |
        <a href="http://tinykrnl.org/down_releases.htm" name="menuanchor4" onmouseover="P7_autoLayers(0);P7_Snap('menuanchor4','drop4',0,8);P7_autoLayers(0,'drop4')">
        	<img src="" name="menuanchor4" border="0" height="0" width="0%">
	        Downloads
	    </a>
      </div>
    </div>

    <!-- ##### Side Bar ##### -->

    <div id="side-bar">
      <div>
        <p class="sideBarTitle">Page Navigation</p>
        <ul>
	  	  <li><a href="#phase1" title="Phase 1">
			� Phase 1 Status</a></li>
          <li><a href="#phase2" title="Phase 2">� Phase 2 Status</a></li>
          <li><a href="#phase3" title="Phase 3">� Phase 3 Status</a></li>
        </ul>
      </div>

      <div>
        <p class="sideBarTitle">Section Navigation</p>
        <ul>
          <li><a href="http://tinykrnl.org/index.htm">� Back</a></li>
        </ul>
      </div>

      <div class="lighterBackground">
        <p class="sideBarTitle">Latest News</p>
        <p align="center"><b><span class="sideBarText">08/05/06</span></b></p>
		<p align="justify"><span class="sideBarText">MountMgr and PartMgr are 
		now booting and working properly in TinyKRNL. NTDLL and Disk are now 40% 
		complete.</span></p>
        <p align="center"><b><span class="sideBarText">29/03/06</span></b></p>
		<p align="justify"><span class="sideBarText">BootVid, KDCom are now 
		fully completed. WMILib and IntelIDE are almost entirely completed and 
		able to boot. ISAPnP has all in-use codepaths implemented and is able to 
		boot. </span>
		</p></div>
    
    </div>

    <!-- ##### Main Copy ##### -->

<?php include "http://tinykrnl.org/phase1-status.php"; ?>

      <a class="topOfPage" href="#top" title="Go to the top of this page">^ TOP</a>

      </p><h1 id="phase2">Phase 2 Status</h1>
      <p>Phase 3 is currently not underway.</p><p>

      <a class="topOfPage" href="#top" title="Go to the top of this page">^ TOP</a>

      </p><h1 id="phase3">Phase 3 Status</h1>
      <p>Phase 3 is currently not underway.</p><p>&nbsp;</p></div>
    
    <!-- ##### Footer ##### -->

    <div id="footer">
      <div class="left">
        E-mail:&nbsp;<a href="mailto:webmaster@tinykrnl.org" title="Email webmaster">webmaster@tinykrnl.org</a><br>
        <a href="mailto:feedback@tinykrnl.org" class="doNotPrint">Contact Us</a>
      </div>

      <br class="doNotDisplay doNotPrint">

      <div class="right">
        �Copyright 2006 TinyKRNL Project. All Rights Reserved<br>
        <a href="http://tinykrnl.org/index.htm" class="doNotPrint">Privacy Statement</a>
      </div>
    </div>
  </body></html>
