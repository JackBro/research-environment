// 
// You may only use this code if you agree to the terms of the ProjectOZ License agreement (see License.txt).
// If you do not agree to the terms, do not use the code.
//

#include <stdio.h>

//#include <stdlib.h>
void   __cdecl _exit(int);

//#include <malloc.h>
void *  __cdecl malloc(size_t);
void *  __cdecl free(void *);

